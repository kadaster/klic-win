package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ImklFeatureWithValidationDomainObject;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.namespace.QName;

public class GeonauwkeurigheidXyHandler extends AbstractCodelistElementHandler<ImklFeatureWithValidationDomainObject> {

    private static final String CODELIST_NAME_IMKL = "NauwkeurigheidXYvalue";

    @Override
    protected QName getHandlingElement() {
        return Elements.GEO_NAUWKEURIGHEID_XY;
    }

    @Override
    protected void preValidate() {
        setCodelist(CODELIST_NAME_IMKL);
    }

    @Override
    protected void postValidate(final ImklFeatureWithValidationDomainObject imklDomainObject, final String xLinkCodelistValue) {
        imklDomainObject.setGeoNauwkeurigheidXY(xLinkCodelistValue);
    }
}