package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.Utiliteitsnet;

import javax.xml.namespace.QName;

import static nl.kadaster.klic.win.feature.common.util.gml.Elements.UTILITYNETWORK_AUTHORITY_ROLE;

public class RelatedPartyRoleHandler extends AbstractCodelistElementHandler<Utiliteitsnet> {

    private static final String CODELIST_NAME_INSPIRE = "RelatedPartyRoleValue";

    @Override
    protected QName getHandlingElement() {
        return UTILITYNETWORK_AUTHORITY_ROLE;
    }

    @Override
    protected void preValidate() {
        setCodelist(CODELIST_NAME_INSPIRE);
    }
}
