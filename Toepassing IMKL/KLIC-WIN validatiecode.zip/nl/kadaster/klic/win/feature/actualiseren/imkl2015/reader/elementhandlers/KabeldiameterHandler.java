package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.KabelOfLeiding;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxHelper;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.stream.events.StartElement;

public class KabeldiameterHandler extends AbstractElementHandler implements ElementHandler<KabelOfLeiding> {
    @Override
    public boolean shouldHandle(StartElement element) {
        return sameQName(Elements.KABELDIAMETER, element.getName());
    }

    @Override
    public void handle(StartElement element, FeatureLinks featureLinks, KabelOfLeiding kabelOfLeiding, StaxEventReader staxEventReader, ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        kabelOfLeiding.setKabeldiameter(StaxHelper.readInteger(staxEventReader));
    }

}
