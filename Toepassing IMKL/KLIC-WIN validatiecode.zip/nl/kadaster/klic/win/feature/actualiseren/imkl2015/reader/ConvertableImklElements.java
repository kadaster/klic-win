package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import javax.xml.namespace.QName;
import java.util.HashMap;
import java.util.Map;

class ConvertableImklElements {

    private final Map<QName, QName> convertibleImklElements = new HashMap<>();

    public QName getInspireElement(final QName baseElement) {
        return convertibleImklElements.get(baseElement);
    }

    public void add(final QName baseElement, final QName inspireElement) {
        convertibleImklElements.put(baseElement, inspireElement);
    }

    public boolean contains(final QName baseElement) {
        return convertibleImklElements.containsKey(baseElement);
    }
}
