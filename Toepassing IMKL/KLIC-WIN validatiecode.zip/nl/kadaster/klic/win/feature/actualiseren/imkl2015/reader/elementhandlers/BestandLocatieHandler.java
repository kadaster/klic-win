package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import javax.xml.stream.events.StartElement;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ImklFeatureWithValidationDomainObject;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxHelper;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

public abstract class BestandLocatieHandler extends AbstractElementHandler implements ElementHandler<ImklFeatureWithValidationDomainObject> {

    @Override
    public boolean shouldHandle(final StartElement element) {
        return sameQName(Elements.BESTANDLOCATIE, element.getName());
    }

    @Override
    public void handle(final StartElement element, final FeatureLinks featureLinks, final ImklFeatureWithValidationDomainObject feature, final StaxEventReader staxEventReader, final ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        String bestandLocatie = StaxHelper.readElementData(staxEventReader);
        feature.setBestandLocatie(bestandLocatie);

        final boolean valuePresent = bestandLocatie != null;
        feature.setSeenElementValue(Elements.BESTANDLOCATIE, element.getLocation().getLineNumber(), valuePresent);

        validateBestandLocatie(bestandLocatie, feature.getGmlId(), validationMessageBuilder);
    }

    protected abstract void validateBestandLocatie(final String bestandLocatie, final String gmlId, final ValidationMessageBuilder validationMessageBuilder);

}