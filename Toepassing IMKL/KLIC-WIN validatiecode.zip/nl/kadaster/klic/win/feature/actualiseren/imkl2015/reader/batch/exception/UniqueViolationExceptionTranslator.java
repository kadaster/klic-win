package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.exception;

import org.springframework.dao.DataIntegrityViolationException;

import java.sql.BatchUpdateException;
import java.sql.SQLException;

public final class UniqueViolationExceptionTranslator {

    private static final String SQLSTATE_UNIQUE_CONSTRAINT_VOILATION = "23505";
    private static final String GMLID = "gmlid";

    private UniqueViolationExceptionTranslator() {
    }

    public static String getGmlId(final Exception exception) {
        if (exception instanceof BatchUpdateException) {
            return getGmlId((BatchUpdateException)exception);
        }
        if (exception instanceof DataIntegrityViolationException) {
            return getGmlId((DataIntegrityViolationException)exception);
        }
        return null;
    }

    private static String getGmlId(final BatchUpdateException bue) {
        final SQLException nextException = bue.getNextException();
        final boolean sqlStatePresent = nextException != null && nextException.getSQLState() != null;
        final boolean isUniqueContraintSqlState = sqlStatePresent && nextException.getSQLState().equals(SQLSTATE_UNIQUE_CONSTRAINT_VOILATION);
        final boolean uniqueConstraintViolatedIsGmlId = isUniqueContraintSqlState && nextException.getMessage() != null && nextException.getMessage().contains(GMLID);
        if (uniqueConstraintViolatedIsGmlId) {
            return getGmlId(nextException.getMessage());
        }
        return null;
    }

    private static String getGmlId(final DataIntegrityViolationException dive) {
        final Throwable cause = dive.getCause();
        final boolean causeMessagePresent = cause != null && cause.getMessage() != null;
        final boolean uniqueConstraintViolatedIsGmlId = causeMessagePresent && cause.getMessage().contains(GMLID);
        if (uniqueConstraintViolatedIsGmlId) {
            return getGmlId(cause.getMessage());
        }
        return null;
    }

    private static String getGmlId(final String message) {
        String gmlId = null;
        final int startIndexGmlId = message.lastIndexOf('(') + 1;
        final int endIndexGmlId = message.lastIndexOf(')');
        if (startIndexGmlId > -1 && endIndexGmlId > -1) {
            gmlId = message.substring(startIndexGmlId, endIndexGmlId);
        }
        return gmlId;
    }
}
