package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception;

public class StaxHelperConfigurationException extends RuntimeException {

    private static final long serialVersionUID = -1886354618613629888L;

    public StaxHelperConfigurationException(final String message, final Throwable cause) {
        super(message, cause);
    }
}
