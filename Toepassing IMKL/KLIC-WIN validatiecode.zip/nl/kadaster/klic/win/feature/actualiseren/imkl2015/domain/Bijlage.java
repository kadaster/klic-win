package nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain;

public class Bijlage extends ImklFeatureWithValidationDomainObject {

    private String bijlageType;

    public String getBijlageType() {
        return bijlageType;
    }

    public void setBijlageType(final String bijlageType) {
        this.bijlageType = bijlageType;
    }

}
