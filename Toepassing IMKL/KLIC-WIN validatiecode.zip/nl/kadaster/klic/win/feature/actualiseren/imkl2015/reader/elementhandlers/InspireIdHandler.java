package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.FeatureWithValidationDomainObject;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.GmlId;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.InspireId;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.namespace.QName;
import javax.xml.stream.events.StartElement;

public class InspireIdHandler extends AbstractInspireIdHandler implements ElementHandler<FeatureWithValidationDomainObject> {
    @Override
    public boolean shouldHandle(final StartElement element) {
        return sameQName(Elements.INSPIRE_ID, element.getName());
    }

    @Override
    public void handle(final StartElement element, final FeatureLinks featureLinks, final FeatureWithValidationDomainObject inspireDomainObject, final StaxEventReader staxEventReader, final ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        final InspireId inspireId = getInspireId(staxEventReader, featureLinks.getInspireType(), featureLinks.getBaseElement());
        inspireDomainObject.setInspireId(inspireId);
        compareInspireIdWithGmlId(inspireDomainObject.getInspireId(), inspireDomainObject, validationMessageBuilder);

        final boolean valuePresent = inspireId != null && inspireId.isComplete();
        inspireDomainObject.setSeenElementValue(Elements.INSPIRE_ID, element.getLocation().getLineNumber(), valuePresent);
    }

    private static InspireId getInspireId(final StaxEventReader staxEventReader, final QName featureType, final QName baseType) throws XMLException {
        return getInspireId(Elements.INSPIRE_ID, Elements.ID_NAMESPACE_INSPIRE_BASE, Elements.LOCAL_ID_INSPIRE_BASE, featureType, baseType, staxEventReader);
    }

    private void compareInspireIdWithGmlId(final InspireId inspireId, final FeatureWithValidationDomainObject inspireDomainObject, final ValidationMessageBuilder validationMessageBuilder) {
        final GmlId gmlIdInspireId = new GmlId(inspireId.getNamespace(), inspireId.getLocalId());
        final GmlId gmlIdFeatureMember = new GmlId(inspireDomainObject.getGmlId());
        if (!gmlIdInspireId.isValid()) {
            validationMessageBuilder.addErrorInspireIdIncorrect(inspireDomainObject.getGmlId());
        } else if (gmlIdFeatureMember.isValid() && !gmlIdInspireId.equals(gmlIdFeatureMember)) {
            validationMessageBuilder.addErrorGmlIdDoesntCompareToInspireId(inspireDomainObject.getGmlId());
        }
    }
}
