package nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain;


public class KabelEnLeidingContainer extends ImklFeatureWithValidationDomainObject {
}
