package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks;

import nl.kadaster.klic.util.EnumUtil;
import nl.kadaster.klic.win.feature.domain.imkl2015.ImklFeatureType;

public class ImklFeaturetypeProvider {

    public ImklFeatureType getImklFeaturetype(final String featuretype) {
        return EnumUtil.getEnumOptionFromValue(ImklFeatureType.class, featuretype);
    }
}
