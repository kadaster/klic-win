package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.Utiliteitsnet;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.CodelistValueValidator;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.storage.ThemaDao;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;
import org.springframework.beans.factory.annotation.Autowired;

import javax.xml.stream.events.StartElement;

public class ImklThemaHandler extends AbstractElementHandler implements ElementHandler<Utiliteitsnet> {

    private static final String CODELIST_NAME = "Thema";

    @Autowired
    private CodelistValueValidator codelistValueValidator;

    @Autowired
    private ThemaDao themaDao;

    @Override
    public boolean shouldHandle(StartElement element) {
        return sameQName(Elements.IMKL_THEMA, element.getName());
    }

    @Override
    public void handle(StartElement element, FeatureLinks featureLinks, Utiliteitsnet utiliteitsnet, StaxEventReader staxEventReader, ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        String thema = getXLink(element);
        utiliteitsnet.setWionthema(themaDao.getThemaId(thema));
        if (codelistValueValidator.validateCodelistValue(CODELIST_NAME, thema, validationMessageBuilder, utiliteitsnet)) {
            String themaStripped = thema.substring(thema.lastIndexOf("/") + 1);
            utiliteitsnet.setThema(themaStripped);
        }
    }
}
