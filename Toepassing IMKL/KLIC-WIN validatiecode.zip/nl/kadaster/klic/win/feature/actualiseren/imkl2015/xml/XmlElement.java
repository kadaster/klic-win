package nl.kadaster.klic.win.feature.actualiseren.imkl2015.xml;

public class XmlElement {

    private final String xml;
    private final int rowNr;

    XmlElement(final String xml, final int rowNr) {
        this.xml = xml;
        this.rowNr = rowNr;
    }

    public String getXml() {
        return xml;
    }

    public int getRowNr() {
        return rowNr;
    }
}
