package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.Utiliteitsnet;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ValidationRule;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ElementsNetworkHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ImklEmailHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ImklIdentificatieHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ImklNaamHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ImklOmschrijvingHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ImklTelefoonHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ImklThemaHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.LabelHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.RelatedPartyRoleHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.StandaardDiepteleggingHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.UtilityNetworkTypeHandler;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;
import org.springframework.beans.factory.annotation.Autowired;

import javax.xml.namespace.QName;
import java.util.List;

public class UtiliteitsnetStaxMapper extends StaxMapper<Utiliteitsnet> {

    @Autowired
    private ImklThemaHandler imklThemaHandler;

    @Autowired
    private UtilityNetworkTypeHandler utilityNetworkTypeHandler;

    @Autowired
    private RelatedPartyRoleHandler relatedPartyRoleHandler;

    public UtiliteitsnetStaxMapper() {
        super();
    }

    @Override
    void initElementHandlers() {
        super.initElementHandlers();
        addElementHandler(new ElementsNetworkHandler());
        addElementHandler(new ImklIdentificatieHandler());
        addElementHandler(new LabelHandler());
        addElementHandler(new ImklOmschrijvingHandler());
        addElementHandler(new ImklNaamHandler());
        addElementHandler(new ImklTelefoonHandler());
        addElementHandler(new ImklEmailHandler());
        addElementHandler(imklThemaHandler);
        addElementHandler(utilityNetworkTypeHandler);
        addElementHandler(relatedPartyRoleHandler);
        addElementHandler(new StandaardDiepteleggingHandler());
    }

    @Override
    boolean canHandle(QName element) {
        return Elements.UTILITEITSNET.equals(element);
    }

    @Override
    public QName getInspireType() {
        return Elements.INSPIRE_UTILITY_NETWORK;
    }

    @Override
    List<ValidationRule> getValidationRules() {
        final List<ValidationRule> validationRules = super.getValidationRules();
        validationRules.add(new ValidationRule(Elements.IMKL_IDENTIFICATIE).withImklStrictlyMandatory());
        validationRules.add(new ValidationRule(Elements.UTILITYNETWORKTYPE).withImklStrictlyMandatory());
        return validationRules;
    }

    @Override
    protected Utiliteitsnet createDomainObject() {
        return new Utiliteitsnet();
    }

    @Override
    protected QName getBaseElement() {
        return Elements.UTILITEITSNET;
    }
}
