package nl.kadaster.klic.win.feature.actualiseren.report;

import nl.kadaster.klic.win.model.StatistiekRegel;

import java.util.List;

public interface StatisticReportService {

    void createReport(final String bronhoudercode, final List<StatistiekRegel> statistiekregels);

}