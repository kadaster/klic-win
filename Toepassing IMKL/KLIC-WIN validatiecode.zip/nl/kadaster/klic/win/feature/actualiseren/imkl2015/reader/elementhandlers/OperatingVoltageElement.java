package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.KabelOfLeiding;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxHelper;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.stream.events.StartElement;
import java.util.Collections;
import java.util.List;

public class OperatingVoltageElement extends AbstractElementHandler implements ElementHandler<KabelOfLeiding> {

    private static final List<String> ALLOWED_UOM_VALUES = Collections.singletonList(
            "urn:ogc:def:uom:OGC::V"
    );

    @Override
    public boolean shouldHandle(StartElement element) {
        return sameQName(Elements.OPERATING_VOLTAGE, element.getName());
    }

    @Override
    public void handle(StartElement element, FeatureLinks featureLinks, KabelOfLeiding kabelOfLeiding, StaxEventReader staxEventReader, ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        final Double operatingVoltage = StaxHelper.readDouble(staxEventReader);
        UomAttributeHandler.handleErrorIfUomIsNotOneOfTheAllowedValues(element, kabelOfLeiding, validationMessageBuilder, ALLOWED_UOM_VALUES);
        kabelOfLeiding.setOperatingVoltage(operatingVoltage);
        kabelOfLeiding.setSeenElementValue(Elements.OPERATING_VOLTAGE, element.getLocation().getLineNumber(), operatingVoltage != null);
    }
}
