package nl.kadaster.klic.win.feature.actualiseren.imkl2015.storage;

import nl.kadaster.klic.util.EnumUtil;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.FeatureWithValidation;
import nl.kadaster.klic.win.feature.domain.imkl2015.ImklFeatureType;
import nl.kadaster.klic.win.storage.BaseRowMapper;

import java.sql.SQLException;

class FeatureRowMapper extends BaseRowMapper<FeatureWithValidation> {

    private static final String FIELD_ID = "id";
    private static final String FIELD_GMLID = "gmlid";
    private static final String FIELD_BRONHOUDERCODE = "bronhoudercode";
    private static final String FIELD_FEATURETYPE_ID = "featuretype_id";
    private static final String FIELD_CURRENTSTATUS = "currentstatus";
    private static final String FIELD_WIONTHEMA = "wionthema";
    private static final String FIELD_TYPE = "type";
    private static final String FIELD_LABEL = "label";
    private static final String FIELD_BESTAND_ID = "bestand_id";
    private static final String FIELD_AANGRIJPING_HORIZONTAAL = "aangrijping_horizontaal";
    private static final String FIELD_AANGRIJPING_VERTICAAL = "aangrijping_verticaal";

    @Override
    protected FeatureWithValidation mapRow() throws SQLException {
        // Geometry is NOT passed to the domain object. This can be done in the future when appropriate.
        FeatureWithValidation feature = new FeatureWithValidation();
        feature.setId(getLong(FIELD_ID));
        feature.setGmlId(getString(FIELD_GMLID));
        feature.setBronhoudercode(getString(FIELD_BRONHOUDERCODE));
        ImklFeatureType featuretype = EnumUtil.getEnumOptionFromKey(ImklFeatureType.class, getLong(FIELD_FEATURETYPE_ID).intValue());
        feature.setFeatureType(featuretype);
        feature.setCurrentStatus(getString(FIELD_CURRENTSTATUS));
        feature.setWionthema(getLong(FIELD_WIONTHEMA));
        feature.setType(getString(FIELD_TYPE));
        feature.setLabel(getString(FIELD_LABEL));
        feature.setBestandIdentificator(getString(FIELD_BESTAND_ID));
        feature.setAangrijpingHorizontaal(getString(FIELD_AANGRIJPING_HORIZONTAAL));
        feature.setAangrijpingVerticaal(getString(FIELD_AANGRIJPING_VERTICAAL));
        return feature;
    }
}
