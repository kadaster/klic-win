package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.FeatureWithValidationDomainObject;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxHelper;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.validation.BronhouderCodeValidator;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;
import org.springframework.beans.factory.annotation.Autowired;

import javax.xml.stream.events.StartElement;

public class BronhouderCodeHandler extends AbstractElementHandler implements ElementHandler<FeatureWithValidationDomainObject> {

    @Autowired
    private BronhouderCodeValidator bronhouderCodeValidator;

    @Override
    public boolean shouldHandle(final StartElement element) {
        return sameQName(Elements.BRONHOUDERCODE, element.getName());
    }

    @Override
    public void handle(final StartElement element, final FeatureLinks featureLinks, final FeatureWithValidationDomainObject domainObject,
                       final StaxEventReader staxEventReader, final ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        final String bronhouderCode = StaxHelper.readElementData(staxEventReader);
        domainObject.setSeenElementValue(Elements.BRONHOUDERCODE, element.getLocation().getLineNumber(), !bronhouderCode.isEmpty());
        if (!bronhouderCode.isEmpty()) {
            bronhouderCodeValidator.validateBronhouderCode(bronhouderCode, domainObject, validationMessageBuilder);
        }
    }

}
