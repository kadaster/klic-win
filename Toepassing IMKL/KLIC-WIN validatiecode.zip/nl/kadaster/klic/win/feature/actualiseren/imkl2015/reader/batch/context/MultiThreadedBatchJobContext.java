package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.context;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.data.BatchJobThreadData;

/**
 * ThreadLocal multi threaded batch job context holding the BatchJobThreadData that is distinct
 * for every thread.
 */
public final class MultiThreadedBatchJobContext {

    private static final ThreadLocal<BatchJobThreadData> VARIABLE = new ThreadLocal<>();

    private MultiThreadedBatchJobContext() {
    }

    public static void setBatchJobThreadData(final BatchJobThreadData batchJobThreadData) {
        VARIABLE.set(batchJobThreadData);
    }

    public static void unset() {
        VARIABLE.remove();
    }

    public static BatchJobThreadData getBatchJobThreadData() {
        return VARIABLE.get();
    }


}
