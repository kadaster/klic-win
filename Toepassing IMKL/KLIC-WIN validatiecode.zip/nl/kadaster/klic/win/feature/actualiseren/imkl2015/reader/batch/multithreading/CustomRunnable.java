package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.multithreading;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.BatchJobParameter;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.context.BatchJobContext;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.context.BatchJobThreadContext;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.context.MultiThreadedBatchJobContext;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.data.BatchJobThreadData;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.scope.context.JobSynchronizationManager;

/**
 * Custom Runnable implementation to support ThreadLocal attributes (BatchJobThreadData).
 * And alongside a fix for a bug in Spring Batch in regard to the Job Scope by registering this thread
 * with the Spring Batch Excecution explicitly.
 *
 * @link https://jira.spring.io/browse/BATCH-2269
 */
class CustomRunnable implements Runnable {

    private final BatchJobThreadContext batchJobThreadContext;
    private final BatchJobContext batchJobContext;
    private JobExecution jobExecution;
    private Runnable task;

    CustomRunnable(final BatchJobContext batchJobContext, final BatchJobThreadContext batchJobThreadContext) {
        this.batchJobContext = batchJobContext;
        this.batchJobThreadContext = batchJobThreadContext;
    }

    public CustomRunnable with(final JobExecution jobExecution, final Runnable task) {
        this.jobExecution = jobExecution;
        this.task = task;
        return this;
    }

    @Override
    public void run() {
        // Register the job execution with this thread
        JobSynchronizationManager.register(jobExecution);

        final Long actualisatieId = jobExecution.getJobParameters().getLong(BatchJobParameter.KEY_ACTUALISATIE_ID);

        try {
            // Initialize new batch job tread data (containing all properties that need to be treadsafe)
            MultiThreadedBatchJobContext.setBatchJobThreadData(
                    batchJobThreadContext.getBatchJobThreadData(
                            batchJobContext.getBatchJobData(actualisatieId)));
            // Run the task
            task.run();
        } finally {
            // When the thread is finished processing, appendThreadJobData the thread job data with the overall batch job data
            final BatchJobThreadData batchJobThreadData = MultiThreadedBatchJobContext.getBatchJobThreadData();
            if (batchJobThreadData != null) {
                batchJobContext.getBatchJobData(actualisatieId).appendThreadJobData(batchJobThreadData);
            }
            // Close synchronization manager for this thread
            JobSynchronizationManager.close();

            // Unset the threaded batch job context (especially important when using thread pools)
            MultiThreadedBatchJobContext.unset();
        }

    }
}
