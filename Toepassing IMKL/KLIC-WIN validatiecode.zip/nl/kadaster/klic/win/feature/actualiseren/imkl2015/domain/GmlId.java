package nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain;

import org.apache.commons.lang.StringUtils;

import java.util.Objects;

public final class GmlId {

    // Only valid namespace that is allowed
    private static final String NAMESPACE_IMKL = "nl.imkl";
    private static final String NAMESPACE_IMKL_LOCALID_HYPHEN = "-";
    private static final String EMPTY_STRING = "";

    private final String namespace;
    private final LocalId localId;
    private final boolean valid;

    public GmlId(final String namespace, final String localId) {
        this.namespace = namespace;
        this.localId = new LocalId(localId);
        valid =  NAMESPACE_IMKL.equalsIgnoreCase(namespace) && this.localId.isValid();
    }

    public GmlId(final String gmlIdString) {
        if (StringUtils.isNotEmpty(gmlIdString) && gmlIdString.length() > 1
                && gmlIdString.contains(NAMESPACE_IMKL_LOCALID_HYPHEN)) {
            final int indexNamespaceHypen = gmlIdString.indexOf(NAMESPACE_IMKL_LOCALID_HYPHEN);
            namespace = gmlIdString.substring(0, indexNamespaceHypen);
            localId = new LocalId(gmlIdString.substring(indexNamespaceHypen + 1));
        } else {
            namespace = null;
            localId = new LocalId(EMPTY_STRING);
        }
        valid =  NAMESPACE_IMKL.equalsIgnoreCase(namespace) && localId.isValid();
    }

    public String getNamespace() {
        return namespace;
    }

    public LocalId getLocalId() {
        return localId;
    }

    public String getId() {
        if (valid) {
            return namespace + NAMESPACE_IMKL_LOCALID_HYPHEN + localId.getLocalIdString();
        }
        return EMPTY_STRING;
    }

    public boolean isForBronhouderCode(final String bronhoudercode) {
        return localId.getBronhouderCode().equals(bronhoudercode);
    }

    public boolean isValid() {
        return valid;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        final GmlId gmlId = (GmlId) o;
        return valid == gmlId.valid &&
                Objects.equals(namespace, gmlId.namespace) &&
                Objects.equals(localId, gmlId.localId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(namespace, localId, valid);
    }
}
