package nl.kadaster.klic.win.feature.actualiseren.imkl2015.xml;

public class XmlRootElement {

    private static final String XML_DECLARATION_UTF8 = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";

    private final String startTag;
    private final String endTag;

    XmlRootElement(final String startTag, final String endTag) {
        this.startTag = startTag;
        this.endTag = endTag;
    }

    public static String getXmlDeclarationUtf8() {
        return XML_DECLARATION_UTF8;
    }

    public String getStartTag() {
        return startTag;
    }

    public String getEndTag() {
        return endTag;
    }
}
