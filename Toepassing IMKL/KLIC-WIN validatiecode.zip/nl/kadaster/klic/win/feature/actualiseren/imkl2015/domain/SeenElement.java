package nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain;

import javax.xml.namespace.QName;

public class SeenElement {

    private final QName name;
    private final int lineNumber;
    private final boolean valueSet;

    SeenElement(final QName name, final int lineNumber, final boolean valueSet) {
        this.lineNumber = lineNumber;
        this.name = name;
        this.valueSet = valueSet;
    }

    public QName getName() {
        return name;
    }

    public int getLineNumber() {
        return lineNumber;
    }

    public boolean isValueSet() {
        return valueSet;
    }
}
