package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.inspireelements;

import javax.xml.namespace.QName;

public interface InspireConvertibleElementProvider {

    boolean isConvertible(final QName baseElement);

    QName getInspireElement(final QName baseElement);
}
