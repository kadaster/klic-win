package nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain;


public class Appurtenance extends ImklFeatureWithValidationDomainObject {

    private String utiliteitsnetInspireId;
    private String point;
    private String appurtenanceType;
    private Boolean bovengrondsZichtbaar;
    private String geoNauwkeurigheidXY;
    private Integer hoogte;

    public Appurtenance() {
        super();
    }

    public String getUtiliteitsnetInspireId() {
        return utiliteitsnetInspireId;
    }

    public void setUtiliteitsnetInspireId(String utiliteitsnetInspireId) {
        this.utiliteitsnetInspireId = utiliteitsnetInspireId;
    }

    public String getPoint() {
        return point;
    }

    public void setPoint(String point) {
        this.point = point;
    }

    public String getAppurtenanceType() {
        return appurtenanceType;
    }

    public void setAppurtenanceType(String appurtenanceType) {
        this.appurtenanceType = appurtenanceType;
    }

    public Boolean getBovengrondsZichtbaar() {
        return bovengrondsZichtbaar;
    }

    public void setBovengrondsZichtbaar(Boolean bovengrondsZichtbaar) {
        this.bovengrondsZichtbaar = bovengrondsZichtbaar;
    }

    @Override
    public String getGeoNauwkeurigheidXY() {
        return geoNauwkeurigheidXY;
    }

    @Override
    public void setGeoNauwkeurigheidXY(String geoNauwkeurigheidXY) {
        this.geoNauwkeurigheidXY = geoNauwkeurigheidXY;
    }

    public Integer getHoogte() {
        return hoogte;
    }

    public void setHoogte(Integer hoogte) {
        this.hoogte = hoogte;
    }
}
