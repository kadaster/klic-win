package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.netinformatie;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.BestandLocatieHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NiBestandLocatieHandler extends BestandLocatieHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(NiBestandLocatieHandler.class);

    @Override
    protected void validateBestandLocatie(String bestandLocatie, String gmlId, ValidationMessageBuilder validationMessageBuilder) {
        LOGGER.debug("bestandLocatie: {}", bestandLocatie);

        // No validation of the content is needed, as the BestandLocatie-element is not allowed when InformatieSoort is
        // Netinformatie. The presence of this element is handled using a ValidationRule

    }
}
