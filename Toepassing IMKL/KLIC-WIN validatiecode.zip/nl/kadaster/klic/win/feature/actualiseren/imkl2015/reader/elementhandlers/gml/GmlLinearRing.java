package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.gml;

import java.util.List;

import org.postgis.Point;

class GmlLinearRing {

    private static final String OPENING_BRACKET = "(";
    private static final String CLOSING_BRACKET = ")";
    private static final String SPACE = " ";
    private static final String COMMA = ",";
    private final List<Point> points;
    private boolean isInterior;
    
    GmlLinearRing(final List<Point> points) {
        this.points = points;
    }
    
    void setInterior(final boolean isInterior) {
        this.isInterior = isInterior;
    }

    public boolean isInterior() {
        return isInterior;
    }

    public List<Point> getPoints() {
        return points;
    }

    String toEWKT() {
        StringBuilder buff = new StringBuilder();
        boolean comma = false;
        buff.append(OPENING_BRACKET);
        for (Point point: points) {
            if (comma) {
                buff.append(COMMA);
            }
            buff.append(point.getX());
            buff.append(SPACE);
            buff.append(point.getY());
            comma = true;
        }
        buff.append(CLOSING_BRACKET);
        return buff.toString();
    }
}
