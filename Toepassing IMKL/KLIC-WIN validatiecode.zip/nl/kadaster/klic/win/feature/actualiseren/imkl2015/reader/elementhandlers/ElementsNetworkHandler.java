package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.Utiliteitsnet;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.stream.events.StartElement;

public class ElementsNetworkHandler extends AbstractElementHandler implements ElementHandler<Utiliteitsnet> {
    @Override
    public boolean shouldHandle(StartElement element) {
        return sameQName(Elements.ELEMENTS_NETWORK, element.getName());
    }

    @Override
    public void handle(StartElement element, FeatureLinks featureLinks, Utiliteitsnet utiliteitsnet, StaxEventReader staxEventReader, ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        // TODO vastleggen van deze links naar child-features
    }
}
