package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ValidationRule;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

public class LabelValuePresenceValidationRuleFactory {

    public static ValidationRule createValidationRule() {
        ValidationRule rule = new ValidationRule(Elements.LABEL).withOneSubElementIsStrictlyMandatoryIfElementExists();
        rule.getSubElements().add(Elements.AANGRIJPING_HORIZONTAAL);
        rule.getSubElements().add(Elements.AANGRIJPING_VERTICAAL);
        return rule;
    }
}
