package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ImklFeatureWithValidationDomainObject;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxHelper;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.stream.events.StartElement;
import java.util.Collections;
import java.util.List;

import static nl.kadaster.klic.win.feature.common.util.gml.Elements.PRESSURE;

public class PressureElement extends AbstractElementHandler implements ElementHandler<ImklFeatureWithValidationDomainObject> {

    private static final List<String> ALLOWED_UOM_VALUES = Collections.singletonList(
            "urn:ogc:def:uom:OGC::bar"
    );

    @Override
    public boolean shouldHandle(StartElement element) {
        return sameQName(PRESSURE, element.getName());
    }

    @Override
    public void handle(StartElement element, FeatureLinks featureLinks, ImklFeatureWithValidationDomainObject kabelOfLeiding, StaxEventReader staxEventReader, ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        final Double pressure = StaxHelper.readDouble(staxEventReader);
        UomAttributeHandler.handleErrorIfUomIsNotOneOfTheAllowedValues(element, kabelOfLeiding, validationMessageBuilder, ALLOWED_UOM_VALUES);
        kabelOfLeiding.setSeenElementValue(Elements.PRESSURE, element.getLocation().getLineNumber(), pressure != null);
        // no need to set any value
    }
}
