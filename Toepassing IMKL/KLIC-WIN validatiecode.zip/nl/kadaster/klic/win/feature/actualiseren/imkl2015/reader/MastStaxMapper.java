package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.PoleHeightElement;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.namespace.QName;

public class MastStaxMapper extends AbstractContainerLeidingElementStaxMapper {

    @Override
    boolean canHandle(final QName element) {
        return Elements.MAST.equals(element);
    }

    @Override
    public QName getInspireType() {
        return Elements.INSPIRE_POLE;
    }

    @Override
    void initElementHandlers() {
        super.initElementHandlers();
        addElementHandler(new PoleHeightElement());
    }

    @Override
    protected QName getBaseElement() {
        return Elements.MAST;
    }

}
