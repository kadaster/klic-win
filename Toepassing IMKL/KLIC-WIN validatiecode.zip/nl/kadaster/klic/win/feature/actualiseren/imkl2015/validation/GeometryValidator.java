package nl.kadaster.klic.win.feature.actualiseren.imkl2015.validation;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import org.postgis.PGgeometry;

public interface GeometryValidator {
    boolean validateGeometry(final PGgeometry geometry, final ValidationMessageBuilder validationMessageBuilder, final String gmlId);
    boolean validateBboxGeometry(final PGgeometry geometry, final ValidationMessageBuilder validationMessageBuilder, final String gmlId);
}
