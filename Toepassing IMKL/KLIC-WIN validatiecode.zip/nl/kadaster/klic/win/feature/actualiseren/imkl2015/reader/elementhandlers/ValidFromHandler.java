package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.FeatureWithValidationDomainObject;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxHelper;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.stream.events.StartElement;

public class ValidFromHandler extends AbstractElementHandler implements ElementHandler<FeatureWithValidationDomainObject> {

    @Override
    public boolean shouldHandle(StartElement element) {
        return sameQName(Elements.VALID_FROM, element.getName());
    }

    @Override
    public void handle(StartElement element, FeatureLinks featureLinks, FeatureWithValidationDomainObject inspireDomainObject, StaxEventReader staxEventReader, ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        inspireDomainObject.setValidFrom(StaxHelper.readDate(staxEventReader));
    }

}