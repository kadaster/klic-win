package nl.kadaster.klic.win.feature.actualiseren.imkl2015.storage;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.GmlObject;

import java.util.List;

public interface InspireGmlObjectDao {

    void store(final GmlObject gmlObject);
    void storeBatch(List<GmlObject> inspireGmlObjectList);

    /**
     * Creates a view that just shows the inspire_gml_objects in the order.
     * Used by deegree-webservices
     *
     * @param orderId The id of the order (bestelling)
     */
    void createViewForOrder(final long orderId);

    List<String> getInspireInvolvedNetbeheerders(final String wktArea);
    
}
