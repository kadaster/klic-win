package nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain;

import nl.kadaster.klic.win.feature.domain.imkl2015.ImklFeatureType;

public class Diepte extends ImklFeatureWithValidationDomainObject {
    
    private final Peil dieptePeil = new Peil();
    private final Peil maaiveldPeil = new Peil();
    
    private String diepteNauwkeurigheid;
    
    public Peil getDieptePeil() {
        return dieptePeil;
    }

    public Peil getMaaiveldPeil() {
        return maaiveldPeil;
    }

    public String getDiepteNauwkeurigheid() {
        return diepteNauwkeurigheid;
    }
    
    public void setDiepteNauwkeurigheid(final String diepteNauwkeurigheid) {
        this.diepteNauwkeurigheid = diepteNauwkeurigheid;
    }
    
    public boolean isDiepteTovMaaiveld() {
        return ImklFeatureType.DIEPTE_TOV_MAAIVELD.equals(getImklFeatureType());
    }

}
