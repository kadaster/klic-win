package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.domain.FeatureItem;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.NamespaceHelper;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.QNameHelper;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.StaxMapperException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.AanleveringCharacteristics;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;
import org.apache.commons.lang3.CharEncoding;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Namespace;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;
import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.List;

public class ImklReader {

    private static final Logger LOG = LoggerFactory.getLogger(ImklReader.class);
    private static final String ERR_XML_INCORRECT = "De xml is niet correct en kan daardoor niet worden ingelezen.";
    private static final ThreadLocal<XMLInputFactory> THREAD_LOCAL_XML_INPUT_FACTORY = new ThreadLocal<XMLInputFactory>() {
        @Override
        protected XMLInputFactory initialValue() {
            return XMLInputFactory.newInstance();
        }
    };

    private final StaxMapperFactory mapperFactory;

    public ImklReader(final StaxMapperFactory staxMapperFactory) {
        assert staxMapperFactory != null;
        mapperFactory = staxMapperFactory;
    }

    public void read(final FeatureItem featureItem, final ValidationMessageBuilder validationMessageBuilder, final AanleveringCharacteristics aanleveringCharacteristics) throws XMLException {
        try {
            readFeature(featureItem, validationMessageBuilder, aanleveringCharacteristics);
        } catch (XMLStreamException e) {
            LOG.error("Error reading imkl stream", e);
            throw new XMLException(ERR_XML_INCORRECT, e);
        } catch (StaxMapperException e) {
            LOG.error("Error processing the XML", e);
            if (validationMessageBuilder.getErrorCount() == 0) {
                throw new XMLException(ERR_XML_INCORRECT, e);
            }
        } catch (DataAccessException dae) {
            LOG.error("Error accessing data in the database", dae);
        }
    }

    private static XMLInputFactory getThreadLocalInstanceXMLInputFactory() {
        return THREAD_LOCAL_XML_INPUT_FACTORY.get();
    }

    private void readFeature(final FeatureItem featureItem, final ValidationMessageBuilder validationMessageBuilder,
                             final AanleveringCharacteristics aanleveringCharacteristics) throws XMLStreamException, StaxMapperException {
        XMLEventReader eventReader = getThreadLocalInstanceXMLInputFactory().createXMLEventReader(new ByteArrayInputStream(featureItem.getXmlString().getBytes()), CharEncoding.UTF_8);
        List<Namespace> globalNamespaces = readFeatureCollectionHeader(eventReader);
        while (eventReader.hasNext()) {
            XMLEvent event = eventReader.nextTag();
            if (event.isStartElement() && !QNameHelper.sameQName(event.asStartElement().getName(), Elements.FEATUREMEMBER)) {
                readFeature(featureItem, validationMessageBuilder, eventReader, globalNamespaces, event.asStartElement(), aanleveringCharacteristics);
                // When the featuremember is read, we can evacuate immediately. We only process one featuremember at a time.
                // So no need to look any further.
                break;
            }
        }
    }

    private void readFeature(final FeatureItem featureItem, final ValidationMessageBuilder validationMessageBuilder,
                             final XMLEventReader eventReader, final List<Namespace> globalNamespaces, final StartElement startElement,
                             final AanleveringCharacteristics aanleveringCharacteristics) throws StaxMapperException {

        @SuppressWarnings("rawtypes")
        StaxMapper mapper = mapperFactory.getMapperForElement(startElement.getName());
        if (mapper != null) {
            mapper.readFeatureMember(featureItem, eventReader, startElement, globalNamespaces, validationMessageBuilder, aanleveringCharacteristics);
        } else {
            validationMessageBuilder.addWarningUnknownFeatureType(startElement.getName().toString());
        }
    }

    @SuppressWarnings("unchecked")
    private static List<Namespace> readFeatureCollectionHeader(final XMLEventReader eventReader) throws XMLStreamException {
        List<Namespace> globalNamespaces = new ArrayList<>();
        while (eventReader.hasNext()) {
            XMLEvent event = eventReader.nextEvent();
            if (event.isStartElement() && QNameHelper.sameQName(event.asStartElement().getName(), Elements.FEATURECOLLECTION)) {
                globalNamespaces = NamespaceHelper.toList(event.asStartElement().getNamespaces());
                break;
            }
        }
        return globalNamespaces;
    }
}
