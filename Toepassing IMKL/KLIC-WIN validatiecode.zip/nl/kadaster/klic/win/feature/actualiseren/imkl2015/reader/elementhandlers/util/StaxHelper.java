package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.StaxHelperConfigurationException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.util.XmlGregorianCalendarUtils;
import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.namespace.QName;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;
import java.util.regex.Pattern;

public final class StaxHelper {

    private static final String ERR_DATE_FORMAT = "Er is een foutief geformatteerde datum aangetroffen in de xml. Foutieve datum: %s";
    private static final String ERR_MISSING_ELEMENT = "Op de plaats waar een element '%s' verwacht wordt, is deze niet aangetroffen in de xml.";

    private static final String EMPTY_STRING = "";
    private static final String COLON_STRING = ":";
    private static final String OF_STRING = " of ";

    private static final Pattern PATTERN = Pattern.compile("\n", Pattern.LITERAL);

    private static final DatatypeFactory DATATYPEFACTORY;
    static{
        try {
            DATATYPEFACTORY = DatatypeFactory.newInstance();
        } catch (DatatypeConfigurationException e) {
            throw new StaxHelperConfigurationException("Unable to initialize DatatypeFactory!", e);
        }
    }

    private StaxHelper() {
    }

    public static boolean isNoEndElement(final XMLEvent event, final QName element) {
        return !event.isEndElement() || !event.asEndElement().getName().equals(element);
    }

    private static boolean isNoStartElement(final XMLEvent event, final QName element) {
        return !event.isStartElement() || !event.asStartElement().getName().equals(element);
    }

    private static boolean areNoStartElements(final XMLEvent event, final QName... elements) {
        for (QName element : elements) {
            if (!isNoStartElement(event, element)) {
                return false;
            }
        }
        return true;
    }

    public static boolean containsAttribute(final XMLEvent event, final QName qName) {
        return event.isStartElement() && event.asStartElement().getAttributeByName(qName) != null;
    }

    public static void navigateToFirstElement(final StaxEventReader eventReader, final QName... elements) throws XMLException {
        findFirstElement(eventReader, elements);
    }

    public static void navigateToEndElement(final StaxEventReader eventReader, final QName element) throws XMLException {
        XMLEvent event = eventReader.nextEvent();
        while (StaxHelper.isNoEndElement(event, element)) {
            event = eventReader.nextEvent();
        }
    }

    private static void findFirstElement(final StaxEventReader eventReader, final QName... elements) throws XMLException {
        int depth = 0;
        XMLEvent event = eventReader.nextEvent();
        while (depth >= 0 && StaxHelper.areNoStartElements(event, elements)) {
            if (event.isStartElement()) {
                depth++;
            } else if (event.isEndElement()) {
                depth--;
            }
            event = eventReader.nextEvent();
        }

        if (elements.length == 1 && StaxHelper.isNoStartElement(event, elements[0])) {
            throw new XMLException(String.format(ERR_MISSING_ELEMENT, elements[0].getLocalPart()));
        } else if (StaxHelper.areNoStartElements(event, elements)) {
            throw new XMLException(String.format(ERR_MISSING_ELEMENT, getElementsDescription(elements)));
        }
    }

    private static String getElementsDescription(final QName[] elements) {
        StringBuilder elementsDescriptionBuilder = new StringBuilder(EMPTY_STRING);
        for (QName element: elements) {
            if (elementsDescriptionBuilder.length() > 0) {
                elementsDescriptionBuilder.append(OF_STRING);
            }
            elementsDescriptionBuilder.append(element.getLocalPart());
        }
        return elementsDescriptionBuilder.toString();
    }

    public static String getQName(final XMLEvent event) {
        String qname;
        if (event.isStartElement()) {
            StartElement startElement = event.asStartElement();
            qname = getQName(startElement.getName());
        } else {
            qname = EMPTY_STRING;
        }
        return qname;
    }

    public static String getQName(final QName qName) {
        String result = EMPTY_STRING;
        final String qNamePrefix = qName.getPrefix();
        if (StringUtils.isNotEmpty(qNamePrefix)){
            result = qNamePrefix + COLON_STRING;
        }
        result += qName.getLocalPart();
        return result;
    }

    public static String readElementData(final StaxEventReader eventReader) throws XMLException {
        String elementData;
        XMLEvent event = eventReader.nextEvent();
        if (event.isCharacters()) {
            elementData = event.asCharacters().getData();
            eventReader.nextEvent();
        } else {
            elementData = EMPTY_STRING;
        }
        return elementData;
    }

    public static DateTime readDate(final StaxEventReader eventReader) throws XMLException {
        DateTime date = null;
        String dateAsString = PATTERN.matcher(StaxHelper.readElementData(eventReader)).replaceAll(EMPTY_STRING);
        if (StringUtils.isNotEmpty(dateAsString)) {
            try {
                date = XmlGregorianCalendarUtils.convertToDateTime(
                        DATATYPEFACTORY.newXMLGregorianCalendar(dateAsString)
                );
            } catch (IllegalArgumentException iae) {
                throw new XMLException(String.format(ERR_DATE_FORMAT, dateAsString), iae);
            }
        }
        return date;
    }

    public static boolean readBoolean(final StaxEventReader eventReader) throws XMLException {
        String boolAsString = StaxHelper.readElementData(eventReader);
        return toBoolean(boolAsString);
    }

    public static Integer readInteger(final StaxEventReader eventReader) throws XMLException {
        String intAsString = StaxHelper.readElementData(eventReader);
        return Integer.parseInt(intAsString);
    }

    public static Double readDouble(final StaxEventReader eventReader) throws XMLException {
        String doubleAsString = StaxHelper.readElementData(eventReader);
        if (StringUtils.isNotEmpty(doubleAsString)) {
            return Double.parseDouble(doubleAsString);
        }
        return null;
    }

    public static boolean toBoolean(final String boolAsString) {
        return !"0".equals(boolAsString) &&
                ("1".equals(boolAsString) || Boolean.parseBoolean(boolAsString));
    }
}
