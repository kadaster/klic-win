package nl.kadaster.klic.win.feature.actualiseren.imkl2015.storage;

public interface PartitionDao {

    void dropSaIndexes(String bronhoudercode);
    void createSaIndexes(String bronhoudercode);
    
    void dropSaConstraints(String bronhoudercode);
    void createSaConstraints(String bronhoudercode);
    void dropSaPartitionConstraints(String bronhoudercode);
 
    void truncateSa(String bronhoudercode);
    void exchangePartitions(String bronhoudercode);
    void recreateSaViews();

}
