package nl.kadaster.klic.win.feature.actualiseren.imkl2015.storage;

import java.util.List;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.GmlObject;

public interface WionGmlObjectDao {
    
    void storeBatch(final List<GmlObject> gmlObjects);

}
