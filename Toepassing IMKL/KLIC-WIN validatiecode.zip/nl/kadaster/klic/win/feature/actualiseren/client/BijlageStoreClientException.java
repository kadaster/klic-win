package nl.kadaster.klic.win.feature.actualiseren.client;

public class BijlageStoreClientException extends RuntimeException {

    public BijlageStoreClientException(final String message) {
        super(message);
    }
}
