package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import javax.xml.namespace.QName;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.DatumOpmetingMaaiveldPeilHandler;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.MaaiveldPeilHandler;

public class DiepteNapStaxMapper extends AbstractDiepteStaxMapper {

    @Override
    void initElementHandlers() {
        super.initElementHandlers();
        addElementHandler(new MaaiveldPeilHandler());
        addElementHandler(new DatumOpmetingMaaiveldPeilHandler());
    }

    @Override
    boolean canHandle(final QName element) {
        return Elements.DIEPTE_NAP.equals(element);
    }

    @Override
    QName getBaseElement() {
        return Elements.DIEPTE_NAP;
    }

}
