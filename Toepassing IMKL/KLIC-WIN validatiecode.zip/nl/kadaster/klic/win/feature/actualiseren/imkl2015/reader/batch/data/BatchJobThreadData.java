package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.data;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.ImklReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.validation.ImklValidator;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.validation.ImklValidatorException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.xml.validation.Validator;

/**
 * Data object holding all data collected by threads that are executing the batch job in parallel.
 * Currently only the chunk parts (see package batch/chunk)
 */
public class BatchJobThreadData extends BatchJobData {

    private static final Logger LOG = LoggerFactory.getLogger(BatchJobThreadData.class);

    private final ImklValidator imklValidator;
    private final ImklReader imklReader;
    private Validator validator;

    public BatchJobThreadData(final BatchJobData batchJobData,
                              final ImklValidator imklValidator, final ImklReader imklReader) {
        super(batchJobData.getInformatieSoort(), batchJobData.getBronhoudercode(), batchJobData.getActualisatieId(), batchJobData.getFilename(),
              batchJobData.getBatchSize(), batchJobData.getPoolSize(), batchJobData.getValidationMessagesTracker());
        this.imklValidator = imklValidator;
        this.imklReader = imklReader;
        getFilesInZipFile().addAll(batchJobData.getFilesInZipFile());
        createValidator(getValidationMessageBuilder());
    }

    public Validator getValidator() {
        return validator;
    }

    public ImklReader getImklReader() {
        return imklReader;
    }

    private void createValidator(final ValidationMessageBuilder validationMessageBuilder) {
        try {
            validator = imklValidator.createValidator(validationMessageBuilder);
        } catch (ImklValidatorException e) {
            LOG.error("Unable to initialize IMKL Validator (XML)", e);
            throw new ExceptionInInitializerError(e);

        }
    }
}
