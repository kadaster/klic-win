package nl.kadaster.klic.win.feature.actualiseren.imkl2015.storage;

import nl.kadaster.klic.win.feature.domain.imkl2015.DatabaseConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.GmlObject;
import nl.kadaster.klic.win.util.NiStoreUtil;

import java.util.List;

public class InspireGmlObjectDaoImpl implements InspireGmlObjectDao {

    private static final String TABLENAME_INSPIRE_GML_OBJECTS = "inspire_gml_objects";

    private static final String QUERY_GET_INSPIRE_INVOLVED_NETBEHEERDERS_BY_AREA = "" +
            "SELECT DISTINCT bronhoudercode" +
            "  FROM " + NiStoreUtil.getCdbTableName(TABLENAME_INSPIRE_GML_OBJECTS) +
            "  WHERE ST_Intersects(geometry, ST_GeomFromText(?, 28992))";

    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Autowired
    private GmlObjectDaoHelper gmlObjectDaoHelper;
    
    @Override
    public void store(final GmlObject gmlObject) {
        gmlObjectDaoHelper.store(TABLENAME_INSPIRE_GML_OBJECTS, gmlObject);
    }

    @Override
    public void storeBatch(final List<GmlObject> gmlObjects) {
        gmlObjectDaoHelper.storeBatch(TABLENAME_INSPIRE_GML_OBJECTS, gmlObjects);
    }
    
    @Override
    public List<String> getInspireInvolvedNetbeheerders(final String wktArea) {
        return jdbcTemplate.queryForList(QUERY_GET_INSPIRE_INVOLVED_NETBEHEERDERS_BY_AREA, new Object[]{ wktArea }, String.class);
    }

    @Override
    public void createViewForOrder(final long orderId) {
        jdbcTemplate.update(createViewStatement(orderId));
        jdbcTemplate.update(createGrantStatement(orderId));
    }

    private static String createViewStatement(final long orderId) {
        return "CREATE VIEW " + getLeveringViewName(orderId) + " AS " //
                + " SELECT * " //
                + " FROM " + DatabaseConstants.LEVERING_SCHEMA + "." + TABLENAME_INSPIRE_GML_OBJECTS //
                + " WHERE order_id = " + orderId //
                ;
    }

    private static String createGrantStatement(final long orderId) {
        return "GRANT SELECT ON " + getLeveringViewName(orderId) + " TO " + DatabaseConstants.LEVERING_USER;
    }

    private static String getLeveringViewName(final long orderId) {
        return DatabaseConstants.LEVERING_SCHEMA + "." + TABLENAME_INSPIRE_GML_OBJECTS + "_" + orderId;
    }
}

