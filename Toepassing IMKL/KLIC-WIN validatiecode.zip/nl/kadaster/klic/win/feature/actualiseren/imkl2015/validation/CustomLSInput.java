package nl.kadaster.klic.win.feature.actualiseren.imkl2015.validation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.ls.LSInput;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;

class CustomLSInput implements LSInput {

    private static final Logger LOG = LoggerFactory.getLogger(CustomLSInput.class);

    private String publicId;
    private String systemId;
    private final BufferedInputStream inputStream;

    public CustomLSInput(String publicId, String sysId, InputStream input) {
        this.publicId = publicId;
        this.systemId = sysId;
        this.inputStream = new BufferedInputStream(input);
    }

    @Override
    public String getPublicId() {
        return publicId;
    }

    @Override
    public void setPublicId(String publicId) {
        this.publicId = publicId;
    }

    @Override
    public String getBaseURI() {
        return null;
    }

    @Override
    public InputStream getByteStream() {
        return null;
    }

    @Override
    public boolean getCertifiedText() {
        return false;
    }

    @Override
    public Reader getCharacterStream() {
        return null;
    }

    @Override
    public String getEncoding() {
        return null;
    }

    @Override
    public String getStringData() {
        synchronized (inputStream) {
            try {
                byte[] input = new byte[inputStream.available()];
                //noinspection ResultOfMethodCallIgnored
                inputStream.read(input);
                return new String(input);
            } catch (IOException e) {
                LOG.error("Failed reading XSD from file system: " + systemId, e);
            }
            return null;
        }
    }

    @Override
    public void setBaseURI(String baseURI) {
        // Not needed
    }

    @Override
    public void setByteStream(InputStream byteStream) {
        // Not needed
    }

    @Override
    public void setCertifiedText(boolean certifiedText) {
        // Not needed
    }

    @Override
    public void setCharacterStream(Reader characterStream) {
        // Not needed
    }

    @Override
    public void setEncoding(String encoding) {
        // Not needed
    }

    @Override
    public void setStringData(String stringData) {
        // Not needed
    }

    @Override
    public String getSystemId() {
        return systemId;
    }

    @Override
    public void setSystemId(String systemId) {
        this.systemId = systemId;
    }

    public BufferedInputStream getInputStream() {
        return inputStream;
    }
}