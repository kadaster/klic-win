package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.context;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.data.BatchJobData;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Consolidated data holder for a single batch job.
 * Consolidated data is collected during execution of all tasks of a batch job.
 */
public class BatchJobContext {

    private final Map<Long /*actualisatieId*/, BatchJobData> data = new ConcurrentHashMap<>(10);

    public void init(final BatchJobData batchJobData) {
        data.put(batchJobData.getActualisatieId(), batchJobData);
    }

    public BatchJobData getBatchJobData(final long actualisatieId) {
        return data.get(actualisatieId);
    }

    public void clean(final long actualisatieId) {
        data.remove(actualisatieId);
    }
}
