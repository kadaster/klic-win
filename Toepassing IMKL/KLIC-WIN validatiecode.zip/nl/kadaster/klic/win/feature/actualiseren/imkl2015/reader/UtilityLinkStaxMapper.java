package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.UtilityLink;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ValidationRule;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.*;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;
import org.springframework.beans.factory.annotation.Autowired;

import javax.xml.namespace.QName;
import java.util.List;

public class UtilityLinkStaxMapper extends StaxMapper<UtilityLink> {

    @Autowired
    private CurrentStatusHandler currentStatusHandler;

    @Override
    void initElementHandlers() {
        super.initElementHandlers();
        addElementHandler(new InNetworkNetworkHandler());
        addElementHandler(new InspireIdHandler());
        addElementHandler(new CentrelineGeometryHandler());
        addElementHandler(new FictitiousHandler());
        addElementHandler(new ValidFromHandler());
        addElementHandler(new VerticalPositionHandler());
        addElementHandler(currentStatusHandler);
    }

    @Override
    public boolean canHandle(final QName element) {
        return Elements.UTILITY_LINK.equals(element);
    }

    @Override
    public QName getInspireType() {
        return Elements.UTILITY_LINK;
    }

    @Override
    List<ValidationRule> getValidationRules() {
        final List<ValidationRule> validationRules = super.getValidationRules();
        validationRules.add(new ValidationRule(Elements.INSPIRE_ID).withImklStrictlyMandatory());
        return validationRules;
    }

    @Override
    protected UtilityLink createDomainObject() {
        return new UtilityLink();
    }

    @Override
    protected QName getBaseElement() {
        return Elements.UTILITY_LINK;
    }
}
