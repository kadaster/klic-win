package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.context.BatchJobContext;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.data.BatchJobData;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.exception.ImklImportBatchJobException;
import nl.kadaster.klic.win.feature.domain.ImportImklAanleveringResult;
import nl.kadaster.klic.win.model.ValidationMessage;
import nl.kadaster.klic.win.feature.domain.InformatieSoort;
import org.apache.commons.lang3.time.DurationFormatUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

public class ImklImportBatchJobRunner {

    private static final Logger LOG = LoggerFactory.getLogger(ImklImportBatchJobRunner.class);

    private static final String SEPARATOR_LINE = "-------------------------------------------------------------------------";
    private static final String MAIN_SEPARATOR_LINE = "=========================================================================";

    private final Job featureImport;
    private final JobLauncher jobLauncher;

    private final BatchJobContext batchJobContext;

    @Autowired
    public ImklImportBatchJobRunner(final Job featureImport, final JobLauncher jobLauncher, final BatchJobContext batchJobContext) {
        this.featureImport = featureImport;
        this.jobLauncher = jobLauncher;
        this.batchJobContext = batchJobContext;
    }

    /**
     * Called from Oracle queue handler, so always one thread concurrently processing
     */
    public void run(
            final InformatieSoort informatieSoort,
            final String bronhoudercode,
            final long actualisatieId,
            final ImportImklAanleveringResult result,
            final String filename)
            throws ImklImportBatchJobException {
        JobParametersBuilder paramBuilder = new JobParametersBuilder();
        paramBuilder.addString(BatchJobParameter.KEY_BRONHOUDERCODE, bronhoudercode);
        paramBuilder.addLong(BatchJobParameter.KEY_ACTUALISATIE_ID, actualisatieId);
        paramBuilder.addString(BatchJobParameter.KEY_FILENAME, filename);
        paramBuilder.addLong(BatchJobParameter.KEY_BATCH_SIZE, BatchJobSettings.BATCH_SIZE);
        paramBuilder.addString(BatchJobParameter.KEY_INFORMATIESOORT, informatieSoort.name());

        try {
            final JobExecution jobExecution = jobLauncher.run(featureImport, paramBuilder.toJobParameters());
            final BatchJobData batchJobData = batchJobContext.getBatchJobData(actualisatieId);

            handleCallbackResult(batchJobData, result);
            logResult(batchJobData, jobExecution, result);

        } catch (JobExecutionAlreadyRunningException e) {
            throw new ImklImportBatchJobException("There is already an import job running", e);
        } catch (JobRestartException e) {
            throw new ImklImportBatchJobException("Restarting the import job is not supported", e);
        } catch (JobInstanceAlreadyCompleteException e) {
            throw new ImklImportBatchJobException("The import job is already completed", e);
        } catch (JobParametersInvalidException e) {
            throw new ImklImportBatchJobException("Invalid parameters provided for the import job", e);
        } finally {
            batchJobContext.clean(actualisatieId);
        }
    }

    private static void handleCallbackResult(final BatchJobData batchJobData, final ImportImklAanleveringResult result) {
        final List<ValidationMessage> validationMessages = batchJobData.getValidationMessageBuilder().getValidationMessagesSorted();
        result.getValidationMessages().addAll(validationMessages);
        result.getStatistiekRegels().addAll(batchJobData.getStatistiekregels());
    }

    private static void logResult(final BatchJobData batchJobData, final JobExecution jobExecution, final ImportImklAanleveringResult result) {
        if (LOG.isInfoEnabled()) {
            StringBuilder sb = new StringBuilder(System.lineSeparator());
            sb.append(MAIN_SEPARATOR_LINE).append(System.lineSeparator());
            sb.append(">>                   Finished processing of features                   <<").append(System.lineSeparator());
            sb.append(SEPARATOR_LINE).append(System.lineSeparator());

            logStatus(batchJobData, jobExecution, sb);
            logImportStepExecution(batchJobData, jobExecution, result, sb);
            logTimings(batchJobData, jobExecution, sb);

            sb.append(MAIN_SEPARATOR_LINE).append(System.lineSeparator());
            LOG.info(sb.toString());
        }
    }

    private static void logStatus(final BatchJobData batchJobData, final JobExecution jobExecution, final StringBuilder sb) {
        sb.append("File                                        : ").append(batchJobData.getFilename()).append(System.lineSeparator());
        sb.append("Status                                      : ").append(jobExecution.getStatus()).append(System.lineSeparator());
        sb.append("Informatie soort                            : ").append(batchJobData.getInformatieSoort()).append(System.lineSeparator());
        sb.append(SEPARATOR_LINE).append(System.lineSeparator());
    }

    private static void logTimings(final BatchJobData batchJobData, final JobExecution jobExecution, final StringBuilder sb) {
        final int poolSize = batchJobData.getPoolSize();
        final long totalExecutionTimeMs = jobExecution.getEndTime().getTime() - jobExecution.getStartTime().getTime();
        final long averageXmlValidationTimeInMs = batchJobData.getTotalXmlValidationTimeInMilliseconds() / poolSize;
        final long averageValidatedImportTimeInMs = batchJobData.getTotalValidatedImportTimeInMilliseconds() / poolSize;
        final long averageDatabaseInsertTimeInMilliseconds = batchJobData.getTotalDatabaseInsertTimeInMilliseconds() / poolSize;
        final long totalDatabasePostUpdateTimeInMilliseconds = batchJobData.getTotalDatabasePostUpdateTimeInMilliseconds();

        if (InformatieSoort.NETINFORMATIE == batchJobData.getInformatieSoort()) {
            // only applicable to aanleveren netinformatie
            final long averageDocumentReferenceCheckingTimeInMilliseconds = batchJobData.getTotalDocumentReferenceCheckingTimeInMilliseconds() / poolSize;
            sb.append("Average DOC ref checking time (per thread)  : ").append(DurationFormatUtils.formatDurationHMS(averageDocumentReferenceCheckingTimeInMilliseconds)).append(System.lineSeparator());
        }

        sb.append("Average XML validation time (per thread)    : ").append(DurationFormatUtils.formatDurationHMS(averageXmlValidationTimeInMs)).append(System.lineSeparator());
        sb.append("Average Validated import time (per thread)  : ").append(DurationFormatUtils.formatDurationHMS(averageValidatedImportTimeInMs)).append(System.lineSeparator());
        sb.append("Average DB insert time  (per thread)        : ").append(DurationFormatUtils.formatDurationHMS(averageDatabaseInsertTimeInMilliseconds)).append(System.lineSeparator());
        sb.append("Total DB post update time                   : ").append(DurationFormatUtils.formatDurationHMS(totalDatabasePostUpdateTimeInMilliseconds)).append(System.lineSeparator());
        sb.append("Total Batch Execution time                  : ").append(DurationFormatUtils.formatDurationHMS(totalExecutionTimeMs)).append(System.lineSeparator());
    }

    private static void logImportStepExecution(final BatchJobData batchJobData, final JobExecution jobExecution, final ImportImklAanleveringResult result, final StringBuilder sb) {
        final long totalExecutionTimeMs = jobExecution.getEndTime().getTime() - jobExecution.getStartTime().getTime();
        final int poolSize = batchJobData.getPoolSize();
        for (StepExecution step : jobExecution.getStepExecutions()) {
            if ("import".equals(step.getStepName())) {

                if (InformatieSoort.NETINFORMATIE == batchJobData.getInformatieSoort()) {
                    // only applicable to aanleveren netinformatie
                    final long totalDocumentReferenceCheckedCount = batchJobData.getTotalDocumentReferenceCheckedCount();
                    sb.append("Nr of documents checked (dostore)           : ").append(totalDocumentReferenceCheckedCount).append(System.lineSeparator());
                }

                sb.append("Nr of feature members read                  : ").append(step.getReadCount()).append(System.lineSeparator());
                final int writeCount = step.getWriteCount();
                sb.append("Nr of feature members written               : ").append(writeCount).append(System.lineSeparator());
                sb.append("Nr of concurrent processing threads         : ").append(poolSize).append(System.lineSeparator());
                sb.append("Batched commit-count                        : ").append(step.getCommitCount()).append(" (on ").append(poolSize).append(" concurrent threads)").append(System.lineSeparator());
                sb.append("Batch size                                  : ").append(batchJobData.getBatchSize()).append(System.lineSeparator());

                double nrOfFeaturesPerSecond = 0d;
                if (writeCount > 0 && totalExecutionTimeMs > 0) {
                    nrOfFeaturesPerSecond = BigDecimal.valueOf(writeCount / (totalExecutionTimeMs / 1000d))
                            .setScale(2, RoundingMode.HALF_EVEN).doubleValue();
                }
                sb.append("Features per second                         : ").append(nrOfFeaturesPerSecond).append(System.lineSeparator());
                result.setFeaturesPerSecond((int)nrOfFeaturesPerSecond);
                result.setItemsProcessed(writeCount);
                break;
            }
        }
        sb.append(SEPARATOR_LINE).append(System.lineSeparator());
    }

}
