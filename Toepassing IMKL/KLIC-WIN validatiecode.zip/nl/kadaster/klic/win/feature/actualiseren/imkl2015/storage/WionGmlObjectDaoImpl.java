package nl.kadaster.klic.win.feature.actualiseren.imkl2015.storage;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.GmlObject;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class WionGmlObjectDaoImpl implements WionGmlObjectDao {

    private static final String TABLENAME_WION_GML_OBJECTS = "wion_gml_objects";
    
    @Autowired
    private GmlObjectDaoHelper gmlObjectDaoHelper;

    @Override
    public void storeBatch(final List<GmlObject> gmlObjects) {
        gmlObjectDaoHelper.storeBatch(TABLENAME_WION_GML_OBJECTS, gmlObjects);
    }

}
