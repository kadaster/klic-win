package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ExtraDetailInfo;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.namespace.QName;

public class ExtraInfoTypeHandler extends AbstractCodelistElementHandler<ExtraDetailInfo> {

    private static final String CODELIST_NAME_IMKL = "ExtraDetailInfoTypeValue";

    @Override
    protected QName getHandlingElement() {
        return Elements.EXTRAINFOTYPE;
    }

    @Override
    protected void preValidate() {
        setCodelist(CODELIST_NAME_IMKL);
    }

    @Override
    protected void postValidate(final ExtraDetailInfo extraDetailInfo, final String xLinkCodelistValue) {
        String extraInfoType = getCodelistValue(xLinkCodelistValue);
        extraDetailInfo.setExtraInfoType(extraInfoType);
        extraDetailInfo.setType(extraInfoType);
    }

}
