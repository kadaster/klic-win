package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.EigenTopografie;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.namespace.QName;

public class ImklStatusHandler extends AbstractCodelistElementHandler<EigenTopografie> {

    private static final String CODELIST_NAME_IMKL = "EigenTopografieStatusValue";

    @Override
    protected QName getHandlingElement() {
        return Elements.IMKL_STATUS;
    }

    @Override
    protected void preValidate() {
        setCodelist(CODELIST_NAME_IMKL);
    }

    @Override
    protected void postValidate(final EigenTopografie eigenTopografie, final String xLinkCodelistValue) {
        eigenTopografie.setCurrentStatus(getCodelistValue(xLinkCodelistValue));
    }
}
