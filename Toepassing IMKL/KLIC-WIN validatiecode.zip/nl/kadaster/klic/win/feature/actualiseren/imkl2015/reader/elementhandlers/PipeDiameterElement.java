package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import java.util.Arrays;
import java.util.List;

import javax.xml.stream.events.StartElement;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ImklFeatureWithValidationDomainObject;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxHelper;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

public class PipeDiameterElement extends AbstractElementHandler implements ElementHandler<ImklFeatureWithValidationDomainObject> {

    private static final List<String> ALLOWED_UOM_VALUES = Arrays.asList(
            "urn:ogc:def:uom:OGC::mm",
            "urn:ogc:def:uom:OGC::cm",
            "urn:ogc:def:uom:OGC::m"
    );

    @Override
    public boolean shouldHandle(StartElement element) {
        return sameQName(Elements.PIPE_DIAMETER, element.getName());
    }

    @Override
    public void handle(StartElement element, FeatureLinks featureLinks, ImklFeatureWithValidationDomainObject kabelOfLeiding, StaxEventReader staxEventReader, ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        UomAttributeHandler.handleErrorIfUomIsNotOneOfTheAllowedValues(element, kabelOfLeiding, validationMessageBuilder, ALLOWED_UOM_VALUES);
        StaxHelper.readDouble(staxEventReader); // check format
        // no need to set any value
    }
}
