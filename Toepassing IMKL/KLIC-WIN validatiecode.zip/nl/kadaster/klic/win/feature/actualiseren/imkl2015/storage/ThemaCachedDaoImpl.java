package nl.kadaster.klic.win.feature.actualiseren.imkl2015.storage;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.Thema;
import nl.kadaster.klic.win.util.NiStoreUtil;

public class ThemaCachedDaoImpl implements ThemaDao {

    private static final String TABLENAME = "thema";
    private static final String QUERY_THEMAS = "select id, code from " + NiStoreUtil.getCdbTableName(TABLENAME);

    private static final Map<String, Long> THEMACACHE = new HashMap<>();

    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    @Override
    public Long getThemaId(String thema) {
        if (THEMACACHE.isEmpty()) {
            readThemasFromDatabase();
        }
        return THEMACACHE.get(thema);
    }

    private synchronized void readThemasFromDatabase() {
        List<Thema> themaObjects = jdbcTemplate.query(QUERY_THEMAS, new ThemaRowMapper());
        for (Thema thema: themaObjects) {
            THEMACACHE.put(thema.getThema(), thema.getId());
        }
    }

}
