package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.inspireelements;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.GmlId;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.InspireId;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.QNameHelper;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxHelper;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.stream.XMLEventFactory;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class XLinkConverter implements InspireElementConverter {

    private static final String PREFIX_LOCAL_XLINK = "#";
    private static final String ERR_INVALID_XLINK_HREF = "Er is een hyperlink-referentie van een featuremember met gml-id: %s naar een ander featuremember aangetroffen dat niet valide is: %s.";
    private final XMLEventFactory xmlEventFactory = XMLEventFactory.newInstance();
    private MappedFeaturetypeProvider inspireIdTypeProvider;

    @Override
    public boolean shouldHandle(final StartElement element) {
        return (QNameHelper.sameQName(Elements.INNETWORK_NETWORK, element.getName()) ||
                QNameHelper.sameQName(Elements.CABLES, element.getName()) ||
                QNameHelper.sameQName(Elements.LINK_NETWORK, element.getName()))
                && StaxHelper.containsAttribute(element, Elements.ATTR_XLINK_HREF);
    }

    @Override
    public boolean shouldHandle(final EndElement element) {
        return false;
    }

    @Override
    public XMLEvent convertStartElement(final StartElement element) throws XMLException {
        return createElementWithUpdatedLink(element);
    }

    private StartElement createElementWithUpdatedLink(final StartElement baseElement) throws XMLException {
        List<Attribute> attributes = new ArrayList<>();
        @SuppressWarnings("unchecked")
        Iterator<Attribute> iterator = baseElement.getAttributes();
        while (iterator.hasNext()) {
            Attribute baseAttribute = iterator.next();
            if (QNameHelper.sameQName(Elements.ATTR_XLINK_HREF, baseAttribute.getName())) {
                attributes.add(xmlEventFactory.createAttribute(baseAttribute.getName(), createXlinkHref(baseAttribute.getValue())));
            } else {
                attributes.add(baseAttribute);
            }
        }
        return xmlEventFactory.createStartElement(baseElement.getName(), attributes.iterator(), baseElement.getNamespaces());
    }

    private String createXlinkHref(final String originalHref) throws XMLException {
        InspireId linkedInspireId = inspireIdTypeProvider.findInspireId(originalHref);
        if (linkedInspireId == null) {
            String gmlIdDomainObject = "no feature";
            throw new XMLException(String.format(ERR_INVALID_XLINK_HREF, gmlIdDomainObject, originalHref), gmlIdDomainObject);
        }
        return PREFIX_LOCAL_XLINK + new GmlId(linkedInspireId.getNamespace(), linkedInspireId.getLocalId()).getId();
    }


    public void setInspireIdTypeProvider(final MappedFeaturetypeProvider inspireIdTypeProvider) {
        this.inspireIdTypeProvider = inspireIdTypeProvider;
    }

    @Override
    public XMLEvent convertEndElement(final EndElement element) {
        return null;
    }

}
