package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception;

public class StaxMapperException extends Exception {

    private static final long serialVersionUID = 366949644209918308L;

    public StaxMapperException(final String message, final Throwable cause) {
        super(message, cause);
    }
}
