package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation;

public class AanleveringCharacteristicsValidator {

    public void validate(final AanleveringCharacteristics aanleveringCharacteristics, final ValidationMessageBuilder validationMessageBuilder) {
        eigenTopoVerbodenIgvNietBetrokken(aanleveringCharacteristics, validationMessageBuilder);
        eisVoorzorgsmaatregelBijlageVerbodenIgvNietBetrokken(aanleveringCharacteristics, validationMessageBuilder);
        eisVoorzorgsmaatregelBijlageIsVerplichtBijEisvoorzorgsmaatregel(aanleveringCharacteristics, validationMessageBuilder);
        eisVoorzorgsmaatregelVerbodenIgvNietBetrokken(aanleveringCharacteristics, validationMessageBuilder);
        eisNetinformatieVerbodenIgvNietBetrokken(aanleveringCharacteristics, validationMessageBuilder);
        eisNetinformatieVerplichtIgvBetrokken(aanleveringCharacteristics, validationMessageBuilder);
    }

    private static void eisVoorzorgsmaatregelVerbodenIgvNietBetrokken(final AanleveringCharacteristics aanleveringCharacteristics,
                                                                      final ValidationMessageBuilder validationMessageBuilder) {
        if (!aanleveringCharacteristics.isBetrokken() && aanleveringCharacteristics.isBelanghebbendeHasEisVoorzorgsmaatregel()) {
            validationMessageBuilder.addErrorNoEisVoorzorgsmaatregelAllowedWhenNietBetrokken();
        }
    }

    private static void eigenTopoVerbodenIgvNietBetrokken(final AanleveringCharacteristics aanleveringCharacteristics,
                                                          final ValidationMessageBuilder validationMessageBuilder) {
        if (!aanleveringCharacteristics.isBetrokken() && aanleveringCharacteristics.hasEigenTopo()) {
            validationMessageBuilder.addErrorNoEigenTopoAllowedWhenNietBetrokken();
        }
    }

    private static void eisVoorzorgsmaatregelBijlageVerbodenIgvNietBetrokken(final AanleveringCharacteristics aanleveringCharacteristics,
                                                                             final ValidationMessageBuilder validationMessageBuilder) {
        if (!aanleveringCharacteristics.isBetrokken() && aanleveringCharacteristics.hasEisVoorzorgsmaatregelBijlage()) {
            validationMessageBuilder.addErrorNoBijlageEisVoorzorgsmaatregelAllowedWhenNietBetrokken();
        }
    }

    private static void eisVoorzorgsmaatregelBijlageIsVerplichtBijEisvoorzorgsmaatregel(final AanleveringCharacteristics aanleveringCharacteristics,
                                                                                        final ValidationMessageBuilder validationMessageBuilder) {
        if (aanleveringCharacteristics.isBelanghebbendeHasEisVoorzorgsmaatregel() && !aanleveringCharacteristics.hasEisVoorzorgsmaatregelBijlage()) {
            validationMessageBuilder.addErrorBijlageEisVoorzorgsmaatregelCompulsory();
        }
    }

    private static void eisNetinformatieVerbodenIgvNietBetrokken(final AanleveringCharacteristics aanleveringCharacteristics,
                                                                 final ValidationMessageBuilder validationMessageBuilder) {
        if (!aanleveringCharacteristics.isBetrokken() && aanleveringCharacteristics.hasUtiliteitsnet()) {
            validationMessageBuilder.addErrorNoNetinformatieAllowedWhenNietBetrokken();
        }
    }

    private static void eisNetinformatieVerplichtIgvBetrokken(final AanleveringCharacteristics aanleveringCharacteristics,
                                                              final ValidationMessageBuilder validationMessageBuilder) {
        if (aanleveringCharacteristics.isBetrokken() && !aanleveringCharacteristics.hasUtiliteitsnet()) {
            validationMessageBuilder.addErrorUtiliteitsnetCompulsoryWhenBetrokken();
        }
    }
}
