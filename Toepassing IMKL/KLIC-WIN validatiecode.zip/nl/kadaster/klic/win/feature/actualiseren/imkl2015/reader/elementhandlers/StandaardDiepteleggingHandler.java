package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.Utiliteitsnet;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxHelper;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;
import org.apache.commons.lang.StringUtils;

import javax.xml.stream.events.StartElement;
import java.util.Collections;
import java.util.List;

public class StandaardDiepteleggingHandler extends AbstractElementHandler implements ElementHandler<Utiliteitsnet> {

    private static final List<String> ALLOWED_UOM_VALUES = Collections.singletonList(
            "urn:ogc:def:uom:OGC::m"
    );
    private static final String DECIMAL_SEPARATOR = ".";

    @Override
    public boolean shouldHandle(StartElement element) {
        return sameQName(Elements.STANDAARDDIEPTELEGGING, element.getName());
    }

    @Override
    public void handle(StartElement element, FeatureLinks featureLinks, Utiliteitsnet utiliteitsnet, StaxEventReader staxEventReader, ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        UomAttributeHandler.handleErrorIfUomIsNotOneOfTheAllowedValues(element, utiliteitsnet, validationMessageBuilder, ALLOWED_UOM_VALUES);
        final String depth = StaxHelper.readElementData(staxEventReader);
        if (hasMoreThanTwoDecimals(depth)) {
            validationMessageBuilder.addErrorInvalidNumberOfDecimalsInStandaardDieptelegging(utiliteitsnet.getGmlId());
        }
    }

    protected boolean hasMoreThanTwoDecimals(String depth) {
        return StringUtils.substringAfter(depth, DECIMAL_SEPARATOR).length() > 2;
    }
}
