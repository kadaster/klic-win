package nl.kadaster.klic.win.feature.actualiseren.imkl2015.storage;

import nl.kadaster.klic.win.feature.domain.imkl2015.DatabaseConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

/**
 * Manage the partitions with Enterprise DB. 
 */
public class PartitionDaoImpl implements PartitionDao {
    
    private static final String BRONHOUDERCODE_PARAM = "in_bronhoudercode";

    private static final String PROC_DROP_SA_INDEXES = "drop_sa_indexes";
    private static final String PROC_CREATE_SA_INDEXES = "create_sa_indexes";
    private static final String PROC_CREATE_SA_CONSTRAINTS = "create_sa_constraints";
    private static final String PROC_DROP_SA_CONSTRAINTS = "drop_sa_constraints";
    private static final String PROC_DROP_SA_PARTITION_CONSTRAINTS = "drop_sa_partition_constraints";
    private static final String PROC_TRUNCATE_SA = "truncate_sa";
    private static final String PROC_EXCHANGE_PARTITIONS = "exchange_partitions";
    private static final String PROC_RECREATE_SA_VIEWS = "recreate_sa_views";
    
    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    @Override
    public void dropSaIndexes(String bronhoudercode) {
        callProc(PROC_DROP_SA_INDEXES, bronhoudercode);
    }

    @Override
    public void createSaIndexes(final String bronhoudercode) {
        callProc(PROC_CREATE_SA_INDEXES, bronhoudercode);
    }
    
    @Override
    public void dropSaConstraints(String bronhoudercode) {
        callProc(PROC_DROP_SA_CONSTRAINTS, bronhoudercode);
    }
    
    @Override
    public void dropSaPartitionConstraints(final String bronhoudercode) {
        callProc(PROC_DROP_SA_PARTITION_CONSTRAINTS, bronhoudercode);
    }
    
    @Override
    public void createSaConstraints(final String bronhoudercode) {
        callProc(PROC_CREATE_SA_CONSTRAINTS, bronhoudercode);
    }

    @Override
    public void truncateSa(String bronhoudercode) {
        callProc(PROC_TRUNCATE_SA, bronhoudercode);
        
    }

    @Override
    public void exchangePartitions(final String bronhoudercode) {
        callProc(PROC_EXCHANGE_PARTITIONS, bronhoudercode);
    }
    
    @Override
    public void recreateSaViews() {
        final SimpleJdbcCall func = new SimpleJdbcCall(jdbcTemplate).withSchemaName(DatabaseConstants.NI_STORE).withProcedureName(PROC_RECREATE_SA_VIEWS);
        func.execute();
    }
    
    private void callProc(final String procname, final String bronhoudercode) {
        final SimpleJdbcCall func = new SimpleJdbcCall(jdbcTemplate).withSchemaName(DatabaseConstants.NI_STORE).withProcedureName(procname);
        final MapSqlParameterSource params = new MapSqlParameterSource();

        params.addValue(BRONHOUDERCODE_PARAM, bronhoudercode);
        func.execute(params);
    }
   
}
