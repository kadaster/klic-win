package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation;

public class AanleveringCharacteristics {

    private boolean hasEigenTopo = false;
    private boolean isBetrokken = false;
    private boolean hasNietBetrokkenBijlage = false;
    private boolean hasEisVoorzorgsmaatregelBijlage = false;
    private boolean hasUtiliteitsnet = false;
    // Value of bool element 'eisVoorzorgsmaatregel' in feature 'Belanghebbende':
    private boolean belanghebbendeHasEisVoorzorgsmaatregel = false;

    public AanleveringCharacteristics() {
        super();
    }

    public boolean hasEigenTopo() {
        return hasEigenTopo;
    }

    public void setHasEigenTopo(final boolean hasEigenTopo) {
        this.hasEigenTopo = hasEigenTopo;
    }

    public boolean isBetrokken() {
        return isBetrokken;
    }

    public void setBetrokken(final boolean betrokken) {
        isBetrokken = betrokken;
    }

    public boolean isHasNietBetrokkenBijlage() {
        return hasNietBetrokkenBijlage;
    }

    public void setHasNietBetrokkenBijlage(final boolean hasNietBetrokkenBijlage) {
        this.hasNietBetrokkenBijlage = hasNietBetrokkenBijlage;
    }

    public boolean hasEisVoorzorgsmaatregelBijlage() {
        return hasEisVoorzorgsmaatregelBijlage;
    }

    public void setHasEisVoorzorgsmaatregelBijlage(final boolean hasEisVoorzorgsmaatregelBijlage) {
        this.hasEisVoorzorgsmaatregelBijlage = hasEisVoorzorgsmaatregelBijlage;
    }

    public boolean isBelanghebbendeHasEisVoorzorgsmaatregel() {
        return belanghebbendeHasEisVoorzorgsmaatregel;
    }

    public void setBelanghebbendeHasEisVoorzorgsmaatregel(final boolean belanghebbendeHasEisVoorzorgsmaatregel) {
        this.belanghebbendeHasEisVoorzorgsmaatregel = belanghebbendeHasEisVoorzorgsmaatregel;
    }

    public boolean hasUtiliteitsnet() {
        return hasUtiliteitsnet;
    }

    public void setHasUtiliteitsnet(final boolean hasUtiliteitsnet) {
        this.hasUtiliteitsnet = hasUtiliteitsnet;
    }
}
