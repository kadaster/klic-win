package nl.kadaster.klic.win.feature.actualiseren.imkl2015.storage;

import nl.kadaster.klic.win.util.NiStoreUtil;
import nl.kadaster.klic.win.feature.domain.imkl2015.FeatureLink;
import nl.kadaster.klic.win.feature.domain.imkl2015.ImklFeatureType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

public class FeatureLinkDaoImpl implements FeatureLinkDao {

    private static final String TABLENAME = "feature_link";
    private static final String FEATURE_TABLE = "feature";

    private static final String FEATURE_LINK_SA_PLACEHOLDER = NiStoreUtil.SA_PLACEHOLDER1;
    private static final String FEATURE_SA_PLACEHOLDER = NiStoreUtil.SA_PLACEHOLDER2;

    private static final String SQL_INSERT_CONCEPT = "insert into " + FEATURE_LINK_SA_PLACEHOLDER + " ( " //
            + "  bronhoudercode"
            + ", featureid"
            + ", gmlid"
            + ", linkedgmlid"
            + ", featuretype_id"
            + ", is_kabelofleiding"
            + ", is_containerleidingelement"
            + ", is_ductkabelbed) values ("
            + " ?"
            + ",?"
            + ",?"
            + ",?"
            + ",?"
            + ",?"
            + ",?"
            + ",?"
            + ")";

    private static final String SQL_UPDATE_CONCEPT_FEATURE_ATTRIBUTES_OF_LINKED_FEATURES =
            "UPDATE " + FEATURE_LINK_SA_PLACEHOLDER + " fl " +
                    "SET linkedfeatureid=ft.id " +
                    "   ,wionthema=wthema.code_short " +
                    "   ,inspirethema=ithema.code_short " +
                    "FROM " + FEATURE_SA_PLACEHOLDER +" as ft, ni_store.thema as wthema, ni_store.thema as ithema " +
                    "WHERE fl.linkedgmlid = ft.gmlid " +
                    "AND ft.bronhoudercode = ? " +
                    "AND wthema.id = ft.wionthema " +
                    "AND ithema.id = ft.inspirethema ";

    private static final String SQL_UPDATE_CONCEPT_FEATURE_THEMAS =
            "WITH cte_utiliteitsnet (gmlid, wionthema, inspirethema) AS (" +
                    "   SELECT ft.gmlid, ft.wionthema, ft.inspirethema " +
                    "     FROM " + FEATURE_SA_PLACEHOLDER + " ft" +
                    "    WHERE ft.bronhoudercode = ? " +
                    "      AND ft.featuretype_id  = " + ImklFeatureType.UTILITEITSNET.getKey() +
                    ") " +
                    "UPDATE " + FEATURE_SA_PLACEHOLDER + " ft" +
                    "   SET wionthema    = cte_utiliteitsnet.wionthema" +
                    "     , inspirethema = cte_utiliteitsnet.inspirethema " +
                    "  FROM " + FEATURE_LINK_SA_PLACEHOLDER + " fl " +
                    "  JOIN cte_utiliteitsnet ON fl.linkedgmlid = cte_utiliteitsnet.gmlid" +
                    " WHERE ft.id = fl.featureid";

    private static final String SQL_QUERY_CONCEPT_LINKS_WITHOUT_LINKED_FEATURE_ID =
            "SELECT * FROM " + FEATURE_LINK_SA_PLACEHOLDER + " WHERE bronhoudercode = ? AND linkedfeatureid IS NULL";
    
    private static final String SQL_DELETE_CONCEPT_LINKS_WITHOUT_LINKED_FEATURE_ID =
            "DELETE FROM " + FEATURE_LINK_SA_PLACEHOLDER + " WHERE bronhoudercode = ? AND linkedfeatureid IS NULL";

    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    @Override
    public void storeBatch(final List<FeatureLink> featureLinks) {
        String sql;
        String bronhoudercode;
        
        if (featureLinks.isEmpty()) {
            return;
        }
        bronhoudercode = featureLinks.get(0).getBronhoudercode();
        sql = NiStoreUtil.adaptQueryForStagingArea(bronhoudercode, SQL_INSERT_CONCEPT, TABLENAME);
        jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps, int i) throws SQLException {
                FeatureLink featureLink = featureLinks.get(i);
                int pos = 1;
                ps.setString(pos++, featureLink.getBronhoudercode());
                ps.setLong(pos++, featureLink.getFeatureId());
                ps.setString(pos++, featureLink.getGmlidFeaturemember());
                ps.setString(pos++, featureLink.getGmlidLinkedFeaturemember());
                ps.setLong(pos++, featureLink.getLinkedImklFeatureType().getKey());
                ps.setBoolean(pos++, featureLink.isKabelOfLeiding());
                ps.setBoolean(pos++, featureLink.isContainerleidingElement());
                ps.setBoolean(pos, featureLink.isDuctOfKabelbed());
            }

            @Override
            public int getBatchSize() {
                return featureLinks.size();
            }
        });
    }

    @Override
    public void updateWithLinkedFeatureIds(final String bronhoudercode) {
        String sql = NiStoreUtil.adaptQueryForStagingArea(bronhoudercode, SQL_UPDATE_CONCEPT_FEATURE_ATTRIBUTES_OF_LINKED_FEATURES, TABLENAME, FEATURE_TABLE);
        jdbcTemplate.update(sql, bronhoudercode);
    }

    @Override
    public List<FeatureLink> getWhereMissingLinkedFeatureIds(final String bronhoudercode) {
        String sql = NiStoreUtil.adaptQueryForStagingArea(bronhoudercode, SQL_QUERY_CONCEPT_LINKS_WITHOUT_LINKED_FEATURE_ID, TABLENAME);
        return jdbcTemplate.query(sql, new Object[]{bronhoudercode}, new FeaturelinkRowMapper());
    }

    @Override
    public void deleteWhereMissingLinkedFeatureIds(final String bronhoudercode) {
        String sql = NiStoreUtil.adaptQueryForStagingArea(bronhoudercode, SQL_DELETE_CONCEPT_LINKS_WITHOUT_LINKED_FEATURE_ID, TABLENAME);
        jdbcTemplate.update(sql, bronhoudercode);
    }
    
    @Override
    public void updateMissingFeatureThemes(final String bronhoudercode) {
        String sql = NiStoreUtil.adaptQueryForStagingArea(bronhoudercode, SQL_UPDATE_CONCEPT_FEATURE_THEMAS, TABLENAME, FEATURE_TABLE);
        jdbcTemplate.update(sql, bronhoudercode);
    }

}
