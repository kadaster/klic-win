package nl.kadaster.klic.win.feature.actualiseren.imkl2015.storage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;

public class InspireFeatureTypeDaoImpl implements InspireFeatureTypeDao {

    private static final String SQL = "select id from ni_store.inspire_feature_types where qname=?";

    @Autowired
    private FeatureTypeDaoHelper daoHelper;

    @Cacheable(value = "featureTypes")
    @Override
    public Long findId(final String featureType) {
        return daoHelper.findId(SQL, featureType);
    }

}
