package nl.kadaster.klic.win.feature.actualiseren.imkl2015.validation;

final class XsdSchema {

    static final String IMKL_XSD = "IMKL2015-wion.xsd";

    private XsdSchema() {
        // Not instanciable
    }
}
