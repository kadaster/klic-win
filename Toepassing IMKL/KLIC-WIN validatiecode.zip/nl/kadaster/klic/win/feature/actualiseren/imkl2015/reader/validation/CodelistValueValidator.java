package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.FeatureWithValidation;
import nl.kadaster.klic.win.feature.codelist.service.CodelistVerifyService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class CodelistValueValidator {

    @Autowired
    private CodelistVerifyService codelistVerifyService;

    public boolean validateCodelistValue(final String codelistName, final String codelistValue, final ValidationMessageBuilder validationMessageBuilder, final FeatureWithValidation domainObject) {
        boolean valid = codelistVerifyService.isValid(codelistName, codelistValue);
        if (!valid) {
            addErrorMessage(codelistName, codelistValue, validationMessageBuilder, domainObject);
        }
        return valid;
    }

    public boolean validateCodelistValue(final List<String> codelistNames, final String codelistValue, final ValidationMessageBuilder validationMessageBuilder, final FeatureWithValidation domainObject) {
        boolean valid = false;
        for (String codelistName: codelistNames) {
            if (validateSilent(codelistName, codelistValue, domainObject)) {
                valid = true;
                break;
            }
        }
        if (!valid) {
            addErrorMessage(StringUtils.join(codelistNames, ", "), codelistValue, validationMessageBuilder, domainObject);
        }
        return valid;
    }

    public boolean validateRestricedCodelistValue(final String codelistName, final String codelistValue, final ValidationMessageBuilder validationMessageBuilder,
                                                  final FeatureWithValidation domainObject, final String restricedCodelistValue) {
        boolean valid = validateCodelistValue(codelistName, codelistValue, validationMessageBuilder, domainObject);
        if (valid && !codelistValue.equals(restricedCodelistValue)) {
            addErrorMessageRestricted(codelistName, codelistValue, restricedCodelistValue, validationMessageBuilder, domainObject);
        }
        return valid;
    }

    private static void addErrorMessage(final String codelistName, final String codelistValue, final ValidationMessageBuilder validationMessageBuilder, final FeatureWithValidation domainObject) {
        if (validationMessageBuilder != null) {
            String gmlId = null;
            if (domainObject != null) {
                gmlId = domainObject.getGmlId();
            }
            validationMessageBuilder.addErrorValueNotInCodelist(codelistName, codelistValue, gmlId);
        }
    }

    private static void addErrorMessageRestricted(final String codelistName, final String codelistValue, final String restricedCodelistValue, final ValidationMessageBuilder validationMessageBuilder, final FeatureWithValidation domainObject) {
        if (validationMessageBuilder != null) {
            String gmlId = null;
            if (domainObject != null) {
                gmlId = domainObject.getGmlId();
            }
            validationMessageBuilder.addErrorValueIsNotRestrictedCodelistValue(codelistName, codelistValue, restricedCodelistValue, gmlId);
        }
    }

    private boolean validateSilent(final String codelistName, final String codelistValue, final FeatureWithValidation domainObject) {
        return validateCodelistValue(codelistName, codelistValue, null, domainObject);
    }
}
