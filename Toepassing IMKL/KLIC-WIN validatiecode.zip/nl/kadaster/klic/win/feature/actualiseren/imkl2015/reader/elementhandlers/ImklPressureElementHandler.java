package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ImklFeatureWithValidationDomainObject;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;

import javax.xml.stream.events.StartElement;
import java.util.Collections;
import java.util.List;

import static nl.kadaster.klic.win.feature.common.util.gml.Elements.IMKL_PRESSURE;

public class ImklPressureElementHandler extends AbstractElementHandler implements ElementHandler<ImklFeatureWithValidationDomainObject> {

    private static final List<String> ALLOWED_UOM_VALUES = Collections.singletonList(
            "urn:ogc:def:uom:OGC::bar"
    );

    @Override
    public boolean shouldHandle(final StartElement element) {
        return sameQName(IMKL_PRESSURE, element.getName());
    }

    @Override
    public void handle(final StartElement element, final FeatureLinks featureLinks, final ImklFeatureWithValidationDomainObject kabelOfLeiding,
                       final StaxEventReader staxEventReader, final ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        UomAttributeHandler.handleErrorIfUomIsNotOneOfTheAllowedValues(element, kabelOfLeiding, validationMessageBuilder, ALLOWED_UOM_VALUES);
        // no need to set any value
    }
}
