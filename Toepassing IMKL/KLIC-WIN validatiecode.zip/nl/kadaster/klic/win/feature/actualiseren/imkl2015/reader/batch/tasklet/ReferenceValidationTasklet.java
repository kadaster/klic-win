package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.tasklet;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.context.BatchJobContext;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.domain.InformatieSoort;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ReferenceValidationTasklet implements Tasklet {

    private final BatchJobContext batchJobContext;
    private long actualisatieId;

    @Autowired
    public ReferenceValidationTasklet(final BatchJobContext batchJobContext){
        this.batchJobContext = batchJobContext;
    }

    public void setActualisatieId(final long actualisatieId) {
        this.actualisatieId = actualisatieId;
    }

    @Override
    public RepeatStatus execute(final StepContribution contribution, final ChunkContext chunkContext) throws Exception {
        if (batchJobContext.getBatchJobData(actualisatieId).getInformatieSoort() == InformatieSoort.BEHEERDERSINFORMATIE) {
            final List<String> referencedFiles = batchJobContext.getBatchJobData(actualisatieId).getFilesReferencedFromFeatures();
            final List<String> filesInZip = batchJobContext.getBatchJobData(actualisatieId).getFilesInZipFile();
            final ValidationMessageBuilder validationMessageBuilder = batchJobContext.getBatchJobData(actualisatieId).getValidationMessageBuilder();

            final Set<String> nonReferencedFiles = new HashSet<>(filesInZip);
            nonReferencedFiles.removeAll(new HashSet<>(referencedFiles));
            for (String file : nonReferencedFiles) {
                validationMessageBuilder.addErrorFileNotReferenced(file);
            }
        }

        return RepeatStatus.FINISHED;
    }
}
