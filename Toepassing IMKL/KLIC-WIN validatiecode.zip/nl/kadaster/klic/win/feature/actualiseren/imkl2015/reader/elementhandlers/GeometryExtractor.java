package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import javax.xml.namespace.QName;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import org.postgis.PGgeometry;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.FeatureWithValidationDomainObject;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.gml.GeometryParser;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.gml.GmlGeometry;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;

final class GeometryExtractor {

    private GeometryExtractor() {
    }

    public static PGgeometry extract(final QName geometryElement, final FeatureWithValidationDomainObject featureDomainObject, final StaxEventReader staxEventReader, final ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        PGgeometry pGgeometry = null;
        GmlGeometry geometry = GeometryParser.parse(geometryElement, featureDomainObject, staxEventReader, validationMessageBuilder);
        if (geometry != null) { // no validation errors
            pGgeometry =  geometry.getPGgeometry();
        }
        return pGgeometry;
    }
}
