package nl.kadaster.klic.win.feature.actualiseren.imkl2015.validation;

import javax.xml.validation.Schema;

public interface XsdSchemaCache {
    Schema getXsdSchema(final String xsd);
}
