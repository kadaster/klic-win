package nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain;

public class Utiliteitsnet extends ImklFeatureWithValidationDomainObject {

    private String naam;
    private String telefoon;
    private String email;
    private String geographicalName;
    private String utilityNetworkType;
    private String utilityFacilityReference;
    private String disclaimer;
    private String eisVoorzorgsmaatregel;
    private String thema;
    private String label;
    private String omschrijving;

    public Utiliteitsnet() {
        super();
    }

    public String getNaam() {
        return naam;
    }

    public void setNaam(String naam) {
        this.naam = naam;
    }

    public String getTelefoon() {
        return telefoon;
    }

    public void setTelefoon(String telefoon) {
        this.telefoon = telefoon;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUtilityNetworkType() {
        return utilityNetworkType;
    }

    public void setUtilityNetworkType(String utilityNetworkType) {
        this.utilityNetworkType = utilityNetworkType;
    }

    @Override
    public String getUtilityFacilityReference() {
        return utilityFacilityReference;
    }

    @Override
    public void setUtilityFacilityReference(String utilityFacilityReference) {
        this.utilityFacilityReference = utilityFacilityReference;
    }

    public String getDisclaimer() {
        return disclaimer;
    }

    public void setDisclaimer(String disclaimer) {
        this.disclaimer = disclaimer;
    }

    public String getEisVoorzorgsmaatregel() {
        return eisVoorzorgsmaatregel;
    }

    public void setEisVoorzorgsmaatregel(String eisVoorzorgsmaatregel) {
        this.eisVoorzorgsmaatregel = eisVoorzorgsmaatregel;
    }

    public String getThema() {
        return thema;
    }

    public void setThema(String thema) {
        this.thema = thema;
    }

    @Override
    public String getLabel() {
        return label;
    }

    @Override
    public void setLabel(String label) {
        this.label = label;
    }

    @Override
    public String getOmschrijving() {
        return omschrijving;
    }

    @Override
    public void setOmschrijving(String omschrijving) {
        this.omschrijving = omschrijving;
    }

    public String getGeographicalName() {
        return geographicalName;
    }

    public void setGeographicalName(String geographicalName) {
        this.geographicalName = geographicalName;
    }

}
