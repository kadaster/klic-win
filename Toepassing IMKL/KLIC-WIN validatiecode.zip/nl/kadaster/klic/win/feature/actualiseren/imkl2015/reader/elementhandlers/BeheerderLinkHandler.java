package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ImklFeatureWithValidationDomainObject;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.stream.events.StartElement;

public class BeheerderLinkHandler extends AbstractElementHandler implements ElementHandler<ImklFeatureWithValidationDomainObject> {

    private static final String IMKL_FEATURETYPE_NAME = "Beheerder";

    @Override
    public boolean shouldHandle(final StartElement element) {
        return sameQName(Elements.BEHEERDER_LINK, element.getName());
    }

    @Override
    public void handle(final StartElement element, final FeatureLinks featureLinks, final ImklFeatureWithValidationDomainObject domainObject, final StaxEventReader staxEventReader, final ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        featureLinks.addFeatureLink(getXLink(element), domainObject, IMKL_FEATURETYPE_NAME);
    }
}
