package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.namespace.QName;

public class MangatStaxMapper extends AbstractContainerLeidingElementStaxMapper {

    @Override
    boolean canHandle(final QName element) {
        return Elements.MANGAT.equals(element);
    }

    @Override
    public QName getInspireType() {
        return Elements.INSPIRE_MANHOLE;
    }

    @Override
    protected QName getBaseElement() {
        return Elements.MANGAT;
    }

}
