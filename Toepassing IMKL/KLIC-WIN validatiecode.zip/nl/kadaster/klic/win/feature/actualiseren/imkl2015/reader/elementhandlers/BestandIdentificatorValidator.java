package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BestandIdentificatorValidator {

    private static final String NAMESPACE = "nl\\.imkl";
    private static final Pattern PATTERN = Pattern.compile("^(" + NAMESPACE + "-)(\\w+)\\.(.+)");

    void validateBestandIdentificatorFormat(final String bestandIdentificator,
                                            final String gmlId,
                                            final ValidationMessageBuilder validationMessageBuilder) {
        Matcher matcher = PATTERN.matcher(bestandIdentificator);
        String nameSpace;
        String bronhouderCode;
        if (matcher.find()) {
            nameSpace = matcher.group(1);
            bronhouderCode = matcher.group(2);
        } else {
            validationMessageBuilder.addErrorInvalidBestandIdentificatorFormat(gmlId);
            return;
        }

        // validates bronhoudercode name
        if (!gmlId.startsWith(nameSpace + bronhouderCode + ".")) {
            validationMessageBuilder.addErrorWrongBestandIdentificatorBronhoudercode(gmlId, bronhouderCode);
        }
    }
}