package nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain;

import nl.kadaster.klic.win.feature.domain.DomainObject;
import org.postgis.PGgeometry;

public class GmlObject extends DomainObject {
    
    private Long featureId;
    private String gmlId;
    private String bronhoudercode;
    private Long featureTypeId;
    private byte[] binaryObject;
    private PGgeometry geometry;
    private PGgeometry gmlBoundedBy;

    public Long getFeatureId() {
        return featureId;
    }

    public void setFeatureId(Long featureId) {
        this.featureId = featureId;
    }

    public String getGmlId() {
        return gmlId;
    }

    public void setGmlId(final String gmlId) {
        this.gmlId = gmlId;
    }

    public String getBronhoudercode() {
        return bronhoudercode;
    }

    public void setBronhoudercode(String bronhoudercode) {
        this.bronhoudercode = bronhoudercode;
    }

    public Long getFeatureTypeId() {
        return featureTypeId;
    }

    public void setFeatureTypeId(final Long featureTypeId) {
        this.featureTypeId = featureTypeId;
    }

    public byte[] getBinaryObject() {
        return binaryObject;
    }

    public void setBinaryObject(final byte[] binaryObject) {
        this.binaryObject = binaryObject;
    }

    public PGgeometry getGeometry() {
        return geometry;
    }

    public void setGeometry(final PGgeometry geometry) {
        this.geometry = geometry;
    }

    public PGgeometry getGmlBoundedBy() {
        return gmlBoundedBy;
    }

    public void setGmlBoundedBy(final PGgeometry gmlBoundedBy) {
        this.gmlBoundedBy = gmlBoundedBy;
    }
}
