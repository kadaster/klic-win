package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.FeatureWithValidationDomainObject;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxHelper;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;
import org.apache.commons.lang3.StringUtils;

import javax.xml.stream.events.StartElement;

public class VerticalPositionHandler extends AbstractElementHandler implements ElementHandler<FeatureWithValidationDomainObject> {

    @Override
    public boolean shouldHandle(StartElement element) {
        return sameQName(Elements.VERTICAL_POSITION, element.getName());
    }

    @Override
    public void handle(StartElement element, FeatureLinks featureLinks, FeatureWithValidationDomainObject inspireDomainObject, StaxEventReader staxEventReader, ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        final String verticalPosition = StaxHelper.readElementData(staxEventReader);
        if (StringUtils.isEmpty(verticalPosition)) {
            NilReasonAttributeHandler.handleWarningOnNilReasonMissing(element, inspireDomainObject, validationMessageBuilder);
        }
        inspireDomainObject.setVerticalPosition(verticalPosition);
    }
}