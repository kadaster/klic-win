package nl.kadaster.klic.win.feature.actualiseren.imkl2015.xml;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.validation.ImklValidator;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.validation.ImklValidatorException;
import org.apache.commons.io.input.BOMInputStream;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.transform.ErrorListener;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stax.StAXSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.validation.Validator;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

public class XmlIterator implements Iterator<XmlPart>, Closeable {

    private static final Logger LOG = LoggerFactory.getLogger(XmlIterator.class);
    private static final String EMPTY_STRING = "";
    private static final String COLON_STRING = ":";
    private static final String SPACE_STRING = " ";
    private static final String IS_QUOTE_STRING = "=\"";
    private static final String QUOTE_STRING = "\"";
    private static final String XMLNS_IS_QUOTE = "xmlns=\"";
    private static final String XMLNS_COLON = "xmlns:";

    private String fatalExceptionMsg;
    private final List<String> errors = new ArrayList<>();
    private final XMLStreamReader streamReader;
    private final Transformer transformer;
    private final String rootTag;
    private final String splitTag;

    private XmlRootElement xmlRootElement;
    private XmlElement xmlElement;
    private Validator imklValidator;

    XmlIterator(final InputStream inputSteam, final String rootTag, final String splitTag, final Validator imklValidator) {
        this.rootTag = rootTag;
        this.splitTag = splitTag;
        this.imklValidator = imklValidator;
        validateInput(inputSteam);
        try {
            // Use BOMInputStream with include set to false. This way the BOM (ByteOrderMark) is excluded from the inputstream
            // See https://commons.apache.org/proper/commons-io/javadocs/api-release/org/apache/commons/io/input/BOMInputStream.html
            streamReader = XMLInputFactory.newInstance().createXMLStreamReader(new BOMInputStream(inputSteam, false));
            transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setErrorListener(new ErrorListener() {
                @Override
                public void warning(final TransformerException exception) {
                    errors.add(exception.getMessage());
                }

                @Override
                public void error(final TransformerException exception) {
                    errors.add(exception.getMessage());
                }

                @Override
                public void fatalError(final TransformerException exception) throws TransformerException {
                    fatalExceptionMsg = exception.getMessage();
                    throw exception;
                }
            });
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
        } catch (TransformerConfigurationException e) {
            final String msg = "Error creating transformer";
            LOG.error(msg, e);
            throw new XmlIteratorException(msg, e);
        } catch (XMLStreamException e) {
            final String msg = "Error while reading from XML stream";
            LOG.error(msg, e);
            throw new XmlIteratorException(msg, e);
        }
    }

    private void validateInput(final InputStream inputSteam) {
        if (inputSteam == null) {
            throw new XmlIteratorException("InputStream cannot be NULL");
        }
        if (StringUtils.isEmpty(rootTag)) {
            throw new XmlIteratorException("RootTag cannot be NULL");
        }
        if (StringUtils.isEmpty(splitTag)) {
            throw new XmlIteratorException("SplitTag cannot be NULL");
        }
    }

    private void moveToNextEntry() {
        xmlElement = null;
        try {
            while (nextTag() == XMLStreamConstants.START_ELEMENT) {
                if (streamReader.isStartElement() && startElementHandled()) {
                    break;
                }
            }
        } catch (XMLStreamException e) {
            final String msg = "Error while reading from XML stream";
            LOG.error(msg, e);
            throw new XmlIteratorException(msg, e);
        } catch (ImklValidatorException e) {
            final String msg = "Error while validation non featuremember element from XML stream";
            LOG.error(msg, e);
            throw new XmlIteratorException(msg, e);
        }
    }

    private int nextTag() throws XMLStreamException {
        int eventType = streamReader.next();
        while((eventType == XMLStreamConstants.CHARACTERS)
                || (eventType == XMLStreamConstants.CDATA)
                || eventType == XMLStreamConstants.SPACE
                || eventType == XMLStreamConstants.PROCESSING_INSTRUCTION
                || eventType == XMLStreamConstants.COMMENT
                || eventType == XMLStreamConstants.END_ELEMENT
                ) {
            eventType = streamReader.next();
        }
        return eventType;
    }

    private boolean startElementHandled() throws ImklValidatorException {
        if (streamReader.getLocalName().equals(splitTag)) {
            initNextElement();
            return true;
        } else if (streamReader.getLocalName().equals(rootTag)) {
            initRootElement();
        } else {
            // Do XSD validation on elements that exist in the FeatureCollection, but are not a FeatureMember (such as 'boundedBy')
            initNextElement();
            ImklValidator.validate(imklValidator, next().getCompleteXmlPart());
            // This non feature member is handled an not needed anymore:
            xmlElement = null;
        }
        return false;
    }

    @Override
    public boolean hasNext() {
        moveToNextEntry();
        return xmlElement != null;
    }

    @Override
    public XmlPart next() {
        if (xmlElement == null) {
            throw new NoSuchElementException();
        }
        return new XmlPart(xmlRootElement, xmlElement);
    }

    @Override
    public void remove() {
        throw new UnsupportedOperationException();
    }

    @Override
    public void close() throws IOException {
        try {
            streamReader.close();
        } catch (XMLStreamException e) {
            final String message = "Unable to close XML stream";
            LOG.error(message, e);
            throw new IOException(message, e);
        }
    }

    public List<String> getErrors() {
        return errors;
    }

    private void initNextElement() {
        final int lineNumber = streamReader.getLocation().getLineNumber();
        try (StringWriter writer = new StringWriter()) {
            transformer.transform(new StAXSource(streamReader), new StreamResult(writer));
            xmlElement = new XmlElement(writer.toString(), lineNumber);
        } catch (IOException e) {
            final String msg = "Unable to create writer";
            LOG.error(msg, e);
            throw new XmlIteratorException(msg, e);
        } catch (TransformerException e) {
            final String msg = "Error during the course of the transformation from source to result.";
            LOG.error(msg, e);
            if (fatalExceptionMsg != null) {
                final String fatalMsg = "Fatal exception while iterating XML with message: " + fatalExceptionMsg;
                LOG.error(fatalMsg);
                throw new XmlIteratorException(fatalMsg, e);
            }
        }
    }

    private void initRootElement() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("<");
        addName(streamReader, stringBuilder);
        addNamespaces(streamReader, stringBuilder);
        addAttributes(streamReader, stringBuilder);
        stringBuilder.append(">");

        String rootStartTag = stringBuilder.toString();
        int index = rootStartTag.indexOf(rootTag) + rootTag.length();
        String rootEndTag = "</" + rootStartTag.substring(1, index) + ">";

        xmlRootElement = new XmlRootElement(rootStartTag, rootEndTag);
    }

    private static void addName(final XMLStreamReader xmlr, final StringBuilder stringBuilder) {
        if (xmlr.hasName()) {
            stringBuilder.append(
                    getName(xmlr.getPrefix(), xmlr.getLocalName())
            );
        }
    }

    private static String getName(final String prefix, final String localName) {
        String name = EMPTY_STRING;
        if (prefix != null) {
            name += prefix + COLON_STRING;
        }
        if (localName != null) {
            name += localName;
        }
        return name;
    }

    private static void addAttributes(final XMLStreamReader xmlr, final StringBuilder stringBuilder) {
        for (int i = 0; i < xmlr.getAttributeCount(); i++) {
            stringBuilder.append(getAttribute(xmlr, i));
        }
    }

    private static String getAttribute(final XMLStreamReader xmlr, final int index) {
        String attribute = SPACE_STRING;
        attribute += getName(xmlr.getAttributePrefix(index), xmlr.getAttributeLocalName(index));
        attribute += IS_QUOTE_STRING + xmlr.getAttributeValue(index) + QUOTE_STRING;
        return attribute;
    }

    private static void addNamespaces(final XMLStreamReader xmlr, final StringBuilder stringBuilder) {
        for (int i = 0; i < xmlr.getNamespaceCount(); i++) {
            stringBuilder.append(getNamespace(xmlr, i));
        }
    }

    private static String getNamespace(final XMLStreamReader xmlr, final int index) {
        String namespace = SPACE_STRING;
        String prefix = xmlr.getNamespacePrefix(index);
        String uri = xmlr.getNamespaceURI(index);
        if (prefix == null) {
            namespace += XMLNS_IS_QUOTE + uri + QUOTE_STRING;
        } else {
            namespace += XMLNS_COLON + prefix + IS_QUOTE_STRING + uri + QUOTE_STRING;
        }
        return namespace;
    }

}
