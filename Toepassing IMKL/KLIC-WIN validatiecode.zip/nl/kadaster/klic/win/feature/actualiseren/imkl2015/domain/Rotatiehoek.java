package nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain;

interface Rotatiehoek {
    String getRotatiehoek();
    void setRotatiehoek(final String rotatiehoek);
}
