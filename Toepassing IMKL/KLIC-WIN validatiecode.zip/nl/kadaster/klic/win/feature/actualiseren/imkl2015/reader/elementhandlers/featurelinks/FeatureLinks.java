package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.FeatureWithValidationDomainObject;
import nl.kadaster.klic.win.feature.domain.imkl2015.FeatureLink;
import nl.kadaster.klic.win.feature.domain.imkl2015.ImklFeatureType;
import org.apache.commons.lang3.StringUtils;

import javax.xml.namespace.QName;
import java.util.ArrayList;
import java.util.List;

public class FeatureLinks {

    private final QName baseElement;
    private final QName inspireType;
    private final List<FeatureLink> links;
    private final ImklFeaturetypeProvider imklFeaturetypeProvider;

    public FeatureLinks(final ImklFeaturetypeProvider imklFeaturetypeProvider, final QName baseElement, final QName inspireType) {
        super();
        this.links = new ArrayList<>();
        this.imklFeaturetypeProvider = imklFeaturetypeProvider;
        this.baseElement = baseElement;
        this.inspireType = inspireType;
    }

    public void addFeatureLink(final String xlinkRef, final FeatureWithValidationDomainObject featureDomainObject, final String imklFeatureTypeName) {
        String featureType = imklFeatureTypeName == null ? baseElement.getLocalPart() : imklFeatureTypeName;
        ImklFeatureType imklFeatureType = imklFeaturetypeProvider.getImklFeaturetype(featureType);
        String gmlidLinkedFeature = extractGmlid(xlinkRef);
        String gmlId = featureDomainObject.getGmlId();
        if (imklFeatureType != null && !StringUtils.isEmpty(gmlidLinkedFeature) && !StringUtils.isEmpty(gmlId)) {
            FeatureLink link = new FeatureLink();
            link.setGmlidFeaturemember(gmlId);
            link.setGmlidLinkedFeaturemember(gmlidLinkedFeature);
            link.setLinkedImklFeatureType(imklFeatureType);
            link.setBronhoudercode(featureDomainObject.getBronhoudercode());
            links.add(link);
        }
    }

    private static String extractGmlid(final String xlinkRef) {
        String gmlid = xlinkRef.substring(xlinkRef.lastIndexOf("/") + 1);
        gmlid = gmlid.replace(':', '.');
        return gmlid;
    }

    public List<FeatureLink> getLinks() {
        return links;
    }

    public QName getBaseElement() {
        return baseElement;
    }

    public QName getInspireType() {
        return inspireType;
    }
}
