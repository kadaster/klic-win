package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch;

public final class BatchJobParameter {

    /** Parameter key for passing the netbeheerder id. */
    public static final String KEY_BRONHOUDERCODE = "job.param.bronhoudercode";

    /** Parameter key for passing the actualisatie id. */
    public static final String KEY_ACTUALISATIE_ID = "job.param.actualisatieId";

    /** Parameter key for passing the filename. */
    public static final String KEY_FILENAME = "job.param.filename";

    /** Parameter key for passing batch size / commit-interval. */
    public static final String KEY_BATCH_SIZE = "job.param.batchsize";

    public static final String KEY_INFORMATIESOORT = "job.param.informatiesoort";
    public static final String KEY_NANO_TIME = "nanoTime";

    private BatchJobParameter() {
    }
}
