package nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain;

import javax.xml.namespace.QName;
import java.util.ArrayList;
import java.util.List;

public class ValidationRule {

    private final QName element;
    private List<QName> subElements;
    private boolean imklStrictlyMandatory = false;
    private boolean imklStrictlyProhibited = false;
    private boolean oneSubElementIsStrictlyMandatoryIfElementExists = false;
    private boolean ignored = false;
    
    public ValidationRule(final QName element) {
        this.element = element;
    }

    public ValidationRule withImklStrictlyMandatory() {
        imklStrictlyMandatory = true;
        return this;
    }

    public ValidationRule withImklStrictlyProhibited() {
        imklStrictlyProhibited = true;
        return this;
    }

    public ValidationRule withOneSubElementIsStrictlyMandatoryIfElementExists() {
        oneSubElementIsStrictlyMandatoryIfElementExists = true;
        return this;
    }

    public ValidationRule withIgnored() {
        ignored = true;
        return this;
    }
    
    public QName getElement() {
        return element;
    }

    public List<QName> getSubElements() {
        if (subElements == null) {
            subElements = new ArrayList<QName>();
        }
        return subElements;
    }

    public boolean isImklStrictlyMandatory() {
        return imklStrictlyMandatory;
    }

    public boolean isImklStrictlyProhibited() {
        return imklStrictlyProhibited;
    }

    public boolean isOneSubElementStrictlyMandatoryIfElementExists() {
        return oneSubElementIsStrictlyMandatoryIfElementExists;
    }
    
    public boolean isIgnored() {
        return ignored;
    }

}
