package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.beheerdersinformatie;

import org.springframework.beans.factory.annotation.Autowired;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.BestandIdentificatorHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.BestandLocatieHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ElementHandlerFactory;

public class BiElementHandlerFactory extends ElementHandlerFactory {

    @Autowired
    private BiBestandLocatieHandler biBestandLocatieHandler;

    @Autowired
    private BiBestandIdentificatorHandler biBestandIdentificatorHandler;

    @Override
    public BestandLocatieHandler getBestandLocatieHandler() {
        return biBestandLocatieHandler;
    }

    @Override
    public BestandIdentificatorHandler getBestandIdentificatorHandler() {
        return biBestandIdentificatorHandler;
    }

}
