package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ValidationRule;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

public abstract class ValidationRuleFactory {

    public abstract ValidationRule getBestandMediaTypeValidationRule();
    public abstract ValidationRule getBestandLocatieValidationRule();

    public ValidationRule getImklIdentificatieValidationRule() {
        return new ValidationRule(Elements.IMKL_IDENTIFICATIE).withImklStrictlyMandatory();
    }
}
