package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.Diepte;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ValidationRule;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.DatumOpmetingDieptePeilHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.DiepteAangrijpingspuntHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.DiepteLiggingHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.DiepteNauwkeurigheidHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.DieptePeilHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ImklIdentificatieHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ImklInNetworkHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.LabelHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.OmschrijvingHandler;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;
import org.springframework.beans.factory.annotation.Autowired;

import javax.xml.namespace.QName;
import java.util.List;

public abstract class AbstractDiepteStaxMapper extends StaxMapper<Diepte> {

    @Autowired
    private DiepteNauwkeurigheidHandler diepteNauwkeurigheidHandler;

    @Autowired
    private DiepteAangrijpingspuntHandler diepteAangrijpingspuntHandler;

    @Override
    public QName getInspireType() {
        return null;
    }

    @Override
    void initElementHandlers() {
        super.initElementHandlers();
        addElementHandler(new ImklIdentificatieHandler());
        addElementHandler(diepteNauwkeurigheidHandler);
        addElementHandler(diepteAangrijpingspuntHandler);
        addElementHandler(new DieptePeilHandler());
        addElementHandler(new DatumOpmetingDieptePeilHandler());
        addElementHandler(new DiepteLiggingHandler());
        addElementHandler(new LabelHandler());
        addElementHandler(new OmschrijvingHandler());
        addElementHandler(new ImklInNetworkHandler());
    }

    @Override
    List<ValidationRule> getValidationRules() {
        final List<ValidationRule> validationRules = super.getValidationRules();
        validationRules.add(new ValidationRule(Elements.IMKL_IDENTIFICATIE).withImklStrictlyMandatory());
        return validationRules;
    }

    @Override
    Diepte createDomainObject() {
        return new Diepte();
    }
}
