package nl.kadaster.klic.win.feature.actualiseren.imkl2015.storage;

public interface WionFeatureTypeDao {
    Long findId(final String featureType);
}
