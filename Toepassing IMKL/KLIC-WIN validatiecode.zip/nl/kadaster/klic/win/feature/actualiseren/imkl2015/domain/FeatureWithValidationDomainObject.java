package nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain;

import nl.kadaster.klic.win.feature.domain.imkl2015.ImklFeatureType;
import org.joda.time.DateTime;

public class FeatureWithValidationDomainObject extends FeatureWithValidation {

    // Table featurelink has a foreign key to the imklfeaturetypes table
    private ImklFeatureType imklFeatureType;
    private long actualisatieId;
    private InspireId inspireId;
    private DateTime beginLifespanVersion;
    private DateTime endLifespanVersion;
    private DateTime validFrom;
    private DateTime validTo;
    private String verticalPosition;
    private String utilityFacilityReference;
    private String governmentalservicereference;
    private String xmlImkl;
    private String xmlInspire;
    // foreign key to table ni_store.inspire_feature_types, used by Deegree WFS for 'levering (mail, screen)'
    private Long inspireFeatureTypeId;
    // foreign key to table ni_store.wion_feature_types, to be used in the future by Deegree WFS for the 'WION brug'
    private Long wionFeatureTypeId;

    private boolean wionOnly;

    public FeatureWithValidationDomainObject() {
        super();
    }

    public ImklFeatureType getImklFeatureType() {
        return imklFeatureType;
    }

    public void setImklFeatureType(final ImklFeatureType imklFeatureType) {
        this.imklFeatureType = imklFeatureType;
    }

    public DateTime getBeginLifespanVersion() {
        return beginLifespanVersion;
    }

    public void setBeginLifespanVersion(final DateTime beginLifespanVersion) {
        this.beginLifespanVersion = beginLifespanVersion;
    }

    public DateTime getEndLifespanVersion() {
        return endLifespanVersion;
    }

    public void setEndLifespanVersion(final DateTime endLifespanVersion) {
        this.endLifespanVersion = endLifespanVersion;
    }

    public long getActualisatieId() {
        return actualisatieId;
    }

    public void setActualisatieId(final long actualisatieId) {
        this.actualisatieId = actualisatieId;
    }

    public InspireId getInspireId() {
        return inspireId;
    }

    public void setInspireId(final InspireId inspireId) {
        if (this.inspireId == null) {
            this.inspireId = inspireId;
        }
    }

    public DateTime getValidFrom() {
        return validFrom;
    }

    public void setValidFrom(final DateTime validFrom) {
        this.validFrom = validFrom;
    }

    public DateTime getValidTo() {
        return validTo;
    }

    public void setValidTo(final DateTime validTo) {
        this.validTo = validTo;
    }

    public String getVerticalPosition() {
        return verticalPosition;
    }

    public void setVerticalPosition(final String verticalPosition) {
        this.verticalPosition = verticalPosition;
    }

    public String getUtilityFacilityReference() {
        return utilityFacilityReference;
    }

    public void setUtilityFacilityReference(final String utilityFacilityReference) {
        this.utilityFacilityReference = utilityFacilityReference;
    }

    public String getGovernmentalservicereference() {
        return governmentalservicereference;
    }

    public void setGovernmentalservicereference(final String governmentalservicereference) {
        this.governmentalservicereference = governmentalservicereference;
    }

    public Long getInspireFeatureTypeId() {
        return inspireFeatureTypeId;
    }

    public void setInspireFeatureTypeId(final Long inspireFeatureTypeId) {
        this.inspireFeatureTypeId = inspireFeatureTypeId;
    }

    public Long getWionFeatureTypeId() {
        return wionFeatureTypeId;
    }

    public void setWionFeatureTypeId(final Long wionFeatureTypeId) {
        this.wionFeatureTypeId = wionFeatureTypeId;
    }

    public String getXmlInspire() {
        return xmlInspire;
    }

    public void setXmlInspire(final String xmlInspire) {
        this.xmlInspire = xmlInspire;
    }

    public String getXmlImkl() {
        return xmlImkl;
    }

    public void setXmlImkl(final String xmlImkl) {
        this.xmlImkl = xmlImkl;
    }

    public void wionOnly(final boolean wionOnly) {
        this.wionOnly = wionOnly;
    }

    public boolean isWionOnly() {
        return wionOnly;
    }
}
