package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ExtraDetailInfo;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ValidationRule;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.*;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationRuleFactory;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.namespace.QName;
import java.util.List;

public class ExtraDetailInfoStaxMapper extends StaxMapper<ExtraDetailInfo> {

    private final ElementHandlerFactory elementHandlerFactory;

    private final ValidationRuleFactory validationRuleFactory;

    public ExtraDetailInfoStaxMapper(final ElementHandlerFactory elementHandlerFactory, final ValidationRuleFactory validationRuleFactory) {
        assert elementHandlerFactory != null;
        assert validationRuleFactory != null;

        this.elementHandlerFactory = elementHandlerFactory;
        this.validationRuleFactory = validationRuleFactory;
    }

    @Override
    boolean canHandle(final QName element) {
        return Elements.EXTRADETAILINFO.equals(element);
    }

    @Override
    ExtraDetailInfo createDomainObject() {
        return new ExtraDetailInfo();
    }

    @Override
    public QName getInspireType() {
        return null;
    }

    @Override
    void initElementHandlers() {
        super.initElementHandlers();
        addElementHandler(elementHandlerFactory.getImklIdentificatieHandler());
        addElementHandler(elementHandlerFactory.getBeginLifespanVersionHandler());
        addElementHandler(elementHandlerFactory.getEndLifespanVersionHandler());
        addElementHandler(elementHandlerFactory.getExtraDetailInfoLiggingHandler());
        addElementHandler(elementHandlerFactory.getLabelHandler());
        addElementHandler(elementHandlerFactory.getOmschrijvingHandler());
        addElementHandler(elementHandlerFactory.getImklInNetworkHandler());
        addElementHandler(elementHandlerFactory.getExtraInfoTypeHandler());
        addElementHandler(elementHandlerFactory.getBestandMediaTypeHandler());
        addElementHandler(elementHandlerFactory.getBestandIdentificatorHandler());
        addElementHandler(elementHandlerFactory.getBestandLocatieHandler());
    }

    @Override
    List<ValidationRule> getValidationRules() {
        final List<ValidationRule> validationRules = super.getValidationRules();
        validationRules.add(validationRuleFactory.getImklIdentificatieValidationRule());
        validationRules.add(validationRuleFactory.getBestandLocatieValidationRule());
        validationRules.add(validationRuleFactory.getBestandMediaTypeValidationRule());
        return validationRules;
    }

    @Override
    protected QName getBaseElement() {
        return Elements.EXTRADETAILINFO;
    }
}
