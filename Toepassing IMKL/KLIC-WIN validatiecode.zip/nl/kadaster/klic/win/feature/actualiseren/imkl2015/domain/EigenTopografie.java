package nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain;

import nl.kadaster.klic.win.feature.common.util.gml.Elements;

public class EigenTopografie extends ImklFeatureWithValidationDomainObject {

    private String typeTopografischObject;

    public EigenTopografie() {
        super();
        setSeenElementValue(Elements.EIGEN_TOPOGRAFIE, 0, true);
    }

    public String getTypeTopografischObject() {
        return typeTopografischObject;
    }

    public void setTypeTopografischObject(final String typeTopografischObject) {
        this.typeTopografischObject = typeTopografischObject;
    }

}
