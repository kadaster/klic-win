package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.netinformatie;

import org.springframework.beans.factory.annotation.Autowired;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.BestandIdentificatorHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.BestandLocatieHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ElementHandlerFactory;

public class NiElementHandlerFactory extends ElementHandlerFactory {

    @Autowired
    private NiBestandIdentificatorHandler niBestandIdentificatorHandler;

    @Override
    public BestandLocatieHandler getBestandLocatieHandler() {
        return new NiBestandLocatieHandler();
    }

    @Override
    public BestandIdentificatorHandler getBestandIdentificatorHandler() {
        return niBestandIdentificatorHandler;
    }
}
