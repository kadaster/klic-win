package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ImklFeatureWithValidationDomainObject;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.namespace.QName;

public class WaterTypeHandler extends AbstractCodelistElementHandler<ImklFeatureWithValidationDomainObject> {

    private static final String CODELIST_NAME_INSPIRE = "WaterTypeValue";
    private static final String CODELIST_NAME_IMKL = "WaterTypeIMKLValue";

    @Override
    protected QName getHandlingElement() {
        return Elements.INSPIRE_WATERTYPE;
    }

    @Override
    protected void preValidate() {
        setCodelist(CODELIST_NAME_INSPIRE, CODELIST_NAME_IMKL);
    }

}