package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.netinformatie;

import nl.kadaster.klic.win.feature.actualiseren.client.BijlageStoreClient;
import nl.kadaster.klic.win.feature.actualiseren.client.BijlageStoreClientException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.context.MultiThreadedBatchJobContext;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.data.BatchJobThreadData;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.BestandIdentificatorHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.regex.Pattern;

public class NiBestandIdentificatorHandler extends BestandIdentificatorHandler {

    private static final Pattern PATTERN = Pattern.compile("-");

    @Autowired
    private BijlageStoreClient bijlageStoreClient;

    private static final Logger LOG = LoggerFactory.getLogger(NiBestandIdentificatorHandler.class);

    @Override
    protected void validateBestandIdentificator(final String bestandIdentificator, final String gmlId, final ValidationMessageBuilder validationMessageBuilder) {

        validateBestandIdentificatorFormat(bestandIdentificator, gmlId, validationMessageBuilder);

        if (!validationMessageBuilder.hasErrors()) {
            // validate existence in bijlagestore
            try {
                long start = System.currentTimeMillis();
                final boolean fileExists = bijlageStoreClient.checkIfFileExist(PATTERN.matcher(bestandIdentificator).replaceFirst("/"));
                final BatchJobThreadData batchJobThreadData = MultiThreadedBatchJobContext.getBatchJobThreadData();
                final long documentReferenceCheckingTime = System.currentTimeMillis() - start;
                if (LOG.isDebugEnabled()) {
                    LOG.debug("Checking on file existence of document {} took {} ms. File exists: {}", bestandIdentificator, documentReferenceCheckingTime, fileExists);
                }
                batchJobThreadData.addDocumentReferenceCheckingTime(documentReferenceCheckingTime);
                batchJobThreadData.addDocumentReferenceCheckedCount();

                if (!fileExists) {
                    validationMessageBuilder.addErrorBestandIdentificatorDoesNotExist(gmlId, bestandIdentificator);
                }
            } catch (BijlageStoreClientException ex) {
                LOG.error("Unable to check if bijlage exists in bijlage store", ex);
                validationMessageBuilder.addErrorTechnical();
            }
        }

    }

}
