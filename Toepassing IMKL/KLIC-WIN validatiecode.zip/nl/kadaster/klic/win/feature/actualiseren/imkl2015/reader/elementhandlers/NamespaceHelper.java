package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import javax.xml.stream.events.Namespace;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class NamespaceHelper {

    private NamespaceHelper() {
    }

    public static List<Namespace> toList(Iterator<Namespace> namespaceIterator) {
        List<Namespace> namespaces = new ArrayList<>();
        while (namespaceIterator.hasNext()) {
            Namespace namespace = namespaceIterator.next();
            namespaces.add(namespace);
        }
        return namespaces;
    }
}
