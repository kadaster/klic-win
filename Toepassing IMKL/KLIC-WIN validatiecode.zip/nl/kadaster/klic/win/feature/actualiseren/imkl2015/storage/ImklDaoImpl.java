package nl.kadaster.klic.win.feature.actualiseren.imkl2015.storage;

import nl.kadaster.klic.win.feature.domain.imkl2015.DatabaseConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.transaction.annotation.Transactional;

import nl.kadaster.klic.win.util.NiStoreUtil;

public class ImklDaoImpl implements ImklDao {

    private static final Logger LOG = LoggerFactory.getLogger(ImklDaoImpl.class);
    
    private static final String DELETE_FOR_NETBEHEERDER = "delete from ni_store.%s_rest_sa where bronhoudercode = ?";
    
    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    @Autowired
    private PartitionDao partitionDao;
    
    @Override
    public void removeConceptData(final String bronhoudercode) {
        if (NiStoreUtil.isPartitioned(bronhoudercode)) {
            partitionDao.dropSaConstraints(bronhoudercode);
            partitionDao.dropSaIndexes(bronhoudercode);
            partitionDao.truncateSa(bronhoudercode);
        } else {
            removeConceptDataByRow("feature", bronhoudercode);
            removeConceptDataByRow("feature_link", bronhoudercode);
            removeConceptDataByRow("inspire_gml_objects", bronhoudercode);
            removeConceptDataByRow("wion_gml_objects", bronhoudercode);
        }
    }
    
    private void removeConceptDataByRow(final String tableName, final String bronhoudercode) {
        String sql = String.format(DELETE_FOR_NETBEHEERDER, tableName);
        jdbcTemplate.update(sql, bronhoudercode);
    }
    
    @Override
    @Transactional
    public void migrateToProduction(final String bronhoudercode) {
        if (NiStoreUtil.isPartitioned(bronhoudercode)) {
            partitionDao.dropSaPartitionConstraints(bronhoudercode);
            partitionDao.exchangePartitions(bronhoudercode);
            partitionDao.recreateSaViews();
        } else {
            performMigration("FeatureLinks", "migrate_feature_link_to_prod", bronhoudercode);
            performMigration("InspireGmlObjects", "migrate_inspire_gml_objects_to_prod", bronhoudercode);
            performMigration("WionGmlObjects", "migrate_wion_gml_objects_to_prod", bronhoudercode);
            performMigration("Features", "migrate_feature_to_prod", bronhoudercode);
        }
    }
    
    private void performMigration(final String elementName, final String functionName, final String bronhoudercode) {
        LOG.info("Migrating {}...", elementName);
        final SimpleJdbcCall func = new SimpleJdbcCall(jdbcTemplate).withSchemaName(DatabaseConstants.NI_STORE).withFunctionName(functionName).withReturnValue();
        final MapSqlParameterSource params = new MapSqlParameterSource();

        params.addValue("in_bronhoudercode", bronhoudercode);
        Integer migratedRows = func.executeFunction(Integer.class, params);
        LOG.info(">> Migrated {} {} rows ", migratedRows, elementName);
    }
   
}
