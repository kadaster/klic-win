package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.InspireId;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

final class XLinkInspireIdExtractor {

    private static final Logger LOG = LoggerFactory.getLogger(XLinkInspireIdExtractor.class);

    private static final String IMKL_NAMESPACE = "NL.IMKL";
    private static final int IMKL_LENGHT_PLUS_ONE = IMKL_NAMESPACE.length() + 1;

    private XLinkInspireIdExtractor() {
    }

    /**
     * InspireId is made up of:
     * 1. Namespace part; fixed 'NL.IMKL'
     * 2. LocalID; made up of 'bronhoudercode.lokaalID'
     *
     * Example: nl.imkl-gembest_rh.e-9
     */
    static InspireId extractInspireId(final String xLinkRef) {
        if (StringUtils.isEmpty(xLinkRef) || xLinkRef.length() <= IMKL_LENGHT_PLUS_ONE || !xLinkRef.toUpperCase().startsWith(IMKL_NAMESPACE)) {
            LOG.error("Invalid xLink found: {}. Imkl namespace (NL.IMKL) should be the first part of the XLink", xLinkRef);
            return null;
        }
        final InspireId inspireId = new InspireId();
        inspireId.setNamespace(IMKL_NAMESPACE);
        inspireId.setLocalId(xLinkRef.toUpperCase().substring(IMKL_LENGHT_PLUS_ONE));

        return inspireId;
    }
}
