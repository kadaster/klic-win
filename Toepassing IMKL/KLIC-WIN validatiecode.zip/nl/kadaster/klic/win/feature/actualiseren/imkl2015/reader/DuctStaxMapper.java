package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.KabelEnLeidingContainer;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ValidationRule;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.CurrentStatusHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.DiepteLeggingHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.DuctWidthElement;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ImklExtraGeometrieHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ImklHeeftExtraInformatieHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.InNetworkNetworkHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.InspireIdHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.LinkNetworkHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.VerticalPositionHandler;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;
import org.springframework.beans.factory.annotation.Autowired;

import javax.xml.namespace.QName;
import java.util.List;

public class DuctStaxMapper extends StaxMapper<KabelEnLeidingContainer> {

    @Autowired
    private CurrentStatusHandler currentStatusHandler;

    @Override
    void initElementHandlers() {
        super.initElementHandlers();
        addElementHandler(new InspireIdHandler());
        addElementHandler(new VerticalPositionHandler());
        addElementHandler(new DuctWidthElement());
        addElementHandler(currentStatusHandler);
        
        // associations
        addElementHandler(new InNetworkNetworkHandler());
        addElementHandler(new LinkNetworkHandler());
        addElementHandler(new DiepteLeggingHandler());
        addElementHandler(new ImklHeeftExtraInformatieHandler());
        addElementHandler(new ImklExtraGeometrieHandler());
    }

    @Override
    boolean canHandle(final QName element) {
        return Elements.DUCT.equals(element);
    }

    @Override
    public QName getInspireType() {
        return Elements.INSPIRE_DUCT;
    }

    @Override
    protected KabelEnLeidingContainer createDomainObject() {
        return new KabelEnLeidingContainer();
    }

    @Override
    List<ValidationRule> getValidationRules() {
        final List<ValidationRule> validationRules = super.getValidationRules();
        validationRules.add(new ValidationRule(Elements.INSPIRE_ID).withImklStrictlyMandatory());
        return validationRules;
    }

    @Override
    protected QName getBaseElement() {
        return Elements.DUCT;
    }
}
