package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import javax.xml.namespace.QName;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.Maatvoering;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

public class MaatvoeringsTypeHandler extends AbstractCodelistElementHandler<Maatvoering> {

    private static final String CODELIST_NAME_IMKL = "MaatvoeringsTypeValue";

    @Override
    protected QName getHandlingElement() {
        return Elements.MAATVOERINGSTYPE;
    }

    @Override
    protected void preValidate() {
        setCodelist(CODELIST_NAME_IMKL);
    }

    @Override
    protected void postValidate(final Maatvoering maatvoering, final String xLinkCodelistValue) {
        maatvoering.setType(getCodelistValue(xLinkCodelistValue));
    }

}
