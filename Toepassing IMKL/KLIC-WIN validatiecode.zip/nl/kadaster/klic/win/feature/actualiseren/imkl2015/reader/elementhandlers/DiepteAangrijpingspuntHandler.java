package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.Diepte;

import javax.xml.namespace.QName;

import static nl.kadaster.klic.win.feature.common.util.gml.Elements.*;

public class DiepteAangrijpingspuntHandler extends AbstractCodelistElementHandler<Diepte> {

    private static final String CODELIST_NAME_IMKL = "DiepteAangrijpingspuntValue";

    @Override
    protected QName getHandlingElement() {
        return DIEPTE_AANGRIJPINGSPUNT;
    }

    @Override
    protected void preValidate() {
        setCodelist(CODELIST_NAME_IMKL);
    }

}
