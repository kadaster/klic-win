package nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain;

import org.apache.commons.lang.StringUtils;

import java.util.Objects;

public class LocalId {

    private static final String DOT = ".";
    private String localIdString;
    private String bronhouderCode;
    private String id;
    private boolean valid;

    LocalId(final String localIdString) {
        init(localIdString);
        if (valid) {
            final int dotIndex = localIdString.indexOf(DOT);
            bronhouderCode = localIdString.substring(0, dotIndex);
            id = localIdString.substring(dotIndex + 1);
        }
    }

    private void init(final String localIdString) {
        this.localIdString = localIdString;
        valid = StringUtils.isNotEmpty(localIdString) && localIdString.length() > 1 && localIdString.contains(DOT);
    }

    public boolean isValid() {
        return valid;
    }

    public String getLocalIdString() {
        return localIdString;
    }

    public String getBronhouderCode() {
        return bronhouderCode;
    }

    public String getId() {
        return id;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        final LocalId localId = (LocalId) o;
        return valid == localId.valid &&
                Objects.equals(localIdString, localId.localIdString) &&
                Objects.equals(bronhouderCode, localId.bronhouderCode) &&
                Objects.equals(id, localId.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(localIdString, bronhouderCode, id, valid);
    }

    @Override
    public String toString() {
        return "LocalId{" +
                "localIdString='" + localIdString + '\'' +
                ", bronhouderCode='" + bronhouderCode + '\'' +
                ", id='" + id + '\'' +
                ", valid=" + valid +
                '}';
    }
}
