package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ValidationRule;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

public class IgnoringValidationRuleFactory extends ValidationRuleFactory {
    @Override
    public ValidationRule getBestandMediaTypeValidationRule() {
        return new ValidationRule(Elements.BESTANDMEDIATYPE).withIgnored();
    }

    @Override
    public ValidationRule getBestandLocatieValidationRule() {
        return new ValidationRule(Elements.BESTANDLOCATIE).withIgnored();
    }
}
