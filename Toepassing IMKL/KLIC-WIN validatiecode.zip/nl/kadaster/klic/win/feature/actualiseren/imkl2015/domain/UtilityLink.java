package nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain;


public class UtilityLink extends FeatureWithValidationDomainObject {

    private long utiliteitsnetId;
    private boolean fictitious;

    private String utiliteitsnetInspireId;

    public boolean isFictitious() {
        return fictitious;
    }

    public void setFictitious(boolean fictious) {
        this.fictitious = fictious;
    }

    public String getUtiliteitsnetInspireId() {
        return utiliteitsnetInspireId;
    }

    public void setUtiliteitsnetInspireId(String utiliteitsnetInspireId) {
        this.utiliteitsnetInspireId = utiliteitsnetInspireId;
    }

    public long getUtiliteitsnetId() {
        return utiliteitsnetId;
    }

    public void setUtiliteitsnetId(long utiliteitsnetId) {
        this.utiliteitsnetId = utiliteitsnetId;
    }
}
