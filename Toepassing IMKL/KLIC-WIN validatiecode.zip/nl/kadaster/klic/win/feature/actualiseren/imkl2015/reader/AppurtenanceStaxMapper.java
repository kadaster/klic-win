package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.Appurtenance;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ValidationRule;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.*;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;
import org.springframework.beans.factory.annotation.Autowired;

import javax.xml.namespace.QName;
import java.util.List;

public class AppurtenanceStaxMapper extends StaxMapper<Appurtenance> {

    @Autowired
    private CurrentStatusHandler currentStatusHandler;

    @Override
    void initElementHandlers() {
        super.initElementHandlers();
        addElementHandler(new InspireIdHandler());
        addElementHandler(new GeometryElementHandler());
        addElementHandler(currentStatusHandler);
        addElementHandler(new ValidFromHandler());
        addElementHandler(new ValidToHandler());
        addElementHandler(new VerticalPositionHandler());
        addElementHandler(new LabelHandler());
        addElementHandler(new OmschrijvingHandler());
        addElementHandler(new AppurtenanceTypeHandler());
        addElementHandler(new ImklForbiddenElements(Elements.SPECIFIC_APPURTENANCE_TYPE));
        addElementHandler(new RotatiehoekSymboolHandler());
        
        // associations
        addElementHandler(new InNetworkNetworkHandler());
        addElementHandler(new DiepteLeggingHandler());
        addElementHandler(new ImklHeeftExtraInformatieHandler());
        addElementHandler(new ImklExtraGeometrieHandler());
    }

    @Override
    boolean canHandle(final QName element) {
        return Elements.APPURTENANCE.equals(element);
    }

    @Override
    List<ValidationRule> getValidationRules() {
        final List<ValidationRule> validationRules = super.getValidationRules();
        validationRules.add(new ValidationRule(Elements.INSPIRE_ID).withImklStrictlyMandatory());
        validationRules.add(new ValidationRule(Elements.APPURTENANCE_TYPE).withImklStrictlyMandatory());
        return validationRules;
    }

    @Override
    protected Appurtenance createDomainObject() {
        return new Appurtenance();
    }

    @Override
    public QName getInspireType() {
        return Elements.INSPIRE_APPURTENANCE;
    }

    @Override
    protected QName getBaseElement() {
        return Elements.APPURTENANCE;
    }

}
