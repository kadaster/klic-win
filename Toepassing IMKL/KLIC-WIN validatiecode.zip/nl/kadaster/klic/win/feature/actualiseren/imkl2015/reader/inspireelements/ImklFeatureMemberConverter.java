package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.inspireelements;

import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLEventFactory;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.Namespace;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;
import java.util.List;

public class ImklFeatureMemberConverter extends CommonFeatureMemberConverter implements InspireElementConverter {

    private final XMLEventFactory xmlEventFactory = XMLEventFactory.newInstance();
    private InspireConvertibleElementProvider inspireConvertibleElementProvider;

    public ImklFeatureMemberConverter(final List<Namespace> globalNamespaces) {
        super(globalNamespaces);
    }

    @Override
    public boolean shouldHandle(final StartElement element) {
        return Elements.NAMESPACE_IMKL.equals(element.getName().getNamespaceURI()) &&
                inspireConvertibleElementProvider.isConvertible(element.getName());
    }

    @Override
    public boolean shouldHandle(final EndElement element) {
        return Elements.NAMESPACE_IMKL.equals(element.getName().getNamespaceURI()) &&
                inspireConvertibleElementProvider.isConvertible(element.getName());
    }

    @Override
    public XMLEvent convertStartElement(final StartElement element) {
        @SuppressWarnings("unchecked") final List<Namespace> namespaces = mergeWithGlobalNamespaces(element.getNamespaces());
        QName inspireElement = inspireConvertibleElementProvider.getInspireElement(element.getName());
        QName inspireElementWithCorrectNamespacePrefix = new QName(inspireElement.getNamespaceURI(), inspireElement.getLocalPart(), findNamespacePrefix(inspireElement.getNamespaceURI(), namespaces));

        List<Namespace> namespacesStrippedOfImkl = stripImklNamespaces(namespaces.iterator());
        return xmlEventFactory.createStartElement(inspireElementWithCorrectNamespacePrefix, element.getAttributes(), namespacesStrippedOfImkl.iterator());
    }

    private static String findNamespacePrefix(final String namespaceURI, final List<Namespace> namespaces) {
        String prefix = "";
        for (Namespace namespace : namespaces) {
            if (namespace.getNamespaceURI().equals(namespaceURI)) {
                prefix = namespace.getPrefix();
                break;
            }
        }
        return prefix;
    }

    public void setInspireConvertibleElementProvider(final InspireConvertibleElementProvider inspireConvertibleElementProvider) {
        this.inspireConvertibleElementProvider = inspireConvertibleElementProvider;
    }

    @Override
    public XMLEvent convertEndElement(final EndElement element) {
        QName inspireElement = inspireConvertibleElementProvider.getInspireElement(element.getName());
        return xmlEventFactory.createEndElement(inspireElement, element.getNamespaces());
    }

}
