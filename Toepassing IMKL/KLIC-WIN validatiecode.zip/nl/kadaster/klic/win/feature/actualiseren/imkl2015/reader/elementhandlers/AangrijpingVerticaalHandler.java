package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.FeatureWithValidation;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.CodelistValueValidator;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import javax.xml.stream.events.StartElement;

public class AangrijpingVerticaalHandler extends AbstractElementHandler implements ElementHandler<FeatureWithValidation> {

    private static final String CODELIST_NAME = "LabelpositieValue";

    private final CodelistValueValidator codelistValueValidator;

    @Autowired
    public AangrijpingVerticaalHandler(final CodelistValueValidator codelistValueValidator) {
        this.codelistValueValidator = codelistValueValidator;
    }

    @Override
    public boolean shouldHandle(final StartElement element) {
        return sameQName(Elements.AANGRIJPING_VERTICAAL, element.getName());
    }

    @Override
    public void handle(final StartElement element, final FeatureLinks featureLinks, final FeatureWithValidation featureDomainObject, final StaxEventReader staxEventReader, final ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        final String aangrijpingVerticaal = getXLink(element);
        if (codelistValueValidator.validateCodelistValue(CODELIST_NAME, aangrijpingVerticaal, validationMessageBuilder, featureDomainObject)) {
            final String aangrijpingVerticaalStripped = aangrijpingVerticaal.substring(aangrijpingVerticaal.lastIndexOf("/") + 1);
            featureDomainObject.setAangrijpingVerticaal(aangrijpingVerticaalStripped);
        }
        featureDomainObject.setSeenElementValue(Elements.AANGRIJPING_VERTICAAL, element.getLocation().getLineNumber(), StringUtils.isNotEmpty(aangrijpingVerticaal));
    }
}
