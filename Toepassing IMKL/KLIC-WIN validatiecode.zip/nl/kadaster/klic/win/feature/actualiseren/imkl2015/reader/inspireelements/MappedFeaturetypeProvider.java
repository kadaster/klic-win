package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.inspireelements;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.InspireId;

public interface MappedFeaturetypeProvider {
    InspireId findInspireId(final String xlinkRef);
}
