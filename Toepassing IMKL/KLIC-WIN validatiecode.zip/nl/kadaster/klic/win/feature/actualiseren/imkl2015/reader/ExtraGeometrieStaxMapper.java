package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ExtraGeometrie;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ValidationRule;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ImklIdentificatieHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ImklInNetworkHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.InNetworkNetworkHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.VlakGeometrie2DHandler;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.namespace.QName;
import java.util.List;

public class ExtraGeometrieStaxMapper extends StaxMapper<ExtraGeometrie> {

    @Override
    void initElementHandlers() {
        super.initElementHandlers();
        addElementHandler(new ImklIdentificatieHandler());
        addElementHandler(new VlakGeometrie2DHandler());
        addElementHandler(new InNetworkNetworkHandler());
        addElementHandler(new ImklInNetworkHandler());
    }

    @Override
    List<ValidationRule> getValidationRules() {
        final List<ValidationRule> validationRules = super.getValidationRules();
        validationRules.add(new ValidationRule(Elements.IMKL_IDENTIFICATIE).withImklStrictlyMandatory());
        return validationRules;
    }

    @Override
    boolean canHandle(final QName element) {
        return Elements.EXTRA_GEOMETRIE.equals(element);
    }

    @Override
    protected ExtraGeometrie createDomainObject() {
        return new ExtraGeometrie();
    }

    @Override
    public QName getInspireType() {
        return null;
    }

    @Override
    protected QName getBaseElement() {
        return Elements.EXTRA_GEOMETRIE;
    }

}
