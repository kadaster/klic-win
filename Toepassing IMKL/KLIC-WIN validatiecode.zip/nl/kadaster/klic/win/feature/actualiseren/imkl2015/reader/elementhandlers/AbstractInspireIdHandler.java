package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.InspireId;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxHelper;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;

import javax.xml.namespace.QName;

abstract class AbstractInspireIdHandler extends AbstractElementHandler {

    static InspireId getInspireId(QName inspireIdName, QName namespaceName, QName localPartName, QName featureType, QName baseType, StaxEventReader staxEventReader) throws XMLException {
        InspireId inspireId = new InspireId();
        inspireId.setType(featureType);
        inspireId.setBaseType(baseType);
        StaxHelper.navigateToFirstElement(staxEventReader, localPartName);
        inspireId.setLocalId(StaxHelper.readElementData(staxEventReader));
        StaxHelper.navigateToFirstElement(staxEventReader, namespaceName);
        inspireId.setNamespace(StaxHelper.readElementData(staxEventReader));
        StaxHelper.navigateToEndElement(staxEventReader, inspireIdName);
        return inspireId;
    }

}
