package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.FeatureWithValidationDomainObject;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.CodelistValueValidator;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import javax.xml.namespace.QName;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.StartElement;
import java.util.Arrays;
import java.util.List;

public abstract class AbstractCodelistElementHandler<T extends FeatureWithValidationDomainObject> extends AbstractElementHandler implements ElementHandler<T> {

    @Autowired
    private CodelistValueValidator codelistValueValidator;
    private List<String> codelistList;

    protected abstract QName getHandlingElement();
    protected abstract void preValidate();

    void setCodelist(final String... codelist) {
        codelistList = Arrays.asList(codelist);
    }

    @Override
    public boolean shouldHandle(final StartElement element) {
        return sameQName(getHandlingElement(), element.getName());
    }

    @Override
    public void handle(final StartElement element, final FeatureLinks featureLinks, final T imklDomainObject, final StaxEventReader staxEventReader, final ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        preValidate();
        final String xLinkCodelistValue = getXlinkCodelistValue(element);
        if (validateXlinkCodelistValue(xLinkCodelistValue, imklDomainObject, validationMessageBuilder)) {
            postValidate(imklDomainObject, xLinkCodelistValue);
        }
        imklDomainObject.setSeenElementValue(element.getName(), element.getLocation().getLineNumber(), StringUtils.isNotEmpty(xLinkCodelistValue));
    }

    void postValidate(final T imklDomainObject, final String xLinkCodelistValue) {
        // Empty implementation to be overridden by subclasses when appropriate.
    }

    private boolean validateXlinkCodelistValue(final String xLinkCodelistValue, final T imklDomainObject, final ValidationMessageBuilder validationMessageBuilder) {
        boolean valid = false;
        if (StringUtils.isNotEmpty(xLinkCodelistValue)) {
            valid = codelistValueValidator.validateCodelistValue(codelistList, xLinkCodelistValue, validationMessageBuilder, imklDomainObject);
        }
        return valid;
    }

    private static String getXlinkCodelistValue(final StartElement element) {
        final Attribute attribute = element.asStartElement().getAttributeByName(Elements.XLINK_HREF);
        if (attribute != null) {
            return attribute.getValue();
        }
        return null;
    }

}
