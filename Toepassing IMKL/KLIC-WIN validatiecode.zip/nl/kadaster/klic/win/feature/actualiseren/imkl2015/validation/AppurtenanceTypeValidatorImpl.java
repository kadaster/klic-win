package nl.kadaster.klic.win.feature.actualiseren.imkl2015.validation;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.storage.FeatureDao;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class AppurtenanceTypeValidatorImpl implements AppurtenanceTypeValidator {

    @Autowired
    private FeatureDao featureDao;

    @Override
    public void validate(final String bronhoudercode, final ValidationMessageBuilder validationMessageBuilder) {
        List<String> errorneousFeatureGmlIds = featureDao.getFeaturesWithIncorrectAppurtenanceType(bronhoudercode);
        for (String gmlId: errorneousFeatureGmlIds) {
            validationMessageBuilder.addErrorAppurtenanceTypeFromWrongCodelist(gmlId);
        }
    }

}
