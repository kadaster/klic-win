package nl.kadaster.klic.win.feature.actualiseren.imkl2015.validation;

import org.w3c.dom.ls.LSInput;
import org.w3c.dom.ls.LSResourceResolver;

import java.io.InputStream;
import java.nio.file.Path;
import java.nio.file.Paths;

public class ResourceResolver implements LSResourceResolver {

    private static final String HTTP = "http://";

    @Override
    public LSInput resolveResource(String type, String namespaceURI,
                                   String publicId, String systemId, String baseURI) {
        String path = buildPath(systemId);

        // Fix for relative paths. Try to resolve the full path.
        if (isRelativePath(path)) {
            path = convertBaseURI(baseURI) + path;
        }

        @SuppressWarnings("resource") InputStream resourceAsStream = getClass().getResourceAsStream(path);
        return new CustomLSInput(publicId, path, resourceAsStream);

        // enable this if xsd dependencies are missing
//        if (resourceAsStream == null) {
//            System.out.println("mkdir " + systemId.replace("/", "\\").substring(0, systemId.lastIndexOf("/")));
//            System.out.println("wget " + systemId);
//        }
    }

    /*
     * return baseURI without current directory and filename.
     */
    private static String convertBaseURI(String baseURI) {
        Path currentRelativePath = Paths.get("");
        String path = currentRelativePath.toAbsolutePath().toString();
        if (path.startsWith("/")) { // fix for unix based OS
            path = path.substring(1);
        }
        path = "file:///" + path;
        String intermediatePath = baseURI.substring(path.length() + 1);
        return intermediatePath.substring(0, intermediatePath.lastIndexOf("/") + 1);
    }

    private static boolean isRelativePath(String systemId) {
        return systemId.startsWith(".") || !systemId.contains("/");
    }

    // we dont want http:// in our package names
    private static String buildPath(String systemId) {
        String path = systemId;
        if (systemId != null && systemId.startsWith(HTTP)) {
            path = systemId.substring(HTTP.length());
        }
        return "" + path;
    }
}