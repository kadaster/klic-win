package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ExtraGeometrie;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.stream.events.StartElement;

public class VlakGeometrie2DHandler extends AbstractElementHandler implements ElementHandler<ExtraGeometrie> {

    @Override
    public boolean shouldHandle(final StartElement element) {
        return sameQName(Elements.VLAK_GEOMETRIE_2D, element.getName());
    }

    @Override
    public void handle(final StartElement element, final FeatureLinks featureLinks, final ExtraGeometrie extraGeometrie, final StaxEventReader staxEventReader, final ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        extraGeometrie.setVlakGeometrie2D(
                GeometryExtractor.extract(element.getName(), extraGeometrie, staxEventReader, validationMessageBuilder)
        );
    }
}
