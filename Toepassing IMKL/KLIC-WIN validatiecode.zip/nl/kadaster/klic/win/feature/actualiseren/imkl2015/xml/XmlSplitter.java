package nl.kadaster.klic.win.feature.actualiseren.imkl2015.xml;

import javax.xml.validation.Validator;
import java.io.InputStream;

public class XmlSplitter {
    private final String rootTag;
    private final String splitTag;

    public XmlSplitter(final String rootTag, final String splitTag) {
        this.rootTag = rootTag;
        this.splitTag = splitTag;
    }

    public XmlIterator split(final InputStream inputSteam, final Validator imklValidator) {
        return new XmlIterator(inputSteam, rootTag, splitTag, imklValidator);
    }
}
