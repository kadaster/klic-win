package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.EigenTopografie;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ValidationRule;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.EigenTopografieLiggingHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ImklIdentificatieHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ImklInNetworkHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ImklStatusHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.InNetworkNetworkHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.LabelHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.OmschrijvingHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.TypeTopografischObjectHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.AanleveringCharacteristics;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;
import org.springframework.beans.factory.annotation.Autowired;

import javax.xml.namespace.QName;
import java.util.List;

public class EigenTopografieStaxMapper extends StaxMapper<EigenTopografie> {

    @Autowired
    private ImklStatusHandler imklStatusHandler;
    
    @Autowired
    private TypeTopografischObjectHandler typeTopografischObjectHandler;

    @Override
    void initElementHandlers() {
        super.initElementHandlers();
        addElementHandler(new LabelHandler());
        addElementHandler(new OmschrijvingHandler());
        addElementHandler(new ImklIdentificatieHandler());
        addElementHandler(imklStatusHandler);
        addElementHandler(typeTopografischObjectHandler);
        addElementHandler(new EigenTopografieLiggingHandler());
        addElementHandler(new InNetworkNetworkHandler());
        addElementHandler(new ImklInNetworkHandler());
    }

    @Override
    boolean canHandle(final QName element) {
        return Elements.EIGEN_TOPOGRAFIE.equals(element);
    }

    @Override
    List<ValidationRule> getValidationRules() {
        final List<ValidationRule> validationRules = super.getValidationRules();
        validationRules.add(new ValidationRule(Elements.IMKL_IDENTIFICATIE).withImklStrictlyMandatory());
        return validationRules;
    }

    @Override
    protected EigenTopografie createDomainObject() {
        return new EigenTopografie();
    }

    @Override
    public QName getInspireType() {
        return null;
    }

    @Override
    protected QName getBaseElement() {
        return Elements.EIGEN_TOPOGRAFIE;
    }

    @Override
    protected void fillAanleveringCharacteristics(final AanleveringCharacteristics aanleveringCharacteristics, final EigenTopografie eigenTopografie) {
        aanleveringCharacteristics.setHasEigenTopo(true);
    }
}
