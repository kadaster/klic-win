package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch;

import java.util.List;

public final class BatchJobSettings {

    /**
     * ################################
     * ###### IMPORTANT NOTE !! #######
     * ################################
     *
     * Do not stretch the batch size too much, otherwise the <code>{@link nl.kadaster.klic.win.feature.actualiseren.imkl2015.storage.FeatureDao#storeBatch(List)}</code>
     * will fail/hang without any exception, message whatsoever.
     *
     * It will look like one or more thread(s) is/are hanging and when looking at the database you'll see that
     * an insert statement is running (insert into ni_store.feature_*_sa ....)
     *
     * At the database level logging you'll notice the following message:
     * <code>could not receive data from client: unrecognized winsock error 10061</code>
     */
    public static final long BATCH_SIZE = 500L;
    public static final int POOL_SIZE = Runtime.getRuntime().availableProcessors();

    private BatchJobSettings() {
    }
}
