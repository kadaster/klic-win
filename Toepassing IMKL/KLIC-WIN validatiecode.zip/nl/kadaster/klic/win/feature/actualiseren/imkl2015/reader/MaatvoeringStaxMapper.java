package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.Maatvoering;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ValidationRule;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.AangrijpingHorizontaalHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.AangrijpingVerticaalHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ImklIdentificatieHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ImklInNetworkHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.InNetworkNetworkHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.LabelHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.MaatvoeringLiggingHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.MaatvoeringsTypeHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.OmschrijvingHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.RotatiehoekHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.LabelValuePresenceValidationRuleFactory;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;
import org.springframework.beans.factory.annotation.Autowired;

import javax.xml.namespace.QName;
import java.util.List;

public class MaatvoeringStaxMapper extends StaxMapper<Maatvoering> {

    private final MaatvoeringsTypeHandler maatvoeringsTypeHandler;
    private final AangrijpingHorizontaalHandler aangrijpingHorizontaalHandler;
    private final AangrijpingVerticaalHandler aangrijpingVerticaalHandler;

    @Autowired
    public MaatvoeringStaxMapper(final AangrijpingVerticaalHandler aangrijpingVerticaalHandler, final MaatvoeringsTypeHandler maatvoeringsTypeHandler, final AangrijpingHorizontaalHandler aangrijpingHorizontaalHandler) {
        this.aangrijpingVerticaalHandler = aangrijpingVerticaalHandler;
        this.maatvoeringsTypeHandler = maatvoeringsTypeHandler;
        this.aangrijpingHorizontaalHandler = aangrijpingHorizontaalHandler;
    }

    @Override
    void initElementHandlers() {
        super.initElementHandlers();
        addElementHandler(new ImklIdentificatieHandler());
        addElementHandler(new InNetworkNetworkHandler());
        addElementHandler(maatvoeringsTypeHandler);
        addElementHandler(aangrijpingHorizontaalHandler);
        addElementHandler(aangrijpingVerticaalHandler);
        addElementHandler(new RotatiehoekHandler());
        addElementHandler(new MaatvoeringLiggingHandler());
        addElementHandler(new LabelHandler());
        addElementHandler(new OmschrijvingHandler());
        addElementHandler(new ImklInNetworkHandler());
    }

    @Override
    boolean canHandle(final QName element) {
        return Elements.MAATVOERING.equals(element);
    }

    @Override
    List<ValidationRule> getValidationRules() {
        final List<ValidationRule> validationRules = super.getValidationRules();
        validationRules.add(new ValidationRule(Elements.IMKL_IDENTIFICATIE).withImklStrictlyMandatory());
        validationRules.add(LabelValuePresenceValidationRuleFactory.createValidationRule());
        return validationRules;
    }

    @Override
    protected Maatvoering createDomainObject() {
        return new Maatvoering();
    }

    @Override
    public QName getInspireType() {
        return null;
    }

    @Override
    protected QName getBaseElement() {
        return Elements.MAATVOERING;
    }
}
