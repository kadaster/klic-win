package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import javax.xml.namespace.QName;

import nl.kadaster.klic.win.feature.common.util.gml.Elements;

public class DiepteTovMaaiveldStaxMapper extends AbstractDiepteStaxMapper {

    @Override
    boolean canHandle(final QName element) {
        return Elements.DIEPTE_TOV_MAAIVELD.equals(element);
    }

    @Override
    QName getBaseElement() {
        return Elements.DIEPTE_TOV_MAAIVELD;
    }

}
