package nl.kadaster.klic.win.feature.actualiseren.imkl2015.validation;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.FeatureWithValidationDomainObject;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;

public interface BronhouderCodeValidator {

    void validateBronhouderCode(
             final String bronhouderCode
            ,final FeatureWithValidationDomainObject domainObject
            ,final ValidationMessageBuilder validationMessageBuilder);

}
