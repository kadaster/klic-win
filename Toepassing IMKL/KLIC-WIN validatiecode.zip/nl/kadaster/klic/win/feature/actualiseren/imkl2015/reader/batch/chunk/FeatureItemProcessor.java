package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.chunk;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.ImklReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.context.MultiThreadedBatchJobContext;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.data.BatchJobThreadData;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.domain.FeatureItem;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.validation.ImklValidator;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.validation.ImklValidatorException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;

/**
 * Enriches the featureItems read from the {@link FeatureItemReader}
 * This processor actually reads, parses and interprets the feature members (XML). Read data is
 * added to the featureItems.
 */
public class FeatureItemProcessor implements ItemProcessor<FeatureItem, FeatureItem> {

    private static final Logger LOG = LoggerFactory.getLogger(FeatureItemProcessor.class);

    @Override
    public FeatureItem process(final FeatureItem featureItem) throws Exception {
        setLineNrOffset(featureItem);
        try {
            doValidateXml(featureItem);
            doValidatedImport(featureItem);
        } catch (ImklValidatorException e) {
            final BatchJobThreadData batchJobThreadData = MultiThreadedBatchJobContext.getBatchJobThreadData();
            LOG.error("IMKL file processing failed for actualisatie: " + batchJobThreadData.getActualisatieId(), e);
            batchJobThreadData.getValidationMessageBuilder().addGeneralError(e);
            throw e;
        }
        return featureItem;
    }

    private static void doValidateXml(final FeatureItem featureItem) throws ImklValidatorException {
        final BatchJobThreadData batchJobThreadData = MultiThreadedBatchJobContext.getBatchJobThreadData();
        batchJobThreadData.addXmlValidationTime(
                ImklValidator.validate(batchJobThreadData.getValidator(), featureItem.getXmlString())
        );
    }

    private static void doValidatedImport(final FeatureItem featureItem) throws XMLException {
        long startTime = System.currentTimeMillis();
        final BatchJobThreadData batchJobThreadData = MultiThreadedBatchJobContext.getBatchJobThreadData();
        final ImklReader imklReader = batchJobThreadData.getImklReader();
        imklReader.read(featureItem, batchJobThreadData.getValidationMessageBuilder(), batchJobThreadData.getAanleveringCharacteristics());
        batchJobThreadData.addValidatedImportTime(System.currentTimeMillis() - startTime);
    }

    private static void setLineNrOffset(final FeatureItem featureItem) {
        final BatchJobThreadData batchJobThreadData = MultiThreadedBatchJobContext.getBatchJobThreadData();
        batchJobThreadData.getValidationMessageBuilder().setLineNrOffset(featureItem.getLineNr());
    }
}
