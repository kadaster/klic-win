package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.TowerHeightElement;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.namespace.QName;

public class TorenStaxMapper extends AbstractContainerLeidingElementStaxMapper {

    @Override
    boolean canHandle(final QName element) {
        return Elements.TOREN.equals(element);
    }

    @Override
    public QName getInspireType() {
        return Elements.INSPIRE_TOWER;
    }

    @Override
    void initElementHandlers() {
        super.initElementHandlers();
        addElementHandler(new TowerHeightElement());
    }

    @Override
    protected QName getBaseElement() {
        return Elements.TOREN;
    }

}
