package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import javax.xml.stream.events.StartElement;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.Diepte;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

public class DiepteLiggingHandler extends AbstractElementHandler implements ElementHandler<Diepte> {

    @Override
    public boolean shouldHandle(final StartElement element) {
        return sameQName(Elements.LIGGING, element.getName());
    }

    @Override
    public void handle(final StartElement element, final FeatureLinks featureLinks, final Diepte diepte, final StaxEventReader staxEventReader, final ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        diepte.setGeometry(
                GeometryExtractor.extract(element.getName(), diepte, staxEventReader, validationMessageBuilder)
        );
    }
}
