package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ImklFeatureWithValidationDomainObject;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxHelper;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;
import org.apache.commons.lang.StringUtils;

import javax.xml.stream.events.StartElement;

public class LabelHandler extends AbstractElementHandler implements ElementHandler<ImklFeatureWithValidationDomainObject> {

    @Override
    public boolean shouldHandle(StartElement element) {
        return sameQName(Elements.LABEL, element.getName());
    }

    @Override
    public void handle(StartElement element, FeatureLinks featureLinks, ImklFeatureWithValidationDomainObject imklDomainObject, StaxEventReader staxEventReader, ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        imklDomainObject.setLabel(StaxHelper.readElementData(staxEventReader));
        imklDomainObject.setSeenElementValue(Elements.LABEL, element.getLocation().getLineNumber(), StringUtils.isNotEmpty(imklDomainObject.getLabel()));
    }

}