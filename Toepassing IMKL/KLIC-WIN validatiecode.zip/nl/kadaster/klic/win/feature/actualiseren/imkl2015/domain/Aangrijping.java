package nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain;

interface Aangrijping {

    void setAangrijpingHorizontaal(final String aangrijpingHorizontaal);
    void setAangrijpingVerticaal(final String aangrijpingVerticaal);
}
