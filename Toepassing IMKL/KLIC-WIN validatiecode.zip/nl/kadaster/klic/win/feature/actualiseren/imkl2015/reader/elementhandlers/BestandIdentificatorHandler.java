package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import javax.xml.stream.events.StartElement;

import org.springframework.beans.factory.annotation.Autowired;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ImklFeatureWithValidationDomainObject;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxHelper;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

public abstract class BestandIdentificatorHandler extends AbstractElementHandler implements ElementHandler<ImklFeatureWithValidationDomainObject> {

    @Autowired
    private BestandIdentificatorValidator bestandIdentificatorValidator;

    @Override
    public boolean shouldHandle(final StartElement element) {
        return sameQName(Elements.BESTANDIDENTIFICATOR, element.getName());
    }

    @Override
    public void handle(final StartElement element,
                       final FeatureLinks featureLinks,
                       final ImklFeatureWithValidationDomainObject feature,
                       final StaxEventReader staxEventReader,
                       final ValidationMessageBuilder validationMessageBuilder)
            throws XMLException {
        feature.setBestandIdentificator(StaxHelper.readElementData(staxEventReader));
        validateBestandIdentificator(feature.getBestandIdentificator(), feature.getGmlId(), validationMessageBuilder);
    }

    protected abstract void validateBestandIdentificator(final String bestandIdentificator, final String gmlId, final ValidationMessageBuilder validationMessageBuilder);

    protected void validateBestandIdentificatorFormat(final String bestandIdentificator,
                                            final String gmlId,
                                            final ValidationMessageBuilder validationMessageBuilder) {
        bestandIdentificatorValidator.validateBestandIdentificatorFormat(bestandIdentificator, gmlId, validationMessageBuilder);
    }
}
