package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.data.ValidationMessagesTracker;
import nl.kadaster.klic.win.model.ValidationMessage;
import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.UncategorizedSQLException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

public class ValidationMessageBuilder {

    private static final String MSG_NO_GMLID = "Er is een feature zonder gml-id: '%s'";
    private static final String MSG_TOO_MUCH_MESSAGES = "Er zijn meer dan %s validatiemeldingen. Meer meldingen worden niet getoond.";
    private static final String MSG_UNKNOWN_FEATURE_TYPE = "Er is een onbekend feature type aangetroffen: '%s'. Deze wordt genegeerd. %s";
    private static final String MSG_INVALID_GEOMETRY_NO_REASON = "Er is een ongeldige geometrie aangetroffen in het feature. %s";
    private static final String MSG_INVALID_GEOMETRY = "Er is een ongeldige geometrie aangetroffen in het feature: %s %s";
    private static final String MSG_NILVALUE_BUT_NO_NILREASON = "Attribuut '%s' heeft geen waarde en geen nil reason. %s";
    private static final String MSG_INVALID_UOM_VALUE = "Attribuut '%s' heeft een ongeldige UOM waarde. Toegestane waarde(s) is/zijn: [%s]. %s";
    private static final String MSG_INVALID_VALUE = "Attribuut '%s' heeft een ongeldige waarde. Toegestane waarde dient te voldoen aan: [%s]. %s";
    private static final String MSG_IMKL_ELEMENT_MANDATORY = "Element '%s' is verplicht binnen het IMKL maar heeft geen waarde. %s";
    private static final String MSG_IMKL_ELEMENT_NOT_PERMITTED = "Element '%s' is niet toegestaan binnen het IMKL van dit feature type. %s";
    private static final String MSG_MANDATORY_ELEMENT_NOT_FOUND = "Verplicht attribuut '%s' ontbreekt.";
    private static final String MSG_UNKNOWN_ERROR_DB_INSERT = "Er is een onbekende fout opgetreden tijdens het opslaan van het feature in de database: '%s'";
    private static final String MSG_DUPLICATE_KEY_ERROR_DB_INSERT = "Duplicate key violation bij het opslaan van het feature in de database.";
    private static final String FIRST_PART_ERROR_MESSAGE_INVALID_GEOMETRY = "ERROR: Invalid geometry in ";
    private static final String MSG_GENERAL_EXCEPTION = "Er is een fout opgetreden: %s";
    private static final String MSG_INVALID_GEOMETRY_CONSTRUCTED_BBOX = "De bounding box die het systeem van de gegeven geometrie heeft afgeleid, is een ongeldige geometrie: '%s'. %s";
    private static final String MSG_TECHNICAL_ERROR = "Er is een onbekende technische fout opgetreden. Neem contact op met de klantenservice.";
    private static final String MSG_XSD_VALIDATION_ERROR = "XSD validatiefout: %s";
    private static final String MSG_XSD_VALIDATION_WARNING = "XSD validatiewaarschuwing: %s";
    private static final String MSG_UNKNOWN_CODELIST_VALUE_ERROR = "Waarde '%s' komt niet voor in codelijst '%s'.";
    private static final String MSG_CODELIST_VALUE_RESTRICED_ERROR = "Waarde '%s' is niet toegestaan. Enkel de waarde '%s' uit de codelijst '%s' is toegestaan. %s";
    private static final String MSG_BESTAND_LOCATIE_INVALID_EXTENTION = "Bestand locatie (%s) heeft een andere extensie dan '%s'. Enkel '%s' is toegestaan. %s";
    private static final String MSG_APPURTENANCETYPE_VALUE_FROM_WRONG_CODELIST_ERROR = "Het appurtenance type komt niet voor in een codelijst voor appurtenance types van het utility network type van het utiliteitsnet waarvan deze appurtenance onderdeel is.";
    private static final String MSG_INVALID_IMKL_FILE = "Er is een ongeldig IMKL bestand aangetroffen.";
    private static final String MSG_MULTIPLE_IMKL_FILES = "Er zijn meerdere IMKL bestanden of mappen aangetroffen.";
    private static final String MSG_NO_IMKL_FILES = "Er is geen IMKL bestand aangetroffen.";
    private static final String MSG_NO_ATTACHMENTS_ALLOWED = "Het is niet toegestaan bijlagen mee te leveren bij het IMKL bestand.";
    private static final String MSG_INVALID_ZIP_FILE = "ZIP file kan niet gelezen worden. Foutmelding: '%s'";
    private static final String MSG_FILE_NOT_REFERENCED = "Er is geen verwijzing naar het meegeleverde bestand '%s'.";
    private static final String MSG_GMLID_UNEQUAL_TO_INSPIREID = "INSPIRE ID (concatenatie van namespace, '-' en local ID) komt niet overeen met het GML ID van het feature.";
    private static final String MSG_GMLID_UNEQUAL_TO_NEN3610ID = "NEN3610 ID (concatenatie van namespace, '-' en local ID) komt niet overeen met het GML ID van het feature.";
    private static final String MSG_GMLID_VERKEERDE_NAMESPACE = "GML ID behoort niet tot uw namespace";
    private static final String MSG_GMLID_INVALID_FORMAT = "GML ID is niet conform NEN3610 ID formaat (GML ID bestaat uit de concatenatie van namespace, '-' en het local ID). '%s'";
    private static final String MSG_INSPIRE_ID_INVALID_FORMAT = "INSPIRE ID is niet correct gevuld (namespace moet 'nl.imkl' bevatten en het localID moet zijn opgebouwd uit: '<bronhoudercode>.<lokaalID>'). '%s'";
    private static final String MSG_NEN3610_ID_INVALID_FORMAT = "NEN3610 ID is niet correct gevuld (namespace moet 'nl.imkl' bevatten en het lokaalID moet zijn opgebouwd uit: '<bronhoudercode>.<lokaalID>'). '%s'";
    private static final String MSG_UNKNOWN_LINKED_FEATURE = "Verwijzing naar een niet meegeleverd feature met gml-id '%s'.";
    private static final String MSG_INVALID_BESTANDIDENTIFICATOR_NAME = "BestandIdentificator heeft een onjuist formaat: bestandIdentificator is opgebouwd uit: <namespace>-<lokaalID>.<bestandsnaam> '%s'.";
    private static final String MSG_WRONG_BESTANDIDENTIFICATOR_BRONHOUDERCODE = "Bronhoudercode uit bestandIdentificator is onjuist [%s]. '%s'";
    private static final String MSG_WRONG_BEHEERDER_BRONHOUDERCODE = "Bronhoudercode uit Beheerder feature is onjuist [%s]. '%s'";
    private static final String MSG_BESTANDIDENTIFICATOR_DOES_NOT_EXIST = "Er is een bestandsverwijzing aangetroffen: '%s'. Deze komt niet voor in de documentenopslag. %s";
    private static final String MSG_BESTAND_LOCATIE_NOT_FOUND_IN_ZIP = "Het bestand waarnaar verwezen wordt ('%s') is niet aanwezig in het ZIP bestand %s.";
    private static final String MSG_INVALID_NILVALUE = "Het '%s' attribuut moet ingevuld zijn, nilreason is niet toegestaan. '%s'";
    private static final String MSG_STANDAARDDIEPTELEGGING_INVALID_NUMBER_OF_DECIMALS = "De waarde voor de standaarddieptelegging heeft teveel decimalen. Maximaal twee decimalen zijn toegestaan. '%s'";
    private static final String MSG_MANDATORY_ELEMENT_HAS_NO_VALUE = "Element mag niet leeg zijn [%s]";
    private static final String MSG_ELEMENT_MAY_CONTAIN_NO_VALUE = "Element mag niet gevuld zijn [%s]";
    private static final String MSG_MANDATORY_ELEMENT_IF_OTHER_ELEMENT_EXISTS_NOT_FOUND = "Element '%s' is aanwezig, maar niet een van de elementen '%s'. Een van deze elementen is verplicht.";
    private static final String MSG_NO_EIGENTOPO_ALLOWED_WHEN_NIETBETROKKEN = "Eigen topografie is niet toegestaan omdat de bronhouder niet betrokken is.";
    private static final String MSG_NO_BIJLAGE_EISVOORZORGSMAATREGEL_ALLOWED_WHEN_NIETBETROKKEN = "Een bijlage eis voorzorgsmaatregel is niet toegestaan omdat de bronhouder niet betrokken is.";
    private static final String MSG_BIJLAGE_EISVOORZORGSMAATREGEL_COMPULSORY = "Minstens één bijlage eis voorzorgsmaatregel is verplicht omdat bij 'Belanghebbende' is aangegeven dat er een eis voorzorgsmaatregel geldt.";
    private static final String MSG_GEEN_EISVOORZORGSMAATREGEL_ALLOWED_WHEN_NIET_BETROKKEN = "Omdat de belanghebbende niet betrokken is, mag deze geen eis voorzorgsmaatregel opleggen";
    private static final String MSG_GEEN_NETINFORMATIE_ALLOWED_WHEN_NIET_BETROKKEN = "Omdat de belanghebbende niet betrokken is, mag deze geen utiliteitsnet aanleveren";
    private static final String MSG_UTILITEITSNET_COMPULSORY = "Minstens één element utiliteitsnet is verplicht omdat de bronhouder betrokken is.";

    private final List<ValidationMessage> validationMessages = new ArrayList<>();
    private final ValidationMessagesTracker validationMessagesTracker;
    private final long actualisatieId;
    private int errorCount = 0;

    private int lineNrOffset = 0;

    public ValidationMessageBuilder(final long actualisatieId, final ValidationMessagesTracker validationMessagesTracker) {
        super();
        this.actualisatieId = actualisatieId;
        this.validationMessagesTracker = validationMessagesTracker;
    }

    public boolean addAll(final List<ValidationMessage> validationMessages) {
        return this.validationMessages.addAll(validationMessages);
    }

    public static ValidationMessage createTechnicalError(final long aanleveringId) {
        ValidationMessage validationMessage = new ValidationMessage();
        validationMessage.setActualisatieId(aanleveringId);
        validationMessage.setCategory(ValidationMessage.ValidationMessageCategory.TECHNISCHE_FOUT);
        validationMessage.setType(ValidationMessage.ValidationMessageType.ERROR);
        validationMessage.setMessage(MSG_TECHNICAL_ERROR);
        validationMessage.setGmlId("-");
        return validationMessage;
    }

    private void addError(final ValidationMessage.ValidationMessageCategory category, final String messageText, final String gmlId) {
        if (addMessage(ValidationMessage.ValidationMessageType.ERROR, category, messageText, gmlId)) {
            errorCount++;
        }
    }

    private void addWarning(final ValidationMessage.ValidationMessageCategory category, final String messageText, final String gmlId) {
        addMessage(ValidationMessage.ValidationMessageType.WARNING, category, messageText, gmlId);
    }

    /**
     * Add the message only if the max messages is not reached. If after adding this message the max is reached, add the {@link #MSG_TOO_MUCH_MESSAGES} message too.
     */
    private boolean addMessage(final ValidationMessage.ValidationMessageType type, final ValidationMessage.ValidationMessageCategory category, final String messageText, final String gmlId) {
        boolean messageAdded = false;
        if (!hasMaxNumberOfMessages()) {
            ValidationMessage msg = new ValidationMessage();
            msg.setActualisatieId(actualisatieId);
            msg.setMessage(messageText);
            msg.setCategory(category);
            msg.setGmlId(gmlId == null ? "" : gmlId);
            msg.setType(type);
            if (!exists(msg)) {
                validationMessages.add(msg);
                validationMessagesTracker.record();
                messageAdded = true;
            } else {
                return false;
            }

            // check if we have reached max number of messages now
            if (hasMaxNumberOfMessages()) {
                ValidationMessage maxReachedMessage = new ValidationMessage();
                maxReachedMessage.setActualisatieId(actualisatieId);
                maxReachedMessage.setMessage(String.format(MSG_TOO_MUCH_MESSAGES, validationMessagesTracker.getMaxMessages()));
                maxReachedMessage.setCategory(ValidationMessage.ValidationMessageCategory.TE_VEEL_MELDINGEN);
                maxReachedMessage.setGmlId(null);
                maxReachedMessage.setType(ValidationMessage.ValidationMessageType.ERROR);
                if (!exists(maxReachedMessage)) {
                    validationMessages.add(maxReachedMessage);
                }
                if (ValidationMessage.ValidationMessageType.ERROR != type) {
                    errorCount++;
                }
            }
        }
        return messageAdded;
    }

    /**
     * Check if a message like the given one already exists in the list.
     *
     * @param message the message to check.
     * @return true if it's already in the list.
     */
    private boolean exists(final ValidationMessage message) {
        boolean exists = false;
        for (ValidationMessage testMessage : validationMessages) {
            if (isSame(message, testMessage)) {
                exists = true;
                break;
            }
        }
        return exists;
    }

    private static boolean isSame(final ValidationMessage message, final ValidationMessage testMessage) {
        return Objects.equals(message.getMessage(), testMessage.getMessage())
                && Objects.equals(message.getGmlId(), testMessage.getGmlId())
                && Objects.equals(message.getCategory(), testMessage.getCategory())
                && Objects.equals(message.getType(), testMessage.getType());
    }

    public boolean hasMaxNumberOfMessages() {
        return validationMessagesTracker.isMaxMessagesReached();
    }

    public int getErrorCount() {
        return errorCount;
    }

    public boolean hasErrors() {
        return errorCount > 0;
    }

    public void reset() {
        validationMessages.clear();
    }

    public void addErrorNoGmlId(final String featureType) {
        addError(ValidationMessage.ValidationMessageCategory.GEEN_GML_ID, String.format(MSG_NO_GMLID, featureType), null);
    }

    public void addErrorTechnical() {
        addError(ValidationMessage.ValidationMessageCategory.TECHNISCHE_FOUT, MSG_TECHNICAL_ERROR, null);
    }

    public void addWarningNillValueButNoNillReasonSpecified(final String gmlId, final String elementName) {
        addWarning(ValidationMessage.ValidationMessageCategory.LEGE_WAARDE_ZONDER_NILREASON, String.format(MSG_NILVALUE_BUT_NO_NILREASON, elementName, getFeatureIndication(getLineNrOffset())), gmlId);
    }

    public void addMandatoryElementNotFound(final String gmlId, final String elementName) {
        addError(ValidationMessage.ValidationMessageCategory.VERPLICHT_ATTRIBUUT_NIET_GEVONDEN, String.format(MSG_MANDATORY_ELEMENT_NOT_FOUND, elementName), gmlId);
    }

    public void addErrorInvalidUomValueSpecified(final String gmlId, final String elementName, final List<String> allowedValues) {
        addError(ValidationMessage.ValidationMessageCategory.ONGELDIGE_UOM_WAARDE, String.format(MSG_INVALID_UOM_VALUE, elementName, StringUtils.join(allowedValues, ','), getFeatureIndication(getLineNrOffset())), gmlId);
    }

    public void addErrorInvalidRotatiehoek(final String gmlId, final String elementName, final String allowedValueMsg) {
        addError(ValidationMessage.ValidationMessageCategory.ONGELDIGE_WAARDE, String.format(MSG_INVALID_VALUE, elementName, allowedValueMsg, getFeatureIndication(getLineNrOffset())), gmlId);
    }

    public void addErrorImklElementNotAllowed(final String gmlId, final String elementName) {
        addError(ValidationMessage.ValidationMessageCategory.ELEMENT_NIET_TOEGESTAAN, String.format(MSG_IMKL_ELEMENT_NOT_PERMITTED, elementName, getFeatureIndication(getLineNrOffset())), gmlId);
    }

    public void addErrorImklElementMandatory(final String gmlId, final String elementName) {
        addError(ValidationMessage.ValidationMessageCategory.VERPLICHT_ELEMENT_HEEFT_GEEN_WAARDE, String.format(MSG_IMKL_ELEMENT_MANDATORY, elementName, getFeatureIndication(getLineNrOffset())), gmlId);
    }

    public void addWarningUnknownFeatureType(final String featureType) {
        addWarning(ValidationMessage.ValidationMessageCategory.ONBEKEND_FEATURE_TYPE, String.format(MSG_UNKNOWN_FEATURE_TYPE, featureType, getFeatureIndication(getLineNrOffset())), null);
    }

    public List<ValidationMessage> getValidationMessages() {
        return validationMessages;
    }

    public List<ValidationMessage> getValidationMessagesSorted() {
        // sort by GmlId descending, with null values last
        Collections.sort(validationMessages, new Comparator<ValidationMessage>() {
            @Override
            public int compare(final ValidationMessage validationMessage, final ValidationMessage otherValidationMessage) {
                final String gmlId = validationMessage.getGmlId();
                final String gmlIdOther = otherValidationMessage.getGmlId();
                if (gmlId == null) {
                    return gmlIdOther == null ? 0 : 1;
                }
                if (gmlIdOther == null) {
                    return -1;
                }
                return gmlId.compareTo(gmlIdOther);
            }
        });
        return validationMessages;
    }

    public void addErrorDatabaseInsert(final UncategorizedSQLException ex, final String gmlId) {
        if (ex.getCause().getMessage().startsWith(FIRST_PART_ERROR_MESSAGE_INVALID_GEOMETRY)) {
            addErrorInvalidGeometry(gmlId);
        } else {
            addError(ValidationMessage.ValidationMessageCategory.ONBEKENDE_FOUT_DATABASE_INSERT, String.format(MSG_UNKNOWN_ERROR_DB_INSERT, ex.getMessage()), gmlId);
        }
    }

    public void addErrorDatabaseInsertDuplicateKey(final String gmlId) {
        addError(ValidationMessage.ValidationMessageCategory.DUPLICATE_KEY, MSG_DUPLICATE_KEY_ERROR_DB_INSERT, gmlId);
    }

    public void addErrorDatabaseInsertDuplicateKey(final String gmlId, final String customMessage) {
        addError(ValidationMessage.ValidationMessageCategory.DUPLICATE_KEY, customMessage, gmlId);
    }

    public void addGeneralError(final Exception e) {
        addError(ValidationMessage.ValidationMessageCategory.GENERAL, String.format(MSG_GENERAL_EXCEPTION, e.getMessage()), null);
    }

    public void addErrorInvalidGeometryExactLineNr(final String gmlId, final String reason) {
        addError(ValidationMessage.ValidationMessageCategory.ONGELDIGE_GEOMETRIE, String.format(MSG_INVALID_GEOMETRY, cleanString(reason), getFeatureIndication(getLineNrOffset())), gmlId);
    }

    public void addErrorInvalidGeometry(final String gmlId, final String reason) {
        String featureIndication = "";
        if (getLineNrOffset() > 0) {
            featureIndication = getFeatureIndication(getLineNrOffset());
        }
        addError(ValidationMessage.ValidationMessageCategory.ONGELDIGE_GEOMETRIE, String.format(MSG_INVALID_GEOMETRY, cleanString(reason), featureIndication), gmlId);
    }

    public void addErrorInvalidConstructedBbox(final String gmlId, final String reason) {
        addError(ValidationMessage.ValidationMessageCategory.ONGELDIGE_GEOMETRIE, String.format(MSG_INVALID_GEOMETRY_CONSTRUCTED_BBOX, reason, getFeatureIndication(getLineNrOffset())), gmlId);
    }

    private void addErrorInvalidGeometry(final String gmlId) {
        addError(ValidationMessage.ValidationMessageCategory.ONGELDIGE_GEOMETRIE, String.format(MSG_INVALID_GEOMETRY_NO_REASON, ""), gmlId);
    }

    public void addErrorXsdValidation(final String message) {
        addError(ValidationMessage.ValidationMessageCategory.XSD_VALIDATIE, String.format(MSG_XSD_VALIDATION_ERROR, message), null);
    }

    public void addWarningXsdValidation(final String message) {
        addWarning(ValidationMessage.ValidationMessageCategory.XSD_VALIDATIE, String.format(MSG_XSD_VALIDATION_WARNING, message), null);
    }

    public void addErrorAppurtenanceTypeFromWrongCodelist(final String gmlId) {
        addError(ValidationMessage.ValidationMessageCategory.ONBEKENDE_CODE_CODELIJST, MSG_APPURTENANCETYPE_VALUE_FROM_WRONG_CODELIST_ERROR, gmlId);
    }

    void addErrorValueNotInCodelist(final String codelistName, final String codelistValue, final String gmlId) {
        addError(ValidationMessage.ValidationMessageCategory.ONBEKENDE_CODE_CODELIJST, String.format(MSG_UNKNOWN_CODELIST_VALUE_ERROR, codelistValue, codelistName), gmlId);
    }

    void addErrorValueIsNotRestrictedCodelistValue(final String codelistName, final String codelistValue, final String restrictedCodelistValue, final String gmlId) {
        addError(ValidationMessage.ValidationMessageCategory.ONGELDIGE_WAARDE, String.format(MSG_CODELIST_VALUE_RESTRICED_ERROR, codelistValue, restrictedCodelistValue, codelistName, getFeatureIndication(getLineNrOffset())), gmlId);
    }

    public void addErrorBestandLocatieExtention(final String gmlId, final String fileName, final String extentionAllowed) {
        addError(ValidationMessage.ValidationMessageCategory.ONGELDIGE_WAARDE, String.format(MSG_BESTAND_LOCATIE_INVALID_EXTENTION, fileName, extentionAllowed, extentionAllowed, getFeatureIndication(getLineNrOffset())), gmlId);
    }

    public void addErrorInvalidImklFile() {
        addError(ValidationMessage.ValidationMessageCategory.ONGELDIGE_ZIP_INHOUD, MSG_INVALID_IMKL_FILE, null);
    }

    public void addErrorMultipleImklFiles() {
        addError(ValidationMessage.ValidationMessageCategory.ONGELDIGE_ZIP_INHOUD, MSG_MULTIPLE_IMKL_FILES, null);
    }

    public void addErrorNoImklFile() {
        addError(ValidationMessage.ValidationMessageCategory.ONGELDIGE_ZIP_INHOUD, MSG_NO_IMKL_FILES, null);
    }

    public void addErrorNoAttachmentsAllowed() {
        addError(ValidationMessage.ValidationMessageCategory.ONGELDIGE_ZIP_INHOUD, MSG_NO_ATTACHMENTS_ALLOWED, null);
    }

    public void addErrorInvalidZipFile(final String message) {
        addError(ValidationMessage.ValidationMessageCategory.ONGELDIGE_ZIP_INHOUD, String.format(MSG_INVALID_ZIP_FILE, message), null);
    }

    public void addErrorFileNotReferenced(final String fileName) {
        addError(ValidationMessage.ValidationMessageCategory.ONGELDIGE_ZIP_INHOUD, String.format(MSG_FILE_NOT_REFERENCED, fileName), null);
    }

    public void addErrorGmlIdDoesntCompareToInspireId(final String gmlId) {
        addError(ValidationMessage.ValidationMessageCategory.NO_UNICITY, MSG_GMLID_UNEQUAL_TO_INSPIREID, gmlId);
    }

    public void addErrorGmlIdDoesntCompareToNen3610Id(final String gmlId) {
        addError(ValidationMessage.ValidationMessageCategory.NO_UNICITY, MSG_GMLID_UNEQUAL_TO_NEN3610ID, gmlId);
    }
    
    public void addErrorVerkeerdeNamespace(final String gmlId) {
        addError(ValidationMessage.ValidationMessageCategory.VERKEERDE_NAMESPACE, MSG_GMLID_VERKEERDE_NAMESPACE, gmlId);
    }

    public void addErrorUnknownLinkedFeature(final String gmlidFeaturemember, final String gmlidLinkedFeaturemember) {
        addError(ValidationMessage.ValidationMessageCategory.ONBEKENDE_FEATURE_VERWIJZING, String.format(MSG_UNKNOWN_LINKED_FEATURE, gmlidLinkedFeaturemember), gmlidFeaturemember);
    }

    public void addXMLProcessingError(final String msg, final String gmlId) {
        addError(ValidationMessage.ValidationMessageCategory.XML_VERWERKING, msg + " " + getFeatureIndication(getLineNrOffset()), gmlId);
    }

    public void addXMLProcessingError(final String msg) {
        addError(ValidationMessage.ValidationMessageCategory.XML_VERWERKING, msg, null);
    }

    public void addErrorInvalidBestandIdentificatorFormat(final String gmlId) {
        addError(ValidationMessage.ValidationMessageCategory.ELEMENT_NIET_TOEGESTAAN, String.format(MSG_INVALID_BESTANDIDENTIFICATOR_NAME, getFeatureIndication(getLineNrOffset())), gmlId);
    }

    public void addErrorWrongBestandIdentificatorBronhoudercode(final String gmlId, final String bronhouderCode) {
        addError(ValidationMessage.ValidationMessageCategory.ELEMENT_NIET_TOEGESTAAN, String.format(MSG_WRONG_BESTANDIDENTIFICATOR_BRONHOUDERCODE, bronhouderCode, getFeatureIndication(getLineNrOffset())), gmlId);
    }

    public void addErrorWrongBeheerderBronhoudercode(final String gmlId, final String bronhouderCode) {
        addError(ValidationMessage.ValidationMessageCategory.ONGELDIGE_WAARDE, String.format(MSG_WRONG_BEHEERDER_BRONHOUDERCODE, bronhouderCode, getFeatureIndication(getLineNrOffset())), gmlId);
    }

    public void addErrorBestandIdentificatorDoesNotExist(final String gmlId, final String fileIdentificator) {
        addError(ValidationMessage.ValidationMessageCategory.ELEMENT_NIET_TOEGESTAAN, String.format(MSG_BESTANDIDENTIFICATOR_DOES_NOT_EXIST, fileIdentificator, getFeatureIndication(getLineNrOffset())), gmlId);
    }

    public void addErrorBestandLocatieNotFoundInZip(final String gmlId, final String fileName) {
        addError(ValidationMessage.ValidationMessageCategory.ONGELDIGE_WAARDE, String.format(MSG_BESTAND_LOCATIE_NOT_FOUND_IN_ZIP, fileName, getFeatureIndication(getLineNrOffset())), gmlId);
    }

    public void addErrorInvalidNilReasson(final String gmlId, final String attributeName) {
        addError(ValidationMessage.ValidationMessageCategory.ELEMENT_NIET_TOEGESTAAN, String.format(MSG_INVALID_NILVALUE, attributeName, getFeatureIndication(getLineNrOffset())), gmlId);
    }

    private static String cleanString(final String reason) {
        return reason.trim() + " ";
    }

    private static String getFeatureIndication(final int featureStartTagLineNr) {
        return "[FeatureMember starting at line number: " + featureStartTagLineNr + "]";
    }

    public void setLineNrOffset(final int lineNrOffset) {
        this.lineNrOffset = lineNrOffset;
    }

    public int getLineNrOffset(){
        return lineNrOffset;
    }

    public void addErrorGmlIdFormatIncorrect(final String gmlId) {
        addError(ValidationMessage.ValidationMessageCategory.ONGELDIG_FORMAAT, String.format(MSG_GMLID_INVALID_FORMAT, getFeatureIndication(getLineNrOffset())), gmlId);
    }

    public void addErrorInspireIdIncorrect(final String gmlId) {
        addError(ValidationMessage.ValidationMessageCategory.ONGELDIG_FORMAAT, String.format(MSG_INSPIRE_ID_INVALID_FORMAT, getFeatureIndication(getLineNrOffset())), gmlId);
    }

    public void addErrorNEN3610IdIncorrect(final String gmlId) {
        addError(ValidationMessage.ValidationMessageCategory.ONGELDIG_FORMAAT, String.format(MSG_NEN3610_ID_INVALID_FORMAT, getFeatureIndication(getLineNrOffset())), gmlId);
    }

    public void addErrorInvalidNumberOfDecimalsInStandaardDieptelegging(final String gmlId) {
        addError(ValidationMessage.ValidationMessageCategory.ONGELDIG_FORMAAT,
                String.format(MSG_STANDAARDDIEPTELEGGING_INVALID_NUMBER_OF_DECIMALS, getFeatureIndication(getLineNrOffset())), gmlId);
    }
    public void addErrorEmptyElement(final String gmlid) {
        addError(ValidationMessage.ValidationMessageCategory.VERPLICHT_ELEMENT_HEEFT_GEEN_WAARDE,
                String.format(MSG_MANDATORY_ELEMENT_HAS_NO_VALUE, getFeatureIndication(getLineNrOffset())), gmlid);
    }

    public void addErrorElementContentNotAllowed(final String gmlId) {
        addError(ValidationMessage.ValidationMessageCategory.ONGELDIGE_WAARDE,
                String.format(MSG_ELEMENT_MAY_CONTAIN_NO_VALUE, getFeatureIndication(getLineNrOffset())), gmlId);
    }

    void addOneSubElementIsStrictlyMandatoryIfElementExistsError(final String gmlId, final String missingElementName, final String subElementNames) {
        addError(ValidationMessage.ValidationMessageCategory.VERPLICHT_ATTRIBUUT_NIET_GEVONDEN, String.format(MSG_MANDATORY_ELEMENT_IF_OTHER_ELEMENT_EXISTS_NOT_FOUND, missingElementName, subElementNames), gmlId);
    }

    public void addErrorNoEigenTopoAllowedWhenNietBetrokken() {
        addError(ValidationMessage.ValidationMessageCategory.ELEMENT_NIET_TOEGESTAAN, MSG_NO_EIGENTOPO_ALLOWED_WHEN_NIETBETROKKEN, null);
    }

    public void addErrorNoBijlageEisVoorzorgsmaatregelAllowedWhenNietBetrokken() {
        addError(ValidationMessage.ValidationMessageCategory.ELEMENT_NIET_TOEGESTAAN, MSG_NO_BIJLAGE_EISVOORZORGSMAATREGEL_ALLOWED_WHEN_NIETBETROKKEN, null);
    }

    public void addErrorBijlageEisVoorzorgsmaatregelCompulsory() {
        addError(ValidationMessage.ValidationMessageCategory.VERPLICHT_ATTRIBUUT_NIET_GEVONDEN, MSG_BIJLAGE_EISVOORZORGSMAATREGEL_COMPULSORY, null);
    }

    public void addErrorNoEisVoorzorgsmaatregelAllowedWhenNietBetrokken() {
        addError(ValidationMessage.ValidationMessageCategory.ONGELDIGE_WAARDE, MSG_GEEN_EISVOORZORGSMAATREGEL_ALLOWED_WHEN_NIET_BETROKKEN, null);
    }

    public void addErrorNoNetinformatieAllowedWhenNietBetrokken() {
        addError(ValidationMessage.ValidationMessageCategory.ONGELDIGE_WAARDE, MSG_GEEN_NETINFORMATIE_ALLOWED_WHEN_NIET_BETROKKEN, null);
    }

    public void addErrorUtiliteitsnetCompulsoryWhenBetrokken() {
        addError(ValidationMessage.ValidationMessageCategory.VERPLICHT_ATTRIBUUT_NIET_GEVONDEN, MSG_UTILITEITSNET_COMPULSORY, null);
    }
}