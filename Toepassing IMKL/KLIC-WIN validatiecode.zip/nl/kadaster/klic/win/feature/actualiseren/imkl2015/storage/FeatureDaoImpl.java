package nl.kadaster.klic.win.feature.actualiseren.imkl2015.storage;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.FeatureWithValidation;
import nl.kadaster.klic.win.util.NiStoreUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.JdbcUtils;
import org.springframework.jdbc.support.SQLExceptionSubclassTranslator;

import javax.sql.DataSource;
import java.sql.BatchUpdateException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class FeatureDaoImpl implements FeatureDao {

    private static final Logger LOG = LoggerFactory.getLogger(FeatureDaoImpl.class);

    private static final String TABLENAME = "feature";
    private static final String FEATURE_SA_PLACEHOLDER = NiStoreUtil.SA_PLACEHOLDER1;
    
    private static final String MULTI_ROW_INSERT_CONCEPT_STMT = "insert into " + FEATURE_SA_PLACEHOLDER
            + "( gmlid"
            + ", bronhoudercode"
            + ", featuretype_id"
            + ", currentstatus"
            + ", wionthema"
            + ", inspirethema"
            + ", geometry"
            + ", type"
            + ", label"
            + ", bestand_id "
            + ", rotatiehoek"
            + ", aangrijping_horizontaal"
            + ", aangrijping_verticaal"
            + ") values ";
    private static final String MULTI_ROW_INSERT_VALUES_PRECEEDING_COMMA = ",(?,?,?,?,?,?,?,?,?,?,?,?,?)";
    private static final String MULTI_ROW_INSERT_VALUES_NON_PRECEEDING_COMMA = "(?,?,?,?,?,?,?,?,?,?,?,?,?)";

    private static final int EPSG_28992 = 28992;
    private static final java.lang.String QUERY_GET_PROD_THEMAS_BY_BRONHOUDERCODE_AND_AREA =
            "select distinct code_short " +
            "from ni_store.feature, ni_store.thema " +
            "where bronhoudercode=? and wionthema=thema.id " +
            "AND ST_Intersects(geometry, ST_GeomFromText(?, " + EPSG_28992 + "))";

    private static final String QUERY_GET_CONCEPT_APPURTENANCES_WITH_INCORRECT_TYPE = "" +
            "WITH cte_codelists (shortcode, codelistnames) AS (" +
            "  VALUES" +
            "    ('electricity',        ARRAY['ElectricityAppurtenanceTypeIMKLValue', 'ElectricityAppurtenanceTypeValue'])," +
            "    ('oilGasChemical',     ARRAY['OilGasChemicalsAppurtenanceTypeIMKLValue', 'OilGasChemicalsAppurtenanceTypeValue'])," +
            "    ('sewer',              ARRAY['SewerAppurtenanceTypeIMKLValue', 'SewerAppurtenanceTypeValue'])," +
            "    ('water',              ARRAY['WaterAppurtenanceTypeIMKLValue', 'WaterAppurtenanceTypeValue'])," +
            "    ('thermal',            ARRAY['ThermalAppurtenanceTypeIMKLValue'])," +
            "    ('telecommunications', ARRAY['TelecommunicationsAppurtenanceTypeIMKLValue'])" +
            ") " +
            "SELECT gmlid" +
            "  FROM " + FEATURE_SA_PLACEHOLDER + " AS ft" +
            "     , ni_store.thema" +
            "     , ni_store.codelist" +
            "     , ni_store.codelistvalue" +
            "     , cte_codelists" +
            " WHERE featuretype_id = 1 " +
            "   AND inspirethema = thema.id " +
            "   AND bronhoudercode = ?" +
            "   AND codelistvalue.code = ft.type " +
            "   AND codelistvalue.codelist_id = codelist.id " +
            "   AND cte_codelists.shortcode = code_short" +
            "   AND NOT (codelist.name = ANY(codelistnames))";

    private static final String COLUMN_GMLID = "gmlid";
    private static final String COLUMN_ERROR_REASON = "error_reason";
    private static final String QUERY_GET_GEOMETRY_ERRORS =
            "select gmlid as " + COLUMN_GMLID + ", st_isvalidreason(geometry) as " + COLUMN_ERROR_REASON + " " +
            " from " + FEATURE_SA_PLACEHOLDER + " " +
            " where st_isvalid(geometry) = false " +
            " and bronhoudercode = ?";

    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    /**
     * Custom implementation at low level to be able to retrieve the generated ids.
     * Springs GeneratedKeyHolder is not supported for batch updates.
     *
     * IMPORTANT NOTE: When encoutering issues (hanging threads, query, ..) in regard to this batched insert, check
     *                 the batch size (nr of features in the list) and the comment.
     *                 This batch size is defined in <code>{@link nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.BatchJobSettings}</code>
     *
     * @param features List of features to store
     */
    @Override
    public void storeBatch(final List<FeatureWithValidation> features) throws BatchUpdateException {
        DataSource ds = jdbcTemplate.getDataSource();
        StringBuilder insertQuery;
        String bronhoudercode;
        
        if (features.isEmpty()) {
            return;
        }
        
        bronhoudercode = features.get(0).getBronhoudercode();
        insertQuery = new StringBuilder(NiStoreUtil.adaptQueryForStagingArea(bronhoudercode, MULTI_ROW_INSERT_CONCEPT_STMT, TABLENAME));
        insertQuery.append(MULTI_ROW_INSERT_VALUES_NON_PRECEEDING_COMMA);
        final int featuresSize = features.size();
        for (int i = 1; i< featuresSize; i++) {
            insertQuery.append(MULTI_ROW_INSERT_VALUES_PRECEEDING_COMMA);
        }

        try (Connection connection = ds.getConnection();
             PreparedStatement stmnt = connection.prepareStatement(insertQuery.toString(), PreparedStatement.RETURN_GENERATED_KEYS)) {
             connection.setAutoCommit(false);
            int pos = 1;
            for (FeatureWithValidation feature : features) {
                stmnt.setString(pos++, feature.getGmlId());
                stmnt.setString(pos++, feature.getBronhoudercode());
                stmnt.setLong(pos++, (long)feature.getFeatureType().getKey());
                stmnt.setString(pos++, feature.getCurrentStatus());
                setNullableLong(stmnt, pos++, feature.getWionthema());
                setNullableLong(stmnt, pos++, feature.getInspirethema());
                stmnt.setObject(pos++, feature.getGeometry());
                stmnt.setString(pos++, feature.getType());
                stmnt.setString(pos++, feature.getLabel());
                stmnt.setString(pos++, feature.getBestandIdentificator());
                stmnt.setString(pos++, feature.getRotatiehoek());
                stmnt.setString(pos++, feature.getAangrijpingHorizontaal());
                stmnt.setString(pos++, feature.getAangrijpingVerticaal());
            }
            stmnt.executeUpdate();

            List<Long> generatedKeys = new ArrayList<>();
            ResultSet keys = stmnt.getGeneratedKeys();
            while (keys.next()) {
                generatedKeys.add(keys.getLong(1));
            }
            JdbcUtils.closeResultSet(keys);

            stmnt.clearBatch();
            connection.commit();

            for (int i = 0; i < generatedKeys.size(); i++) {
                features.get(i).setId(generatedKeys.get(i));
            }
        }  catch (SQLException sqle) {
            LOG.error("Error executing feature multi row insert", sqle);
            throw new SQLExceptionSubclassTranslator().translate(null, null, sqle);
        }
    }

    /*
     * DatabaseHelper.setNullableLong would give
     * java.lang.IllegalArgumentException: Can't change resolved type for param: 5 from 1700 to 20
     * at org.postgresql.core.v3.SimpleParameterList.setResolvedType(SimpleParameterList.java:280)
     */
    private static void setNullableLong(final PreparedStatement stmnt, final int col, final Long value) throws SQLException {
        if (value == null) {
            stmnt.setObject(col, null);
        } else {
            stmnt.setLong(col, value);
        }
    }

    @Override
    public List<String> getImklThemesByNetbeheerderAndArea(final String bronhoudercode, final String wktArea) {
        return jdbcTemplate.query(new PreparedStatementCreator() {
            @Override
            public PreparedStatement createPreparedStatement(final Connection connection) throws SQLException {
                final PreparedStatement ps = connection.prepareStatement(QUERY_GET_PROD_THEMAS_BY_BRONHOUDERCODE_AND_AREA);
                int pos = 1;
                ps.setString(pos++, bronhoudercode);
                ps.setString(pos, wktArea);
                return ps;
            }
        }, new RowMapper<String>() {
            @Override
            public String mapRow(final ResultSet rs, final int rowNum) throws SQLException {
                return rs.getString(1);
            }
        });
    }

    @Override
    public List<String> getFeaturesWithIncorrectAppurtenanceType(final String bronhoudercode) {
        return jdbcTemplate.query(new PreparedStatementCreator() {
            @Override
            public PreparedStatement createPreparedStatement(final Connection connection) throws SQLException {
                final String sql = NiStoreUtil.adaptQueryForStagingArea(bronhoudercode, QUERY_GET_CONCEPT_APPURTENANCES_WITH_INCORRECT_TYPE, TABLENAME);
                final PreparedStatement ps = connection.prepareStatement(sql);
                ps.setString(1, bronhoudercode);
                return ps;
            }
        }, new RowMapper<String>() {
            @Override
            public String mapRow(final ResultSet rs, final int rowNum) throws SQLException {
                return rs.getString(1);
            }
        });
    }

    @Override
    public Map<String, String> getGeometryErrors(final String bronhoudercode) {
        return jdbcTemplate.query(new PreparedStatementCreator() {
            @Override
            public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
                final String sql = NiStoreUtil.adaptQueryForStagingArea(bronhoudercode, QUERY_GET_GEOMETRY_ERRORS, TABLENAME);
                final PreparedStatement ps = connection.prepareStatement(sql);
                ps.setString(1, bronhoudercode);
                return ps;
            }
        }, new ResultSetExtractor<Map>() {
            @Override
            public Map extractData(ResultSet rs) throws SQLException, DataAccessException {
                Map<String, String> mapRet = new TreeMap<String, String>();
                while (rs.next()) {
                    mapRet.put(rs.getString(COLUMN_GMLID), rs.getString(COLUMN_ERROR_REASON));
                }
                return mapRet;
            }
        });
    }

}
