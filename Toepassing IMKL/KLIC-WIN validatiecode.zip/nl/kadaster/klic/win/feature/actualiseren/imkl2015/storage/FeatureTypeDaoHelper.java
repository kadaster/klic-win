package nl.kadaster.klic.win.feature.actualiseren.imkl2015.storage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;

/**
 * Code shared by the InspireFeatureTypeDao and the WionFeatureTypeDao. 
 *
 */
public class FeatureTypeDaoHelper {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    Long findId(final String sql, final String featureType) {
        Long id = null;
        final List<Long> results = jdbcTemplate.query(new PreparedStatementCreator() {
            @Override
            public PreparedStatement createPreparedStatement(final Connection connection) throws SQLException {
                final PreparedStatement ps = connection.prepareStatement(sql);
                ps.setString(1, featureType);
                return ps;
            }
        }, new RowMapper<Long>() {
            @Override
            public Long mapRow(final ResultSet rs, final int rowNum) throws SQLException {
                return rs.getLong(1);
            }
        });
        if (results != null && !results.isEmpty()) {
            id = results.get(0);
        }
        return id;
    }

}
