package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.UtilityLink;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.stream.events.StartElement;

public class CentrelineGeometryHandler extends AbstractElementHandler implements ElementHandler<UtilityLink> {

    @Override
    public boolean shouldHandle(StartElement element) {
        return sameQName(Elements.CENTRELINE_GEOMETRY, element.getName());
    }

    @Override
    public void handle(StartElement element, FeatureLinks featureLinks, UtilityLink utilityLink, StaxEventReader staxEventReader, ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        utilityLink.setGeometry(
                GeometryExtractor.extract(element.getName(), utilityLink, staxEventReader, validationMessageBuilder)
        );
    }
}
