package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.context;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.ImklReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.data.BatchJobData;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.data.BatchJobThreadData;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.validation.ImklValidator;
import nl.kadaster.klic.win.feature.domain.InformatieSoort;
import org.springframework.beans.factory.annotation.Autowired;

public class BatchJobThreadContext {

    private final ImklReader netinformatieImklReader;
    private final ImklReader beheerdersinformatieImklReader;
    private final ImklValidator imklValidator;

    @Autowired
    public BatchJobThreadContext(final ImklReader netinformatieImklReader, final ImklReader beheerdersinformatieImklReader, final ImklValidator imklValidator) {
        this.netinformatieImklReader = netinformatieImklReader;
        this.beheerdersinformatieImklReader = beheerdersinformatieImklReader;
        this.imklValidator = imklValidator;
    }

    /**
     * Depending on the {@link InformatieSoort}, the correct {@link ImklReader} will be put on the
     *   {@link BatchJobThreadData} object.
     * @param batchJobData The data for the entire batch job
     * @return a new {@link BatchJobThreadData} object in which a thread can store its data.
     */
    public BatchJobThreadData getBatchJobThreadData(final BatchJobData batchJobData) {

        switch (batchJobData.getInformatieSoort()) {
            case BEHEERDERSINFORMATIE:
                return new BatchJobThreadData(batchJobData, imklValidator, beheerdersinformatieImklReader);

            case NETINFORMATIE:
            default:
                return new BatchJobThreadData(batchJobData, imklValidator, netinformatieImklReader);
        }

    }
}
