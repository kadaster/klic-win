package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.data;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * Keeps track of the number of validation messages over all running threads
 */
public class ValidationMessagesTracker {

    private final int maxMessages;
    private final AtomicInteger currentNrOfMessages = new AtomicInteger();

    public ValidationMessagesTracker(final int maxMessages) {
        this.maxMessages = maxMessages;
    }

    public int record() {
        return currentNrOfMessages.incrementAndGet();
    }

    public boolean isMaxMessagesReached() {
        return currentNrOfMessages.get() >= maxMessages;
    }

    public int getMaxMessages() {
        return maxMessages;
    }
}
