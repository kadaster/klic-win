package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.KabelOfLeiding;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ValidationRule;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.BuismateriaalTypeHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.CurrentStatusHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.DiepteLeggingHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.GeonauwkeurigheidXyHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ImklExtraGeometrieHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ImklForbiddenElements;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ImklHeeftExtraInformatieHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.InNetworkNetworkHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.InspireIdHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.KabeldiameterHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.LabelHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.LinkNetworkHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.OmschrijvingHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.PipeDiameterElement;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ToelichtingHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.UtilityDeliveryTypeHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ValidFromHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.VerticalPositionHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.WarningTypeHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.WaterTypeHandler;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;
import org.springframework.beans.factory.annotation.Autowired;

import javax.xml.namespace.QName;
import java.util.List;

public class WaterleidingStaxMapper extends StaxMapper<KabelOfLeiding> {

    @Autowired
    private BuismateriaalTypeHandler buismateriaalTypeHandler;

    @Autowired
    private GeonauwkeurigheidXyHandler geonauwkeurigheidXyHandler;

    @Autowired
    private WarningTypeHandler warningTypeHandler;

    @Autowired
    private CurrentStatusHandler currentStatusHandler;

    @Autowired
    private WaterTypeHandler waterTypeHandler;

    @Autowired
    private UtilityDeliveryTypeHandler utilityDeliveryTypeHandler;

    @Override
    void initElementHandlers() {
        super.initElementHandlers();
        addElementHandler(new InspireIdHandler());
        addElementHandler(new ValidFromHandler());
        addElementHandler(new PipeDiameterElement());
        addElementHandler(new VerticalPositionHandler());
        addElementHandler(new ImklForbiddenElements(Elements.CABLES, Elements.PIPES));
        addElementHandler(utilityDeliveryTypeHandler);
        addElementHandler(warningTypeHandler);
        addElementHandler(currentStatusHandler);
        addElementHandler(new KabeldiameterHandler());
        addElementHandler(geonauwkeurigheidXyHandler);
        addElementHandler(new ToelichtingHandler());
        addElementHandler(new LabelHandler());
        addElementHandler(new OmschrijvingHandler());
        addElementHandler(waterTypeHandler);
        addElementHandler(buismateriaalTypeHandler);

        // associations
        addElementHandler(new InNetworkNetworkHandler());
        addElementHandler(new LinkNetworkHandler());
        addElementHandler(new DiepteLeggingHandler());
        addElementHandler(new ImklHeeftExtraInformatieHandler());
        addElementHandler(new ImklExtraGeometrieHandler());
    }

    @Override
    boolean canHandle(final QName element) {
        return Elements.WATERLEIDING.equals(element);
    }

    @Override
    protected KabelOfLeiding createDomainObject() {
        return new KabelOfLeiding();
    }

    @Override
    List<ValidationRule> getValidationRules() {
        final List<ValidationRule> validationRules = super.getValidationRules();
        validationRules.add(new ValidationRule(Elements.INSPIRE_ID).withImklStrictlyMandatory());
        return validationRules;
    }

    @Override
    protected QName getBaseElement() {
        return Elements.WATERLEIDING;
    }

    @Override
    public QName getInspireType() {
        return Elements.INSPIRE_WATERPIPE;
    }

}
