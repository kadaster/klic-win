package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import org.springframework.beans.factory.annotation.Autowired;

public abstract class ElementHandlerFactory {

    @Autowired
    private BijlageTypeHandler bijlageTypeHandler;
    
    @Autowired
    private BestandMediaTypeHandler bestandMediaTypeHandler;

    @Autowired
    private ExtraInfoTypeHandler extraInfoTypeHandler;

    public abstract BestandLocatieHandler getBestandLocatieHandler();
    public abstract BestandIdentificatorHandler getBestandIdentificatorHandler();

    public ElementHandler getBijlageTypeHandler() {
        return bijlageTypeHandler;
    }
    
    public ElementHandler getBestandMediaTypeHandler() {
        return bestandMediaTypeHandler;
    }

    public ElementHandler getExtraInfoTypeHandler() {
        return extraInfoTypeHandler;
    }

    public ElementHandler getImklInNetworkHandler() {
        return new ImklInNetworkHandler();
    }

    public ElementHandler getOmschrijvingHandler() {
        return new OmschrijvingHandler();
    }

    public ElementHandler getLabelHandler() {
        return new LabelHandler();
    }

    public ElementHandler getImklIdentificatieHandler() {
       return new ImklIdentificatieHandler();
    }

    public ElementHandler getBeginLifespanVersionHandler() {
        return new BeginLifespanVersionHandler();
    }

    public ElementHandler getEndLifespanVersionHandler() {
        return new EndLifespanVersionHandler();
    }

    public ElementHandler getExtraDetailInfoLiggingHandler() {
        return new ExtraDetailInfoLiggingHandler();
    }

}
