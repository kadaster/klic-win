package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.gml;

import java.util.List;

import org.postgis.PGgeometry;
import org.postgis.Point;

import nl.kadaster.klic.win.storage.DatabaseHelper;

class GmlLineString implements GmlGeometry {

    private final List<Point> points;
    
    GmlLineString(final List<Point> points) {
        this.points = points;
    }

    @Override
    public PGgeometry getPGgeometry() {
        return DatabaseHelper.gmlPosListToPgLineString(points);
    }

}
