package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.chunk;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.FeatureWithValidation;
import nl.kadaster.klic.win.feature.domain.imkl2015.FeatureLink;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.GmlObject;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.BatchSupport;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.context.MultiThreadedBatchJobContext;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.data.BatchJobThreadData;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.domain.FeatureItem;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.exception.DuplicateKeyExceptionTranslator;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.exception.UniqueViolationExceptionTranslator;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.storage.FeatureDao;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.storage.FeatureLinkDao;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.storage.InspireGmlObjectDao;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.storage.WionGmlObjectDao;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.UncategorizedSQLException;

import java.sql.BatchUpdateException;
import java.util.List;

/**
 * Writes the collected data from the feature items to the database.
 */
public class FeatureItemWriter implements ItemWriter<FeatureItem> {

    private static final Logger LOG = LoggerFactory.getLogger(FeatureItemWriter.class);
    private static final int LOG_INTERVAL = 10000;

    private final FeatureDao featureDao;
    private final FeatureLinkDao featureLinkDao;
    private final WionGmlObjectDao wionGmlObjectDao;
    private final InspireGmlObjectDao inspireGmlObjectDao;

    private int nrOfFeaturesProcessed;

    @Autowired
    public FeatureItemWriter(final InspireGmlObjectDao inspireGmlObjectDao, final FeatureLinkDao featureLinkDao,
                             final WionGmlObjectDao wionGmlObjectDao, final FeatureDao featureDao) {
        this.inspireGmlObjectDao = inspireGmlObjectDao;
        this.featureLinkDao = featureLinkDao;
        this.wionGmlObjectDao = wionGmlObjectDao;
        this.featureDao = featureDao;
    }

    @Override
    public void write(final List<? extends FeatureItem> featureItemList) throws Exception {
        long start = System.currentTimeMillis();
        insertIntoDatabase(featureItemList);
        final BatchJobThreadData batchJobThreadData = MultiThreadedBatchJobContext.getBatchJobThreadData();
        batchJobThreadData.addDatabaseInsertTime(System.currentTimeMillis() - start);
    }

    private void insertIntoDatabase(final List<? extends FeatureItem> featureItemList) {
        try {
            final List<FeatureWithValidation> features = BatchSupport.toFeatureList(featureItemList);
            featureDao.storeBatch(features);

            final List<FeatureLink> featureLinks = BatchSupport.toFeatureLinkList(featureItemList);
            featureLinkDao.storeBatch(featureLinks);

            final List<GmlObject> wionGmlObjectList = BatchSupport.toWionGmlObjectList(featureItemList);
            wionGmlObjectDao.storeBatch(wionGmlObjectList);

            final List<GmlObject> inspireGmlObjectList = BatchSupport.toInspireGmlObjectList(featureItemList);
            inspireGmlObjectDao.storeBatch(inspireGmlObjectList);

            logEveryNrOfFeaturesProcessed(featureItemList);

        } catch(BatchUpdateException bue) {
            handleUniqueViolationException(bue);
        } catch (DuplicateKeyException dke) {
            LOG.error("Duplicate key violation while storing feature", dke);
            handleDuplicateKeyException(dke);
        } catch (DataIntegrityViolationException dive) {
            LOG.error("DataIntegrityViolationException while storing feature", dive);
            handleUniqueViolationException(dive);
        } catch (UncategorizedSQLException ex) {
            LOG.error("UncategorizedSQLException while storing feature", ex);
            final BatchJobThreadData batchJobThreadData = MultiThreadedBatchJobContext.getBatchJobThreadData();
            batchJobThreadData.getValidationMessageBuilder().addErrorDatabaseInsert(ex, "Unknown");
        } catch (Exception e) {
            LOG.error("Exception while writing batched features", e);
            final BatchJobThreadData batchJobThreadData = MultiThreadedBatchJobContext.getBatchJobThreadData();
            batchJobThreadData.getValidationMessageBuilder().addErrorTechnical();
        }
    }

    private static void handleDuplicateKeyException(final DuplicateKeyException dke) {
        final DuplicateKeyExceptionTranslator duplicateKeyExceptionTranslator = new DuplicateKeyExceptionTranslator(dke);
        final String message = duplicateKeyExceptionTranslator.getMsg();
        final String gmlId = duplicateKeyExceptionTranslator.getGmlId();
        final BatchJobThreadData batchJobThreadData = MultiThreadedBatchJobContext.getBatchJobThreadData();
        if (message != null) {
            batchJobThreadData.getValidationMessageBuilder().addErrorDatabaseInsertDuplicateKey(gmlId, message);
        } else {
            batchJobThreadData.getValidationMessageBuilder().addErrorDatabaseInsertDuplicateKey(dke.getMessage());
        }
    }

    private static void handleUniqueViolationException(final Exception exception) {
        final String gmlId = UniqueViolationExceptionTranslator.getGmlId(exception);
        final BatchJobThreadData batchJobThreadData = MultiThreadedBatchJobContext.getBatchJobThreadData();
        if (gmlId != null) {
            batchJobThreadData.getValidationMessageBuilder().addErrorDatabaseInsertDuplicateKey(gmlId);
        } else {
            batchJobThreadData.getValidationMessageBuilder().addGeneralError(exception);
        }
    }

    /**
     * Logs every x features the progress. Also logs the last batch run per thread.
     * @param featureItemList The list being processed
     */
    private void logEveryNrOfFeaturesProcessed(final List<? extends FeatureItem> featureItemList) {
        final int listSize = featureItemList.size();
        final int progressCounterCurrentBatch = nrOfFeaturesProcessed;
        nrOfFeaturesProcessed += listSize;
        final BatchJobThreadData batchJobThreadData = MultiThreadedBatchJobContext.getBatchJobThreadData();

        if (listSize <  batchJobThreadData.getBatchSize()) {
            // Log last batch
            LOG.info("Progress thread {}: (done) - processed {} features. [bronhoudercode: {}, actualisatieId: {}, file: {}]",
                    Thread.currentThread().getName(), nrOfFeaturesProcessed, batchJobThreadData.getBronhoudercode(), batchJobThreadData.getActualisatieId(), batchJobThreadData.getFilename());
        } else {
            // Log normal progress of every batch
            for (int i = 1; i < listSize + 1; i++) {
                if ((progressCounterCurrentBatch + i) % LOG_INTERVAL == 0) {
                    LOG.info("Progress thread {}: (running) - processed {} features. [bronhoudercode: {}, actualisatieId: {}, file: {}]",
                            Thread.currentThread().getName(), nrOfFeaturesProcessed, batchJobThreadData.getBronhoudercode(), batchJobThreadData.getActualisatieId(), batchJobThreadData.getFilename());
                }
            }
        }

    }
}
