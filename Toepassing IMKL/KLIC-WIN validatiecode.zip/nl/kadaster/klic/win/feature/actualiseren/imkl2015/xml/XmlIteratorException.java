package nl.kadaster.klic.win.feature.actualiseren.imkl2015.xml;

public class XmlIteratorException extends RuntimeException {

    private static final long serialVersionUID = -2498866210811405467L;

    XmlIteratorException(final String message) {
        super(message);
    }

    XmlIteratorException(final String message, final Throwable cause) {
        super(message, cause);
    }
}
