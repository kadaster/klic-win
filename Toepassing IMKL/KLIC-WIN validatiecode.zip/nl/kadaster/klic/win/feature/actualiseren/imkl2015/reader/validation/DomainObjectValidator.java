package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.FeatureWithValidation;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.FeatureWithValidationDomainObject;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.GmlId;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.SeenElement;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ValidationRule;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxHelper;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.validation.GmlIdContainingBronhouderCodeValidator;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import javax.xml.namespace.QName;
import java.util.List;

public class DomainObjectValidator {

    private static final Logger LOG = LoggerFactory.getLogger(DomainObjectValidator.class);

    private final GmlIdContainingBronhouderCodeValidator gmlIdContainingBronhouderCodeValidator;

    @Autowired
    public DomainObjectValidator(final GmlIdContainingBronhouderCodeValidator gmlIdContainingBronhouderCodeValidator) {
        this.gmlIdContainingBronhouderCodeValidator = gmlIdContainingBronhouderCodeValidator;
    }

    public boolean validate(final FeatureWithValidationDomainObject domainObject, final ValidationMessageBuilder validationMessageBuilder) {
        evaluateAllValidationRules(domainObject, validationMessageBuilder);
        if (validateGmlIdFormat(domainObject, validationMessageBuilder)) {
            // only continue checking the gmlId when it's valid
            validateGmlIdContainsBronhouderCode(domainObject, validationMessageBuilder);
        }
        return validationMessageBuilder.hasErrors();
    }

    private static boolean validateGmlIdFormat(final FeatureWithValidationDomainObject domainObject, final ValidationMessageBuilder validationMessageBuilder) {
        boolean valid = true;
        final GmlId gmlIdDomainObject = new GmlId(domainObject.getGmlId());
        if (!gmlIdDomainObject.isValid()) {
            valid = false;
            validationMessageBuilder.addErrorGmlIdFormatIncorrect(domainObject.getGmlId());
        }
        return valid;
    }

    protected static void evaluateAllValidationRules(final FeatureWithValidation domainObject, final ValidationMessageBuilder validationMessageBuilder) {
        for (ValidationRule validationRule : domainObject.getValidationRules()) {
            evaluateValidationRule(domainObject, validationMessageBuilder, validationRule);
        }
    }

    private static void evaluateValidationRule(FeatureWithValidation domainObject, ValidationMessageBuilder validationMessageBuilder, ValidationRule validationRule) {
        if (validationRule.isImklStrictlyMandatory()) {
            validateImklStrictlyMandatory(domainObject, validationMessageBuilder, validationRule);
        } else if (validationRule.isImklStrictlyProhibited()) {
            validateImklStrictlyProhibited(domainObject, validationMessageBuilder, validationRule);
        } else if (validationRule.isOneSubElementStrictlyMandatoryIfElementExists()) {
            validateOneSubElementStrictlyMandatoryIfElementExists(domainObject, validationMessageBuilder, validationRule);
        }
    }

    private void validateGmlIdContainsBronhouderCode(final FeatureWithValidationDomainObject domainObject, final ValidationMessageBuilder validationMessageBuilder) {
        boolean valid = gmlIdContainingBronhouderCodeValidator.validateGmlId(domainObject, validationMessageBuilder);
        if (!valid) {
            LOG.debug("Bronhoudercode of netbeheerder with bronhoudercode: {} was not found in the gmlId: {} in feature type: {}",
                    domainObject.getBronhoudercode(), domainObject.getGmlId(), domainObject.getImklFeatureType());
        }
    }

    private static void validateOneSubElementStrictlyMandatoryIfElementExists(final FeatureWithValidation domainObject, final ValidationMessageBuilder validationMessageBuilder, final ValidationRule validationRule) {
        boolean valid = false;
        final SeenElement seenElement = domainObject.getSeenElement(validationRule.getElement());
        if ((seenElement != null) && (seenElement.isValueSet())) {
            // The element is present, so a minumum of one of the sub validation rules should apply
            for (QName subElement: validationRule.getSubElements()) {
                final SeenElement seenSubElement = domainObject.getSeenElement(subElement);
                if ((seenSubElement != null) && (seenSubElement.isValueSet())) {
                    valid = true;
                    break;
                }
            }
            if (!valid) {
                validationMessageBuilder.addOneSubElementIsStrictlyMandatoryIfElementExistsError(domainObject.getGmlId(), StaxHelper.getQName(validationRule.getElement()), concatenateSubElementNames(validationRule.getSubElements()));
            }
        }
    }

    private static String concatenateSubElementNames(List<QName> subElements) {
        String subElementNames = "";
        for (QName subElement: subElements) {
            if (!StringUtils.isEmpty(subElementNames)) {
                subElementNames = subElementNames + ", ";
            }
            subElementNames = subElementNames + StaxHelper.getQName(subElement);
        }
        return subElementNames;
    }

    private static boolean validateImklStrictlyMandatory(final FeatureWithValidation domainObject, final ValidationMessageBuilder validationMessageBuilder, final ValidationRule validationRule) {
        boolean valid = true;
        final String elementName = StaxHelper.getQName(validationRule.getElement());
        final SeenElement seenElement = domainObject.getSeenElement(validationRule.getElement());
        if (seenElement == null) {
            valid = false;
            if (validationMessageBuilder != null) {
                validationMessageBuilder.addMandatoryElementNotFound(domainObject.getGmlId(), elementName);
            }
        } else {
            if (validationRule.isImklStrictlyMandatory() && !seenElement.isValueSet()) {
                valid = false;
                if (validationMessageBuilder != null) {
                    validationMessageBuilder.addErrorImklElementMandatory(domainObject.getGmlId(), elementName);
                }
            }
        }
        return valid;
    }

    private static boolean validateImklStrictlyProhibited(final FeatureWithValidation domainObject, final ValidationMessageBuilder validationMessageBuilder, final ValidationRule validationRule) {
        boolean valid = true;
        final String elementName = StaxHelper.getQName(validationRule.getElement());
        final SeenElement seenElement = domainObject.getSeenElement(validationRule.getElement());
        if (seenElement != null){
            valid = false;
            if (validationMessageBuilder != null) {
                validationMessageBuilder.addErrorImklElementNotAllowed(domainObject.getGmlId(), elementName);
            }
        }
        return valid;
    }
}
