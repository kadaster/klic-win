package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.Appurtenance;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.stream.events.StartElement;

public class AppurtenanceTypeHandler extends AbstractElementHandler implements ElementHandler<Appurtenance> {

    @Override
    public boolean shouldHandle(StartElement element) {
        return sameQName(Elements.APPURTENANCE_TYPE, element.getName());
    }

    @Override
    public void handle(StartElement element, FeatureLinks featureLinks, Appurtenance appurtanance, StaxEventReader staxEventReader, ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        final String appurtenanceType = getXLink(element);
        // Code list value validation is done afterwards and at import of utiliteitsnet.
        appurtanance.setAppurtenanceType(appurtenanceType);
        appurtanance.setType(appurtenanceType);

        // Set seen this element for IMKL strictly mandatory
        appurtanance.setSeenElementValue(Elements.APPURTENANCE_TYPE, element.getLocation().getLineNumber(), appurtenanceType != null);
    }

}
