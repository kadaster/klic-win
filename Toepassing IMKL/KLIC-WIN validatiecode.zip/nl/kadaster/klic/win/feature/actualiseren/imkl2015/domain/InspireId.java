package nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain;

import org.apache.commons.lang.StringUtils;

import javax.xml.namespace.QName;

public class InspireId {

    private String namespace;
    private String localId;
    private QName type;
    private QName baseType;

    public InspireId() {
        super();
    }

    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(final String namespace) {
        this.namespace = namespace;
    }

    public String getLocalId() {
        return localId;
    }

    public void setLocalId(final String localId) {
        this.localId = localId;
    }

    public QName getType() {
        return type;
    }

    public void setType(final QName type) {
        this.type = type;
    }

    public QName getBaseType() {
        return baseType;
    }

    public void setBaseType(final QName baseType) {
        this.baseType = baseType;
    }

    public boolean isComplete() {
        return StringUtils.isNotEmpty(namespace)
                && StringUtils.isNotEmpty(localId);
    }

    @Override
    public String toString() {
        return "InspireId{" +
                "namespace='" + namespace + '\'' +
                ", localId='" + localId + '\'' +
                ", type=" + type +
                ", baseType=" + baseType +
                '}';
    }
}
