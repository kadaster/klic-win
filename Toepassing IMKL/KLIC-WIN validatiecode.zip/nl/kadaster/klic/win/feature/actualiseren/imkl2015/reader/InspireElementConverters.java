package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.inspireelements.GmlConverter;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.inspireelements.ImklFeatureMemberConverter;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.inspireelements.InspireConvertibleElementProvider;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.inspireelements.InspireElementConverter;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.inspireelements.MappedFeaturetypeProvider;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.inspireelements.UtilityLinkConverter;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.inspireelements.XLinkConverter;

import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.Namespace;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;
import java.util.ArrayList;
import java.util.List;

class InspireElementConverters {

    private final List<InspireElementConverter> elementConverters;

    InspireElementConverters (final List<Namespace> globalNamespaces,
                              final InspireConvertibleElementProvider inspireConvertibleElementProvider,
                              final MappedFeaturetypeProvider mappedFeaturetypeProvider) {
        elementConverters = new ArrayList<>(4);

        elementConverters.add(new UtilityLinkConverter(globalNamespaces));

        ImklFeatureMemberConverter imklFeatureMemberConverter = new ImklFeatureMemberConverter(globalNamespaces);
        imklFeatureMemberConverter.setInspireConvertibleElementProvider(inspireConvertibleElementProvider);
        elementConverters.add(imklFeatureMemberConverter);

        XLinkConverter xLinkConverter = new XLinkConverter();
        xLinkConverter.setInspireIdTypeProvider(mappedFeaturetypeProvider);
        elementConverters.add(xLinkConverter);

        elementConverters.add(new GmlConverter());
    }

    XMLEvent toInspire(final XMLEvent event) throws XMLException {
        if (event.isStartElement()) {
            final StartElement startElement = event.asStartElement();
            for (InspireElementConverter inspireElementConverter : elementConverters) {
                if (inspireElementConverter.shouldHandle(startElement)) {
                    return inspireElementConverter.convertStartElement(startElement);
                }
            }
        } else if (event.isEndElement()) {
            final EndElement endElement = event.asEndElement();
            for (InspireElementConverter inspireElementConverter : elementConverters) {
                if (inspireElementConverter.shouldHandle(endElement)) {
                    return inspireElementConverter.convertEndElement(endElement);
                }
            }
        }
        return event;
    }

}
