package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.inspireelements;

import nl.kadaster.klic.win.feature.common.util.gml.Elements;
import org.apache.commons.collections4.Predicate;

import javax.xml.stream.events.Namespace;

final class Predicates {

    private Predicates() {
    }

    public static Predicate<Namespace> namespacePrefixEquality(final Namespace aNamespace) {
        return new Predicate<Namespace>() {
            @Override
            public boolean evaluate(final Namespace namespace) {
                return namespace.getPrefix().equals(aNamespace.getPrefix());
            }
        };
    }

    public static Predicate<Namespace> namespaceImkl() {
        return new Predicate<Namespace>() {
            @Override
            public boolean evaluate(final Namespace namespace) {
                return Elements.NAMESPACE_IMKL.equals(namespace.getValue());
            }
        };
    }

}
