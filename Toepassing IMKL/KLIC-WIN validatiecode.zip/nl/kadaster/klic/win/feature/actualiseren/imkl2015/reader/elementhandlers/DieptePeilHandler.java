package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.Diepte;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxHelper;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;
import org.apache.commons.lang.StringUtils;

import javax.xml.namespace.QName;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.StartElement;

public class DieptePeilHandler extends AbstractElementHandler implements ElementHandler<Diepte> {
    
    private static final QName UOM = new QName("uom");

    @Override
    public boolean shouldHandle(final StartElement element) {
        return sameQName(Elements.DIEPTE_PEIL, element.getName());
    }

    @Override
    public void handle(final StartElement element, final FeatureLinks featureLinks, final Diepte diepte, final StaxEventReader staxEventReader, final ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        final Attribute uom = element.getAttributeByName(UOM);
        final Double measure = StaxHelper.readDouble(staxEventReader);
        diepte.setLabel(measure + StringUtils.substringAfter(uom.getValue(), "::"));
    }
}
