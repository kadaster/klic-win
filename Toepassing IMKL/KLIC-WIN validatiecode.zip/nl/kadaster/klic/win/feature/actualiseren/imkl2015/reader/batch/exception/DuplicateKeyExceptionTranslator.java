package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.exception;

import org.springframework.dao.DuplicateKeyException;

import java.util.StringTokenizer;

public class DuplicateKeyExceptionTranslator {

    private static final String FEATURE_LINK_PKEY = "feature_link_pkey";
    private static final String MESSAGE_FORMAT = "FeatureWithValidation '%s' verwijst meerdere keren naar feature '%s'.";

    private String gmlId = null;
    private String msg = null;

    public DuplicateKeyExceptionTranslator(final Exception exception) {
        init(exception);
    }

    private void init(final Exception exception) {
        if (exception instanceof DuplicateKeyException) {
            extractMessage(exception.getCause());
        }
    }

    private void extractMessage(final Throwable cause) {
        if (cause == null) {
            return;
        }

        final String causeMessage = cause.getMessage();
        if (causeMessage != null && causeMessage.contains(FEATURE_LINK_PKEY)) {
            final int startIndexGmlId = causeMessage.lastIndexOf('(') + 1;
            final int endIndexGmlId = causeMessage.lastIndexOf(')');
            if (startIndexGmlId > -1 && endIndexGmlId > -1) {
                final String text = causeMessage.substring(startIndexGmlId, endIndexGmlId);
                final StringTokenizer tokenizer = new StringTokenizer(text, ",");
                int nrOfTokens = tokenizer.countTokens();
                if (nrOfTokens == 4) {
                    tokenizer.nextToken();
                    tokenizer.nextToken();
                    final String feature = tokenizer.nextToken().trim();
                    final String linkedFeature = tokenizer.nextToken().trim();
                    gmlId = feature;
                    msg = String.format(MESSAGE_FORMAT, feature, linkedFeature);
                }
            }
        }
    }

    public String getGmlId() {
        return gmlId;
    }

    public String getMsg() {
        return msg;
    }
}
