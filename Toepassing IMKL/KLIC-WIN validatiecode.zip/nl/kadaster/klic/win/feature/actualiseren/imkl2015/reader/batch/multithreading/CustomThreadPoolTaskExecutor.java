package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.multithreading;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.BatchJobSettings;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.context.BatchJobContext;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.context.BatchJobThreadContext;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.scope.context.JobSynchronizationManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

/**
 * Custom implementation to work around the bug containing Job scope with
 * multiple thread processing in batch jobs.
 * @link https://jira.spring.io/browse/BATCH-2269
 */
public class CustomThreadPoolTaskExecutor extends ThreadPoolTaskExecutor {

    private final transient BatchJobContext batchJobContext;
    private final transient BatchJobThreadContext batchJobThreadContext;
    private int extraThreadsOnTopOfNrOfProcessors;

    @Autowired
    public CustomThreadPoolTaskExecutor(final BatchJobContext batchJobContext, final BatchJobThreadContext batchJobThreadContext) {
        this.batchJobContext = batchJobContext;
        this.batchJobThreadContext = batchJobThreadContext;
        setDefaults();
    }

    private void setDefaults() {
        final int threadpoolSize = getThreadpoolSize();
        setCorePoolSize(threadpoolSize);
        setMaxPoolSize(threadpoolSize);
    }

    private int getThreadpoolSize() {
        return BatchJobSettings.POOL_SIZE + extraThreadsOnTopOfNrOfProcessors;
    }

    @Override
    public void execute(final Runnable task) {
        // gets the jobExecution of the configuration thread
        final JobExecution jobExecution = JobSynchronizationManager.getContext().getJobExecution();
        super.execute(new CustomRunnable(batchJobContext, batchJobThreadContext).with(jobExecution, task));
    }

    public void setExtraThreadsOnTopOfNrOfProcessors(final int extraThreadsOnTopOfNrOfProcessors) {
        this.extraThreadsOnTopOfNrOfProcessors = extraThreadsOnTopOfNrOfProcessors;
        setDefaults();
    }
}
