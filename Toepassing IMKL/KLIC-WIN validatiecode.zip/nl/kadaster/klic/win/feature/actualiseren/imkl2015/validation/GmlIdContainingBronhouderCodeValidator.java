package nl.kadaster.klic.win.feature.actualiseren.imkl2015.validation;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.FeatureWithValidationDomainObject;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;

/**
 * Het gmlId moet na de namespace de bronhoudercode van de netbeheerder bevatten
 */
public interface GmlIdContainingBronhouderCodeValidator {

    boolean validateGmlId(final FeatureWithValidationDomainObject domainObj, final ValidationMessageBuilder validationMessageBuilder);
}
