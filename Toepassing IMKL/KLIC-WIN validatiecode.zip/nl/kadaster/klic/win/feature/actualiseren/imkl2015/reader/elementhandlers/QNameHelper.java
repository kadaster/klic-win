package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import javax.xml.namespace.QName;

public final class QNameHelper {

    private QNameHelper() {
    }

    public static boolean sameQName(final QName qName1, final QName qName2) {
        return qName1.getNamespaceURI().equals(qName2.getNamespaceURI()) && qName1.getLocalPart().equals(qName2.getLocalPart());
    }
}
