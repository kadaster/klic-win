package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ContainerLeidingElement;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ValidationRule;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.CurrentStatusHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.DiepteLeggingHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.GeometryNetCommonHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ImklExtraGeometrieHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ImklHeeftExtraInformatieHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ImklInNetworkHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.InspireIdNetCommonHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.NodesHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ValidFromHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ValidToHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.VerticalPositionHandler;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public abstract class AbstractContainerLeidingElementStaxMapper extends StaxMapper<ContainerLeidingElement> {

    @Autowired
    private CurrentStatusHandler currentStatusHandler;

    @Override
    void initElementHandlers() {
        super.initElementHandlers();
        addElementHandler(new InspireIdNetCommonHandler());
        addElementHandler(new NodesHandler());
        addElementHandler(new GeometryNetCommonHandler());
        addElementHandler(new ValidFromHandler());
        addElementHandler(new ValidToHandler());
        addElementHandler(new VerticalPositionHandler());
        addElementHandler(currentStatusHandler);
        
        // associations
        addElementHandler(new ImklInNetworkHandler());
        addElementHandler(new DiepteLeggingHandler());
        addElementHandler(new ImklHeeftExtraInformatieHandler());
        addElementHandler(new ImklExtraGeometrieHandler());
    }

    @Override
    List<ValidationRule> getValidationRules() {
        final List<ValidationRule> validationRules = super.getValidationRules();
        validationRules.add(new ValidationRule(Elements.INSPIRE_ID_NET_COMMON).withImklStrictlyMandatory());
        return validationRules;
    }

    @Override
    ContainerLeidingElement createDomainObject() {
        return new ContainerLeidingElement();
    }

}
