package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.FeatureWithValidationDomainObject;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.domain.DomainObject;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.stream.events.StartElement;

public class NodesHandler extends AbstractElementHandler implements ElementHandler<DomainObject> {

    @Override
    public boolean shouldHandle(StartElement element) {
        return sameQName(Elements.NODES_NET_COMMON, element.getName());
    }

    @Override
    public void handle(StartElement element, FeatureLinks featureLinks, DomainObject domainObject, StaxEventReader staxEventReader, ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        if (domainObject instanceof FeatureWithValidationDomainObject) {
            FeatureWithValidationDomainObject feature = (FeatureWithValidationDomainObject) domainObject;
            featureLinks.addFeatureLink(getXLink(element), feature, null);
        }
    }

}
