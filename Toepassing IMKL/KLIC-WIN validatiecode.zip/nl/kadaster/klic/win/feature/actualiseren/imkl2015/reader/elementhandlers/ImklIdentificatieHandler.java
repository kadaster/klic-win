package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.FeatureWithValidationDomainObject;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.GmlId;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.InspireId;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxHelper;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.stream.events.StartElement;

public class ImklIdentificatieHandler extends AbstractElementHandler implements ElementHandler<FeatureWithValidationDomainObject> {
    @Override
    public boolean shouldHandle(final StartElement element) {
        return sameQName(Elements.IMKL_IDENTIFICATIE, element.getName());
    }

    @Override
    public void handle(final StartElement element, final FeatureLinks featureLinks, final FeatureWithValidationDomainObject featureDomainObject, final StaxEventReader staxEventReader, final ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        final InspireId inspireId = getImklId(featureLinks, staxEventReader);

        featureDomainObject.setInspireId(inspireId);
        compareImklIdWithGmlId(featureDomainObject.getInspireId(), featureDomainObject, validationMessageBuilder);

        final boolean valuePresent = inspireId != null && inspireId.isComplete();
        featureDomainObject.setSeenElementValue(Elements.IMKL_IDENTIFICATIE, element.getLocation().getLineNumber(), valuePresent);
    }

    private static InspireId getImklId(final FeatureLinks featureLinks, final StaxEventReader staxEventReader) throws XMLException {
        final InspireId inspireId = new InspireId();
        StaxHelper.navigateToFirstElement(staxEventReader, Elements.IMKL_NAMESPACE);
        inspireId.setNamespace(StaxHelper.readElementData(staxEventReader));
        StaxHelper.navigateToFirstElement(staxEventReader, Elements.IMKL_LOKAAL_ID);
        inspireId.setLocalId(StaxHelper.readElementData(staxEventReader));
        inspireId.setType(featureLinks.getInspireType());
        inspireId.setBaseType(featureLinks.getBaseElement());
        StaxHelper.navigateToEndElement(staxEventReader, Elements.IMKL_ID);
        return inspireId;
    }

    private void compareImklIdWithGmlId(final InspireId inspireId, final FeatureWithValidationDomainObject inspireDomainObject, final ValidationMessageBuilder validationMessageBuilder) {
        final GmlId gmlIdInspireId = new GmlId(inspireId.getNamespace(), inspireId.getLocalId());
        final GmlId gmlIdFeatureMember = new GmlId(inspireDomainObject.getGmlId());
        if (!gmlIdInspireId.isValid()) {
            validationMessageBuilder.addErrorNEN3610IdIncorrect(inspireDomainObject.getGmlId());
        } else if (gmlIdFeatureMember.isValid() && !gmlIdInspireId.equals(gmlIdFeatureMember)) {
            validationMessageBuilder.addErrorGmlIdDoesntCompareToNen3610Id(inspireDomainObject.getGmlId());
        }
    }
}
