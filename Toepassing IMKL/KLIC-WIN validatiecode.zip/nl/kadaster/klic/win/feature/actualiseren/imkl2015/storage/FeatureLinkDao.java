package nl.kadaster.klic.win.feature.actualiseren.imkl2015.storage;

import nl.kadaster.klic.win.feature.domain.imkl2015.FeatureLink;

import java.util.List;

public interface FeatureLinkDao {

    void storeBatch(final List<FeatureLink> featureLinks);

    void updateWithLinkedFeatureIds(final String bronhoudercode);

    List<FeatureLink> getWhereMissingLinkedFeatureIds(final String bronhoudercode);
    
    void deleteWhereMissingLinkedFeatureIds(final String bronhoudercode);

    void updateMissingFeatureThemes(final String bronhoudercode);

}
