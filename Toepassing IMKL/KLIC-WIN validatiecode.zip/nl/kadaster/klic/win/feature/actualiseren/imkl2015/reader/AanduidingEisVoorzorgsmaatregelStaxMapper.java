package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.AanduidingEisVoorzorgsmaatregel;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ImklFeatureWithValidationDomainObject;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ValidationRule;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ExtraDetailInfoLiggingHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.GeometrieHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ImklIdentificatieHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ImklInNetworkHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.LabelHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.OmschrijvingHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.namespace.QName;
import javax.xml.stream.events.StartElement;
import java.util.List;

public class AanduidingEisVoorzorgsmaatregelStaxMapper extends StaxMapper<AanduidingEisVoorzorgsmaatregel> {

    @Override
    boolean canHandle(QName element) {
        return Elements.AANDUIDINGEISVOORZORGSMAATREGEL.equals(element);
    }

    @Override
    public QName getInspireType() {
        return null;
    }

    @Override
    void initElementHandlers() {
        super.initElementHandlers();
        addElementHandler(new ImklIdentificatieHandler());
        addElementHandler(new ExtraDetailInfoLiggingHandler());
        addElementHandler(new LabelHandler());
        addElementHandler(new OmschrijvingHandler());
        addElementHandler(new ImklInNetworkHandler());

        addElementHandler(new GeometrieHandler() {
            
            @Override
            public void handle(final StartElement element, final FeatureLinks featureLinks, final ImklFeatureWithValidationDomainObject aanduiding, final StaxEventReader staxEventReader, final ValidationMessageBuilder validationMessageBuilder) throws XMLException {
                super.handle(element, featureLinks, aanduiding, staxEventReader, validationMessageBuilder);
                if (aanduiding.getGeometry() == null) {
                    validationMessageBuilder.addErrorImklElementMandatory(aanduiding.getGmlId(), element.getName().getLocalPart());
                }
            }
        });
    }

    @Override
    List<ValidationRule> getValidationRules() {
        final List<ValidationRule> validationRules = super.getValidationRules();
        validationRules.add(new ValidationRule(Elements.IMKL_IDENTIFICATIE).withImklStrictlyMandatory());
        return validationRules;
    }

    @Override
    protected AanduidingEisVoorzorgsmaatregel createDomainObject() {
        return new AanduidingEisVoorzorgsmaatregel();
    }

    @Override
    QName getBaseElement() {
        return Elements.AANDUIDINGEISVOORZORGSMAATREGEL;
    }
}
