package nl.kadaster.klic.win.feature.actualiseren.report;

public enum InspireLabel implements ReportLabel {

     UTILITEITSNET("utiliteitsnet", "utiliteitsnet" )
    ,KABEL_OF_LEIDING("kabelOfLeiding", "kabelsenleidingen")
    ,KABEL_EN_LEIDING_CONTAINER("kabelEnLeidingContainer", "kabelenleidingcontainers")
    ,LEIDINGELEMENT("leidingelement", "leidingelementen")
    ,CONTAINER_LEIDINGELEMENT("containerLeidingelement", "containerleidingelementen")
    ,UTILITYLINK("utilityLink", "utilitylink")
    
    ,ELECTRICITY("electricity", "electricity")
    ,OIL_GAS_CHEMICAL("oilGasChemicals","oilGasChemical")
    ,SEWER("sewer", "sewer") 
    ,TELECOMMUNICATIONS("telecommunications", "telecommunications")
    ,THERMAL("thermal", "thermal")
    ,WATER("water", "water")
    ,OVERIG("overig", "overig")
    
    ,CABINET("cabinet", null)
    ,MANHOLE("manhole", "Mangat")
    ,POLE("pole", "Mast")
    ,TOWER("tower", "Toren")
    ;
    
    private final String displayName;
    private final String dbCode;
     
    InspireLabel(final String displayName, final String dbCode) {
        this.displayName = displayName;
        this.dbCode = dbCode;
    }

    @Override
    public String getDisplayName() {
        return displayName;
    }
    
    @Override
    public String getDbCode() {
        return dbCode;
    }
    
}
