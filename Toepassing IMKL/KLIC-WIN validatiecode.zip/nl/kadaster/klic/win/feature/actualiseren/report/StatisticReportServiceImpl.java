package nl.kadaster.klic.win.feature.actualiseren.report;


import nl.kadaster.klic.win.model.StatistiekRegel;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class StatisticReportServiceImpl implements StatisticReportService {

    private static final WionLabel[] WION_THEMAS = new WionLabel[] {
             WionLabel.BUISLEIDING_GEVAARLIJKE_INHOUD
            ,WionLabel.DATATRANSPORT
            ,WionLabel.GAS_HOGE_DRUK
            ,WionLabel.GAS_LAGE_DRUK
            ,WionLabel.HOOGSPANNING
            ,WionLabel.LAAGSPANNING
            ,WionLabel.LANDELIJK_HOOGSPANNINGSNET
            ,WionLabel.MIDDENSPANNING
            ,WionLabel.OVERIG
            ,WionLabel.PETROCHEMIE
            ,WionLabel.RIOOL_ONDER_OF_OVERDRUK
            ,WionLabel.RIOOL_VRIJVERVAL
            ,WionLabel.WARMTE
            ,WionLabel.WATER
            ,WionLabel.WEES
    };

    private static final InspireLabel[] INSPIRE_THEMAS = new InspireLabel[] {
              InspireLabel.ELECTRICITY
             ,InspireLabel.OIL_GAS_CHEMICAL
             ,InspireLabel.SEWER
             ,InspireLabel.TELECOMMUNICATIONS
             ,InspireLabel.THERMAL
             ,InspireLabel.WATER
             ,InspireLabel.OVERIG
    };

    private static final WionLabel[] WION_CONTAINER_LEIDINGELEMENTEN = new WionLabel[] {
             WionLabel.TOREN
            ,WionLabel.MAST
            ,WionLabel.MANGAT
            ,WionLabel.KAST
            ,WionLabel.TECHNISCH_GEBOUW
    };
    
    private static final WionLabel[] EXTRA_DETAILINFO_TYPES = new WionLabel[] {
             WionLabel.EDI_AANSLUITING
            ,WionLabel.EDI_HUISAANSLUITING
            ,WionLabel.EDI_OVERIG
            ,WionLabel.EDI_PROFIELSCHETS
            ,WionLabel.EDI_VERZOEKTOTCONTACT
    };

    private static final StatistiekRegel.StatistiekSoort STATISTIEKSOORT_WION = StatistiekRegel.StatistiekSoort.IMKL_NETINFORMATIE_WION;
    private static final StatistiekRegel.StatistiekSoort STATISTIEKSOORT_INSPIRE = StatistiekRegel.StatistiekSoort.IMKL_NETINFORMATIE_INSPIRE;

    private static final String FEATURE_TYPE_KAST = "Kast";
    private static final String FEATURE_TYPE_TECHNISCHGEBOUW = "TechnischGebouw";
    
    @Autowired
    private StatisticDao statisticDao;

    @Override
    public void createReport(final String bronhoudercode, final List<StatistiekRegel> statistiekregels) {
        statisticDao.loadRawStatistics(bronhoudercode);
        createWionReport(statistiekregels);
        createInspireReport(statistiekregels);
    }

    private void createWionReport(final List<StatistiekRegel> statistiekregels) {
        addWionGroepRegels(statistiekregels, WionLabel.UTILITEITSNET);
        addWionGroepRegels(statistiekregels, WionLabel.KABEL_OF_LEIDING);
        addWionGroepRegels(statistiekregels, WionLabel.KABEL_EN_LEIDING_CONTAINER);
        addWionGroepRegels(statistiekregels, WionLabel.LEIDINGELEMENT);
        addWionContainerLeidingelementRegels(statistiekregels);
        addWionGroepRegels(statistiekregels, WionLabel.UTILITYLINK);
        
        addWionFeatureRegel(statistiekregels, WionLabel.AANDUIDING_EIS_VOORZORGSMAATREGEL);
        addWionFeatureRegel(statistiekregels, WionLabel.ANNOTATIE);
        addWionFeatureRegel(statistiekregels, WionLabel.DIEPTE_NAP);
        addWionFeatureRegel(statistiekregels, WionLabel.DIEPTE_TOV_MAAIVELD);
        addWionFeatureRegel(statistiekregels, WionLabel.EIGEN_TOPOGRAFIE);
        addWionExtraDetailInfoRegels(statistiekregels);
        addWionFeatureRegel(statistiekregels, WionLabel.EXTRA_GEOMETRIE);
        addWionFeatureRegel(statistiekregels, WionLabel.MAATVOERING);
    }
    
    
    private void addWionGroepRegels(final List<StatistiekRegel> statistiekregels, final WionLabel groep) {
        for (WionLabel thema : WION_THEMAS) {
           int aantal = statisticDao.countByGroepAndWionThema(groep.getDbCode(),thema.getDbCode());
           createStatistiekregel(STATISTIEKSOORT_WION, groep, thema, aantal, statistiekregels);
        }
    }
    
    private void addWionContainerLeidingelementRegels(final List<StatistiekRegel> statistiekregels) {
        WionLabel groep = WionLabel.CONTAINER_LEIDINGELEMENT;
        for (WionLabel containerLeidingelement : WION_CONTAINER_LEIDINGELEMENTEN) {
            int aantal = statisticDao.countByFeaturetype(containerLeidingelement.getDbCode());
            createStatistiekregel(STATISTIEKSOORT_WION, groep, containerLeidingelement, aantal, statistiekregels);
        }
    }
    
    private void addWionExtraDetailInfoRegels(final List<StatistiekRegel> statistiekregels) {
        ReportLabel extraDetailInfo = WionLabel.EXTRA_DETAIL_INFO;
        for (ReportLabel ediType : EXTRA_DETAILINFO_TYPES) {
            int aantal = statisticDao.countByFeaturetypeAndType(extraDetailInfo.getDbCode(), ediType.getDbCode());
            createStatistiekregel(STATISTIEKSOORT_WION, extraDetailInfo, ediType, aantal, statistiekregels);
        }
    }

    private void addWionFeatureRegel(final List<StatistiekRegel> statistiekregels, final WionLabel wionLabel) {
        int aantal = statisticDao.countByFeaturetype(wionLabel.getDbCode());
        createStatistiekregel(STATISTIEKSOORT_WION, wionLabel, null, aantal, statistiekregels);
    }
    
    private void createInspireReport(final List<StatistiekRegel> statistiekregels) {
        addInspireGroepRegels(statistiekregels, InspireLabel.UTILITEITSNET);
        addInspireGroepRegels(statistiekregels, InspireLabel.KABEL_OF_LEIDING);
        addInspireGroepRegels(statistiekregels, InspireLabel.KABEL_EN_LEIDING_CONTAINER);
        addInspireGroepRegels(statistiekregels, InspireLabel.LEIDINGELEMENT);
        addInspireContainerLeidingelementRegels(statistiekregels);
        addInspireGroepRegels(statistiekregels, InspireLabel.UTILITYLINK);
    }

    private void addInspireGroepRegels(final List<StatistiekRegel> statistiekregels, final InspireLabel groep) {
        for (InspireLabel thema : INSPIRE_THEMAS) {
           int aantal = statisticDao.countByGroepAndInspireThema(groep.getDbCode(),thema.getDbCode());
            createStatistiekregel(STATISTIEKSOORT_INSPIRE, groep, thema, aantal, statistiekregels);
        }
    }
    
    private void addInspireContainerLeidingelementRegels(final List<StatistiekRegel> statistiekregels) {
        InspireLabel groep = InspireLabel.CONTAINER_LEIDINGELEMENT;
        InspireLabel[] containerLeidingelementen = new InspireLabel[] {
                 InspireLabel.MANHOLE
                ,InspireLabel.POLE
                ,InspireLabel.TOWER
        };
        for (InspireLabel containerLeidingelement : containerLeidingelementen) {
            int aantal = statisticDao.countByFeaturetype(containerLeidingelement.getDbCode());
            createStatistiekregel(STATISTIEKSOORT_INSPIRE, groep, containerLeidingelement, aantal, statistiekregels);
        }

        // create the 'CABINET' inspire label
        int aantalKast = statisticDao.countByFeaturetype(FEATURE_TYPE_KAST);
        int aantalTechnischGebouw = statisticDao.countByFeaturetype(FEATURE_TYPE_TECHNISCHGEBOUW);
        createStatistiekregel(STATISTIEKSOORT_INSPIRE, groep, InspireLabel.CABINET, aantalKast + aantalTechnischGebouw, statistiekregels);
    }
    
    private static void createStatistiekregel(final StatistiekRegel.StatistiekSoort statistiekSoort,
                                              final ReportLabel niveau1, final ReportLabel niveau2, final int aantal, final List<StatistiekRegel> statistiekregels) {
        if (aantal > 0) {
            StatistiekRegel statistiekregel = new StatistiekRegel();
            statistiekregel.setStatistiekSoort(statistiekSoort);
            statistiekregel.setStatistiekAanduidingNiveau1(niveau1.getDisplayName());
            if (niveau2 != null) {
                statistiekregel.setStatistiekAanduidingNiveau2(niveau2.getDisplayName());
            }
            statistiekregel.setAantal(aantal);
            statistiekregels.add(statistiekregel);
        }
    }

}
