package nl.kadaster.klic.win.feature.actualiseren.report;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.ResultSetExtractor;

import nl.kadaster.klic.win.util.NiStoreUtil;

public class StatisticDaoImpl implements StatisticDao {

    private static final String FEATURE_SA_PLACEHOLDER = NiStoreUtil.SA_PLACEHOLDER1;
    
    private static final String LOAD_RAW_STATISTICS =
              "CREATE TEMPORARY TABLE RAW_STATISTICS ON COMMIT DROP "
            + "AS "
            + "SELECT ft.featuretype"
            + "     , wthema.code_short as wion_thema "
            + "     , ithema.code_short as inspire_thema "
            + "     , ft.groep as feature_group "
            + "     , f.type "
            + "     , count(1) as aantal "
            + "  FROM " + FEATURE_SA_PLACEHOLDER + " f "
            + "  JOIN ni_store.feature_types ft  ON f.featuretype_id = ft.id "
            + "  LEFT JOIN ni_store.thema wthema ON wthema.id = f.wionthema "
            + "  LEFT JOIN ni_store.thema ithema ON ithema.id = f.inspirethema "
            + " WHERE f.bronhoudercode = ? "
            + " GROUP BY ft.featuretype, wthema.code_short, ithema.code_short, ft.groep, f.type "
    ;
    
    
    private static final String COUNT_BY_GROUP_AND_WION_THEMA =
          "select sum(aantal) "
        + "from raw_statistics "
        + "where feature_group = ? "
        + "and wion_thema = ? "
        ;
    
    private static final String COUNT_BY_GROUP_AND_INSPIRE_THEMA =
            "select sum(aantal) "
          + "from raw_statistics "
          + "where feature_group = ? "
          + "and inspire_thema = ? "
          ;
    
    private static final String COUNT_BY_FEATURE_TYPE_AND_TYPE =
            "select sum(aantal) "
          + "from raw_statistics "
          + "where featuretype = ? "
          + "and type = ? "
          ;

    private static final String COUNT_BY_FEATURE_TYPE =
            "select sum(aantal) "
          + "from raw_statistics "
          + "where featuretype = ?"
          ;
    
    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    @Override
    public void loadRawStatistics(final String bronhoudercode) {
        String sql = NiStoreUtil.adaptQueryForStagingArea(bronhoudercode, LOAD_RAW_STATISTICS, "feature");
        jdbcTemplate.update(sql, bronhoudercode);
    }
    
    @Override
    public int countByGroepAndWionThema(final String groep, final String thema) {
        return count(COUNT_BY_GROUP_AND_WION_THEMA, groep, thema);
    }
    
    @Override
    public int countByGroepAndInspireThema(final String groep, final String thema) {
        return count(COUNT_BY_GROUP_AND_INSPIRE_THEMA, groep, thema);
    }
    
    @Override
    public int countByFeaturetypeAndType(final String featuretype, final String type) {
        return count(COUNT_BY_FEATURE_TYPE_AND_TYPE, featuretype, type);
    }
    
    @Override
    public int countByFeaturetype(final String featuretype) {
        return count(COUNT_BY_FEATURE_TYPE, featuretype, null);
    }
    
    private int count(final String sql, final String arg1, final String arg2) {
        return jdbcTemplate.query(
                new PreparedStatementCreator() {

                    @Override
                    public PreparedStatement createPreparedStatement(final Connection con) throws SQLException {
                        final PreparedStatement ps = con.prepareStatement(sql);
                        ps.setString(1, arg1);
                        if (arg2 != null) {
                            ps.setString(2, arg2);
                        }
                        return ps;
                    }
                    
                },
                new CountExtractor());
    }
    
    private static class CountExtractor implements ResultSetExtractor<Integer> {

        @Override
        public Integer extractData(final ResultSet rs) throws SQLException {
            int count;
            if (rs.next()) {
                count = rs.getInt(1);
            } else {
                count = 0;
            }
            return count;
        }   
    }

}
