package nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain;

public class ExtraDetailInfo extends ExtraInformatie {

    private String extraInfoType;
   

    public String getExtraInfoType() {
        return extraInfoType;
    }

    public void setExtraInfoType(final String extraInfoType) {
        this.extraInfoType = extraInfoType;
    }
    
}
