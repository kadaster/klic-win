package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.InspireId;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.inspireelements.InspireConvertibleElementProvider;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.inspireelements.MappedFeaturetypeProvider;
import nl.kadaster.klic.win.feature.domain.InformatieSoort;
import org.springframework.beans.factory.annotation.Autowired;

import javax.xml.namespace.QName;
import java.util.ArrayList;
import java.util.List;

public class StaxMapperFactory implements MappedFeaturetypeProvider, InspireConvertibleElementProvider {

    @SuppressWarnings("rawtypes")
    @Autowired
    private StaxMapper utilityLinkStaxMapper;

    @SuppressWarnings("rawtypes")
    @Autowired
    private StaxMapper utiliteitsnetStaxMapper;

    @SuppressWarnings("rawtypes")
    @Autowired
    private StaxMapper elektriciteitskabelStaxMapper;

    @SuppressWarnings("rawtypes")
    @Autowired
    private StaxMapper appurtenanceStaxMapper;

    @SuppressWarnings("rawtypes")
    @Autowired
    private StaxMapper kastStaxMapper;
    
    @SuppressWarnings("rawtypes")
    @Autowired
    private StaxMapper technischGebouwStaxMapper;

    @SuppressWarnings("rawtypes")
    @Autowired
    private StaxMapper ductStaxMapper;

    @SuppressWarnings("rawtypes")
    @Autowired
    private StaxMapper mantelbuisStaxMapper;

    @SuppressWarnings("rawtypes")
    @Autowired
    private StaxMapper oliegaschemicalienpijpleidingStaxMapper;

    @SuppressWarnings("rawtypes")
    @Autowired
    private StaxMapper kabelbedStaxMapper;

    @SuppressWarnings("rawtypes")
    @Autowired
    private StaxMapper waterleidingStaxMapper;

    @SuppressWarnings("rawtypes")
    @Autowired
    private StaxMapper thermischePijpleidingStaxMapper;

    @SuppressWarnings("rawtypes")
    @Autowired
    private StaxMapper rioolleidingStaxMapper;

    @SuppressWarnings("rawtypes")
    @Autowired
    private StaxMapper mangatStaxMapper;

    @SuppressWarnings("rawtypes")
    @Autowired
    private StaxMapper mastStaxMapper;

    @SuppressWarnings("rawtypes")
    @Autowired
    private StaxMapper torenStaxMapper;
    
    @SuppressWarnings("rawtypes")
    @Autowired
    private StaxMapper annotatieStaxMapper;

    @SuppressWarnings("rawtypes")
    @Autowired
    private StaxMapper maatvoeringStaxMapper;

    @SuppressWarnings("rawtypes")
    @Autowired
    private StaxMapper niExtraDetailInfoStaxMapper;

    @SuppressWarnings("rawtypes")
    @Autowired
    private StaxMapper biExtraDetailInfoStaxMapper;

    @SuppressWarnings("rawtypes")
    @Autowired
    private StaxMapper eigenTopografieStaxMapper;

    @SuppressWarnings("rawtypes")
    @Autowired
    private StaxMapper extraGeometrieStaxMapper;
    
    @SuppressWarnings("rawtypes")
    @Autowired
    private StaxMapper telecommunicatiekabelStaxMapper;
    
    @SuppressWarnings("rawtypes")
    @Autowired
    private StaxMapper diepteTovMaaiveldStaxMapper;

    @SuppressWarnings("rawtypes")
    @Autowired
    private StaxMapper diepteNapStaxMapper;

    @SuppressWarnings("rawtypes")
    @Autowired
    private StaxMapper aanduidingEisVoorzorgsmaatregelStaxMapper;
    @SuppressWarnings("rawtypes")
    @Autowired
    private StaxMapper overigStaxMapper;

    @SuppressWarnings("rawtypes")
    @Autowired
    private StaxMapper belanghebbendeStaxMapper;

    @SuppressWarnings("rawtypes")
    @Autowired
    private StaxMapper beheerderStaxMapper;

    @SuppressWarnings("rawtypes")
    @Autowired
    private StaxMapper niBijlageStaxMapper;
    
    @SuppressWarnings("rawtypes")
    @Autowired
    private StaxMapper biBijlageStaxMapper;

    @SuppressWarnings("rawtypes")
    @Autowired
    private StaxMapper eisVoorzorgsmaatregelBijlageStaxMapper;

    @SuppressWarnings("rawtypes")
    private List<StaxMapper> mappers;

    private ConvertableImklElements convertableImklElements;

    private final InformatieSoort informatieSoort;

    /**
     * The StaxMapperFactory is initialized for a specific {@link InformatieSoort}.
     * @param informatieSoort Netinformatie or beheerdersinformatie
     */
    public StaxMapperFactory(final InformatieSoort informatieSoort) {
        super();
        this.informatieSoort = informatieSoort;
    }

    @SuppressWarnings("rawtypes")
    StaxMapper getMapperForElement(final QName element) {

        StaxMapper matchedMapper = null;
        for (StaxMapper mapper : mappers) {
            if (mapper.canHandle(element)) {
                matchedMapper = mapper;
                break;
            }
        }
        return matchedMapper;
    }

    // Called after instantiation aka postconstruct (see klic-imkl.xml init-method)
    @SuppressWarnings("unused")
    private void init() {
        initMappers();
        initConvertibles();
    }

    private void initMappers() {
        mappers = new ArrayList<>(30);
        mappers.add(initMapper(utilityLinkStaxMapper));
        mappers.add(initMapper(elektriciteitskabelStaxMapper));
        mappers.add(initMapper(appurtenanceStaxMapper));
        mappers.add(initMapper(utiliteitsnetStaxMapper));
        mappers.add(initMapper(kastStaxMapper));
        mappers.add(initMapper(technischGebouwStaxMapper));
        mappers.add(initMapper(ductStaxMapper));
        mappers.add(initMapper(mantelbuisStaxMapper));
        mappers.add(initMapper(oliegaschemicalienpijpleidingStaxMapper));
        mappers.add(initMapper(kabelbedStaxMapper));
        mappers.add(initMapper(waterleidingStaxMapper));
        mappers.add(initMapper(rioolleidingStaxMapper));
        mappers.add(initMapper(mastStaxMapper));
        mappers.add(initMapper(torenStaxMapper));
        mappers.add(initMapper(mangatStaxMapper));
        mappers.add(initMapper(annotatieStaxMapper));
        mappers.add(initMapper(maatvoeringStaxMapper));
        mappers.add(initMapper(extraGeometrieStaxMapper));
        mappers.add(initMapper(thermischePijpleidingStaxMapper));
        mappers.add(initMapper(telecommunicatiekabelStaxMapper));
        mappers.add(initMapper(diepteTovMaaiveldStaxMapper));
        mappers.add(initMapper(diepteNapStaxMapper));
        mappers.add(initMapper(aanduidingEisVoorzorgsmaatregelStaxMapper));
        mappers.add(initMapper(overigStaxMapper));
        mappers.add(initMapper(beheerderStaxMapper));
        mappers.add(initMapper(eigenTopografieStaxMapper));

        switch (informatieSoort) {
            case BEHEERDERSINFORMATIE:
                mappers.add(initMapper(belanghebbendeStaxMapper));
                mappers.add(initMapper(biBijlageStaxMapper));
                mappers.add(initMapper(eisVoorzorgsmaatregelBijlageStaxMapper));
                mappers.add(initMapper(biExtraDetailInfoStaxMapper));
                break;

            case NETINFORMATIE:
                mappers.add(initMapper(niBijlageStaxMapper));
                mappers.add(initMapper(niExtraDetailInfoStaxMapper));
                break;
        }

    }

    private StaxMapper initMapper(final StaxMapper mapper) {
        mapper.setInspireConvertibleElementProvider(this);
        mapper.setMappedFeaturetypeProvider(this);
        mapper.initElementHandlers();
        return mapper;
    }

    private void initConvertibles() {
        if (convertableImklElements == null) {
            convertableImklElements = new ConvertableImklElements();
            for (StaxMapper mapper : mappers) {
                if (mapper.getInspireType() != null && !mapper.getBaseElement().equals(mapper.getInspireType())) {
                    convertableImklElements.add(mapper.getBaseElement(), mapper.getInspireType());
                }
            }
        }
    }

    @Override
    public boolean isConvertible(final QName baseElement) {
        return convertableImklElements.contains(baseElement);
    }

    @Override
    public QName getInspireElement(final QName baseElement) {
        return convertableImklElements.getInspireElement(baseElement);
    }

    @SuppressWarnings("rawtypes")
    @Override
    public InspireId findInspireId(final String xLinkRef) {
        return XLinkInspireIdExtractor.extractInspireId(xLinkRef);
    }
}
