package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

/**
 * Processing gone wrong.
 */
public class ImklFileProcessingException extends Exception {

    private static final long serialVersionUID = 1L;

    public ImklFileProcessingException(String message) {
        super(message);
    }

}
