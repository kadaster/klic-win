package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.inspireelements;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;

import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

public interface InspireElementConverter {

    boolean shouldHandle(final StartElement element);

    boolean shouldHandle(final EndElement element);

    XMLEvent convertStartElement(final StartElement element) throws XMLException;

    XMLEvent convertEndElement(final EndElement element);
}
