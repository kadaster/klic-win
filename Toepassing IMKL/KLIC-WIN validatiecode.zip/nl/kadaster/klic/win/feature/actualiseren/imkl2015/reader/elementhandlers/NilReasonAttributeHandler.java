package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.FeatureWithValidationDomainObject;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxHelper;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;
import org.apache.commons.lang3.StringUtils;

import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.StartElement;

final class NilReasonAttributeHandler {

    private NilReasonAttributeHandler() {
    }

    static void handleWarningOnNilReasonMissing(final StartElement element, final FeatureWithValidationDomainObject featureDomainObject,
                                                final ValidationMessageBuilder validationMessageBuilder) {
        final Attribute nilReason = element.getAttributeByName(Elements.ATTRIBUTE_NIL_REASON);
        boolean nilReasonMissing = nilReason == null || StringUtils.isEmpty(nilReason.getValue());
        if (nilReasonMissing) {
            final String elementName = StaxHelper.getQName(element);
            final String gmlId = featureDomainObject.getGmlId();
            validationMessageBuilder.addWarningNillValueButNoNillReasonSpecified(gmlId, elementName);
        }
    }
}