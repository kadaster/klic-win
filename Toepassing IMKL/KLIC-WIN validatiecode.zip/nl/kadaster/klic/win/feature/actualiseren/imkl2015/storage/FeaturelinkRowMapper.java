package nl.kadaster.klic.win.feature.actualiseren.imkl2015.storage;

import nl.kadaster.klic.win.feature.domain.imkl2015.FeatureLink;
import nl.kadaster.klic.win.storage.BaseRowMapper;

import java.sql.SQLException;

class FeaturelinkRowMapper extends BaseRowMapper<FeatureLink> {

    private static final String FIELD_GMLID_FEATUREMEMBER = "gmlid";
    private static final String FIELD_GMLID_LINKEDFEATUREMEMBER = "linkedgmlid";
    private static final String FIELD_FEATURE_ID = "featureid";
    private static final String FIELD_LINKEDFEATURE_ID = "linkedfeatureid";

    private static final String FIELD_IS_KABELOFLEIDING = "is_kabelofleiding";
    private static final String FIELD_IS_CONTAINERLEIDINGELEMENT = "is_containerleidingelement";
    private static final String FIELD_IS_DUCTKABELBED = "is_ductkabelbed";

    @Override
    protected FeatureLink mapRow() throws SQLException {
        FeatureLink featurelink = new FeatureLink();
        featurelink.setGmlidFeaturemember(getString(FIELD_GMLID_FEATUREMEMBER));
        featurelink.setGmlidLinkedFeaturemember(getString(FIELD_GMLID_LINKEDFEATUREMEMBER));
        featurelink.setFeatureId(getLong(FIELD_FEATURE_ID));
        featurelink.setLinkedFeatureId(getLong(FIELD_LINKEDFEATURE_ID));
        featurelink.setKabelOfLeiding(getBoolean(FIELD_IS_KABELOFLEIDING));
        featurelink.setContainerleidingElement(getBoolean(FIELD_IS_CONTAINERLEIDINGELEMENT));
        featurelink.setDuctOfKabelbed(getBoolean(FIELD_IS_DUCTKABELBED));

        return featurelink;
    }
}
