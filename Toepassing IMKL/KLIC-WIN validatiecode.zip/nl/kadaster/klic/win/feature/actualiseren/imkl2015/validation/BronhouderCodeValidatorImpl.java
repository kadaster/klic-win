package nl.kadaster.klic.win.feature.actualiseren.imkl2015.validation;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.FeatureWithValidationDomainObject;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.GmlId;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;

public class BronhouderCodeValidatorImpl implements BronhouderCodeValidator {

    @Override
    public void validateBronhouderCode(
              final String bronhouderCode
            , final FeatureWithValidationDomainObject domainObject
            , final ValidationMessageBuilder validationMessageBuilder) {
       GmlId gmlId = new GmlId(domainObject.getGmlId());
       if (!gmlId.isForBronhouderCode(bronhouderCode)) {
           validationMessageBuilder.addErrorWrongBeheerderBronhoudercode(domainObject.getGmlId(), bronhouderCode);
       }
    }

}
