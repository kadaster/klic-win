package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.beheerdersinformatie;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.BestandIdentificatorHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;

public class BiBestandIdentificatorHandler extends BestandIdentificatorHandler{

    @Override
    protected void validateBestandIdentificator(final String bestandIdentificator, final String gmlId, final ValidationMessageBuilder validationMessageBuilder) {
        validateBestandIdentificatorFormat(bestandIdentificator, gmlId, validationMessageBuilder);
    }

}
