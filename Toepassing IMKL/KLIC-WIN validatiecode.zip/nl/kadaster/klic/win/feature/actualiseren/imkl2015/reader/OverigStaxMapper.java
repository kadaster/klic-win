package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.KabelOfLeiding;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ValidationRule;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.*;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;
import org.springframework.beans.factory.annotation.Autowired;

import javax.xml.namespace.QName;
import java.util.List;

public class OverigStaxMapper extends StaxMapper<KabelOfLeiding> {

    @Autowired
    private GeonauwkeurigheidXyHandler geonauwkeurigheidXyHandler;

    @Autowired
    private WarningTypeHandler warningTypeHandler;

    @Autowired
    private UtilityDeliveryTypeHandler utilityDeliveryTypeHandler;

    @Autowired
    private CurrentStatusHandler currentStatusHandler;

    @Autowired
    private BuismateriaalTypeHandler buismateriaalTypeHandler;

    @Override
    void initElementHandlers() {
        super.initElementHandlers();
        addElementHandler(new InspireIdHandler());
        addElementHandler(new ImklPipeDiameterElement());
        addElementHandler(new ImklPressureElementHandler());
        addElementHandler(new ValidFromHandler());
        addElementHandler(new ValidToHandler());
        addElementHandler(new VerticalPositionHandler());
        addElementHandler(utilityDeliveryTypeHandler);
        addElementHandler(warningTypeHandler);
        addElementHandler(new KabeldiameterHandler());
        addElementHandler(geonauwkeurigheidXyHandler);
        addElementHandler(new ToelichtingHandler());
        addElementHandler(currentStatusHandler);
        addElementHandler(new LabelHandler());
        addElementHandler(new OmschrijvingHandler());
        addElementHandler(buismateriaalTypeHandler);

        // associations
        addElementHandler(new InNetworkNetworkHandler());
        addElementHandler(new LinkNetworkHandler());
        addElementHandler(new DiepteLeggingHandler());
        addElementHandler(new ImklHeeftExtraInformatieHandler());
        addElementHandler(new ImklExtraGeometrieHandler());
    }

    @Override
    boolean canHandle(final QName element) {
        return Elements.OVERIG.equals(element);
    }

    @Override
    protected KabelOfLeiding createDomainObject() {
        return new KabelOfLeiding();
    }

    @Override
    List<ValidationRule> getValidationRules() {
        final List<ValidationRule> validationRules = super.getValidationRules();
        validationRules.add(new ValidationRule(Elements.INSPIRE_ID).withImklStrictlyMandatory());
        return validationRules;
    }

    @Override
    protected QName getBaseElement() {
        return Elements.OVERIG;
    }

    @Override
    public QName getInspireType() {
        // No Inspire variant, so no delivery for inspire
        return null;
    }

}
