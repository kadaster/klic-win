package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.Belanghebbende;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxHelper;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.stream.events.StartElement;

public class UtiliteitsnetLinkHandler extends AbstractElementHandler implements ElementHandler<Belanghebbende> {

    private static final String IMKL_FEATURETYPE_NAME = "Utiliteitsnet";

    @Override
    public boolean shouldHandle(final StartElement element) {
        return sameQName(Elements.UTILITEITSNET_LINK, element.getName());
    }

    @Override
    public void handle(final StartElement element, final FeatureLinks featureLinks, final Belanghebbende belanghebbende,
                       final StaxEventReader staxEventReader, final ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        final String xLink = getXLink(element);
        if (xLink == null) {
            validationMessageBuilder.addMandatoryElementNotFound(belanghebbende.getGmlId(), StaxHelper.getQName(Elements.XLINK_HREF));
        } else {
            featureLinks.addFeatureLink(xLink, belanghebbende, IMKL_FEATURETYPE_NAME);
            belanghebbende.setUtiliteitsnet(xLink);
        }
    }
}
