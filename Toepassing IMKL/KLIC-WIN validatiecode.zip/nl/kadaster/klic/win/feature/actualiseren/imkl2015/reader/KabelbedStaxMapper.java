package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.namespace.QName;

public class KabelbedStaxMapper extends DuctStaxMapper {

    @Override
    boolean canHandle(final QName element) {
        return Elements.KABELBED.equals(element);
    }

    @Override
    public QName getInspireType() {
        return Elements.INSPIRE_DUCT;
    }

    @Override
    protected QName getBaseElement() {
        return Elements.KABELBED;
    }

}
