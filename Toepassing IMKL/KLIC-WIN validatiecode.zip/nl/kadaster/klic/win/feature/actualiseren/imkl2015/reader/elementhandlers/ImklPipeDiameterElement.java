package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ImklFeatureWithValidationDomainObject;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxHelper;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.stream.events.StartElement;
import java.util.Arrays;
import java.util.List;

public class ImklPipeDiameterElement extends AbstractElementHandler implements ElementHandler<ImklFeatureWithValidationDomainObject> {

    private static final List<String> ALLOWED_UOM_VALUES = Arrays.asList(
            "urn:ogc:def:uom:OGC::mm",
            "urn:ogc:def:uom:OGC::cm",
            "urn:ogc:def:uom:OGC::m"
    );

    @Override
    public boolean shouldHandle(final StartElement element) {
        return sameQName(Elements.IMKL_PIPE_DIAMETER, element.getName());
    }

    @Override
    public void handle(final StartElement element, final FeatureLinks featureLinks, final ImklFeatureWithValidationDomainObject kabelOfLeiding,
                       final StaxEventReader staxEventReader, final ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        UomAttributeHandler.handleErrorIfUomIsNotOneOfTheAllowedValues(element, kabelOfLeiding, validationMessageBuilder, ALLOWED_UOM_VALUES);
        StaxHelper.readDouble(staxEventReader); // check format
        // no need to set any value
    }
}
