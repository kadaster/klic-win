package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import javax.xml.namespace.QName;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.Diepte;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

public class DiepteNauwkeurigheidHandler extends AbstractCodelistElementHandler<Diepte> {
    
    private static final String CODELIST_NAME_IMKL = "NauwkeurigheidDiepteValue";

    @Override
    protected QName getHandlingElement() {
        return Elements.DIEPTE_NAUWKEURIGHEID;
    }

    @Override
    protected void preValidate() {
        setCodelist(CODELIST_NAME_IMKL);
    }

    @Override
    protected void postValidate(final Diepte diepte, final String xLinkCodelistValue) {
        diepte.setDiepteNauwkeurigheid(xLinkCodelistValue);
    }
}
