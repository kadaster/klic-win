package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception;

public class XMLException extends Exception {

    private static final long serialVersionUID = 1603015778350050265L;

    private final String gmlId;

    public XMLException(final String message) {
        super(message);
        gmlId = null;
    }

    public XMLException(final String message, final String gmlId) {
        super(message);
        this.gmlId = gmlId;
    }

    public XMLException(final String message, final Throwable cause) {
        super(message, cause);
        gmlId = null;
    }

    public String getGmlId() {
        return gmlId;
    }
}
