package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import javax.xml.stream.events.StartElement;

import org.springframework.beans.factory.annotation.Autowired;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ImklFeatureWithValidationDomainObject;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.CodelistValueValidator;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

public class BestandMediaTypeHandler extends AbstractElementHandler implements ElementHandler<ImklFeatureWithValidationDomainObject> {

    private static final String CODELIST_NAME_IMKL = "BestandMediaTypeValue";
    private static final String RESTRICED_CODELIST_VALUE = "http://definities.geostandaarden.nl/imkl2015/id/waarde/BestandMediaTypeValue/PDF";

    @Autowired
    private CodelistValueValidator codelistValueValidator;

    @Override
    public boolean shouldHandle(final StartElement element) {
        return sameQName(Elements.BESTANDMEDIATYPE, element.getName());
    }

    @Override
    public void handle(final StartElement element, final FeatureLinks featureLinks, final ImklFeatureWithValidationDomainObject feature,
                       final StaxEventReader staxEventReader, final ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        final String bestandMediaTypeCodeListValue = getXLink(element);
        if (codelistValueValidator.validateRestricedCodelistValue(CODELIST_NAME_IMKL, bestandMediaTypeCodeListValue, validationMessageBuilder, feature, RESTRICED_CODELIST_VALUE)) {
            feature.setBestandMediaType(getCodelistValue(bestandMediaTypeCodeListValue));
        }

        // Set seen this element for IMKL strictly mandatory
        feature.setSeenElementValue(Elements.BESTANDMEDIATYPE, element.getLocation().getLineNumber(), bestandMediaTypeCodeListValue != null);
    }
}
