package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.tasklet;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.BatchJobSettings;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.context.BatchJobContext;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.data.BatchJobData;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.data.ValidationMessagesTracker;
import nl.kadaster.klic.win.feature.domain.InformatieSoort;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

public class StartupBatchTasklet implements Tasklet {

    private final BatchJobContext batchJobContext;
    private final ValidationMessagesTracker validationMessagesTracker;

    // Job properties
    private String bronhoudercode;
    private long actualisatieId;
    private long batchSize;
    private String filename;
    private int extraThreadsOnTopOfNrOfProcessors;
    private InformatieSoort informatiesoort;

    @Autowired
    public StartupBatchTasklet(final BatchJobContext batchJobContext, final ValidationMessagesTracker validationMessagesTracker) {
        this.batchJobContext = batchJobContext;
        this.validationMessagesTracker = validationMessagesTracker;
    }

    @Override
    public RepeatStatus execute(final StepContribution stepContribution, final ChunkContext chunkContext) throws Exception {
        final int threadPoolSize = BatchJobSettings.POOL_SIZE + extraThreadsOnTopOfNrOfProcessors;
        final BatchJobData batchJobData = new BatchJobData(informatiesoort, bronhoudercode, actualisatieId, filename, batchSize, threadPoolSize, validationMessagesTracker);
        batchJobContext.init(batchJobData);
        return RepeatStatus.FINISHED;
    }

    public void setBronhoudercode(final String bronhoudercode) {
        this.bronhoudercode = bronhoudercode;
    }

    public void setActualisatieId(final long actualisatieId) {
        this.actualisatieId = actualisatieId;
    }

    public void setFilename(final String filename) {
        this.filename = filename;
    }

    public void setBatchSize(final long batchSize) {
        this.batchSize = batchSize;
    }

    public void setExtraThreadsOnTopOfNrOfProcessors(final int extraThreadsOnTopOfNrOfProcessors) {
        this.extraThreadsOnTopOfNrOfProcessors = extraThreadsOnTopOfNrOfProcessors;
    }

    public void setInformatiesoort(final String informatiesoortName) {
        informatiesoort = InformatieSoort.valueOf(informatiesoortName);
    }

}
