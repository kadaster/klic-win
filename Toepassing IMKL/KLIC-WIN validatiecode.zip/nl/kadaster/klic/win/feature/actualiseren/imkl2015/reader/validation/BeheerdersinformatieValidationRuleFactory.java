package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ValidationRule;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

public class BeheerdersinformatieValidationRuleFactory extends ValidationRuleFactory {
    @Override
    public ValidationRule getBestandMediaTypeValidationRule() {
        return new ValidationRule(Elements.BESTANDMEDIATYPE).withImklStrictlyMandatory();
    }

    @Override
    public ValidationRule getBestandLocatieValidationRule() {
        return new ValidationRule(Elements.BESTANDLOCATIE).withImklStrictlyMandatory();
    }
}
