package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.namespace.QName;

public class KastStaxMapper extends AbstractContainerLeidingElementStaxMapper {

    @Override
    boolean canHandle(final QName element) {
        return Elements.KAST.equals(element);
    }

    @Override
    public QName getInspireType() {
        return Elements.INSPIRE_CABINET;
    }

    @Override
    protected QName getBaseElement() {
        return Elements.KAST;
    }

}
