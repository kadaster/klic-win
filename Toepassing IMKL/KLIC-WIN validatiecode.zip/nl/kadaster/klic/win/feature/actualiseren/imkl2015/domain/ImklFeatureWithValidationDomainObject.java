package nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain;

public class ImklFeatureWithValidationDomainObject extends FeatureWithValidationDomainObject {

    private String label;
    private String omschrijving;
    private String geoNauwkeurigheidXY;
    private String toelichting;
    private String bestandLocatie;
    private String bestandMediaType;

    @Override
    public String getLabel() {
        return label;
    }

    @Override
    public void setLabel(String label) {
        this.label = label;
    }

    public String getOmschrijving() {
        return omschrijving;
    }

    public void setOmschrijving(String omschrijving) {
        this.omschrijving = omschrijving;
    }

    public String getGeoNauwkeurigheidXY() {
        return geoNauwkeurigheidXY;
    }

    public void setGeoNauwkeurigheidXY(String geoNauwkeurigheidXY) {
        this.geoNauwkeurigheidXY = geoNauwkeurigheidXY;
    }

    public String getToelichting() {
        return toelichting;
    }

    public void setToelichting(String toelichting) {
        this.toelichting = toelichting;
    }

    public String getBestandLocatie() {
        return bestandLocatie;
    }

    public void setBestandLocatie(final String bestandLocatie) {
        this.bestandLocatie = bestandLocatie;
    }

    public String getBestandMediaType() {
        return bestandMediaType;
    }

    public void setBestandMediaType(final String bestandMediaType) {
        this.bestandMediaType = bestandMediaType;
    }

}
