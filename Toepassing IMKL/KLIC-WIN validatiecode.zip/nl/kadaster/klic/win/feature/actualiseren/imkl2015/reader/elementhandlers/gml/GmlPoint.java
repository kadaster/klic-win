package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.gml;

import org.postgis.PGgeometry;
import org.postgis.Point;

class GmlPoint implements GmlGeometry {
    
    private final Point point;

    GmlPoint(final Point point) {
        this.point = point;
    }

    @Override
    public PGgeometry getPGgeometry() {
        return new PGgeometry(point);
    }
    
}
