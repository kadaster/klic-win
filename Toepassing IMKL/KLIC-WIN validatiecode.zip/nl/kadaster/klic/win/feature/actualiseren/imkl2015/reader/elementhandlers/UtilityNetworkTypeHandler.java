package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.Utiliteitsnet;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.storage.ThemaDao;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;
import org.springframework.beans.factory.annotation.Autowired;

import javax.xml.namespace.QName;

public class UtilityNetworkTypeHandler extends AbstractCodelistElementHandler<Utiliteitsnet> {

    private static final String CODELIST_NAME_INSPIRE = "UtilityNetworkTypeIMKLValue";

    @Autowired
    private ThemaDao themaDao;

    @Override
    protected QName getHandlingElement() {
        return Elements.UTILITYNETWORKTYPE;
    }

    @Override
    protected void preValidate() {
        setCodelist(CODELIST_NAME_INSPIRE);
    }

    @Override
    protected void postValidate(final Utiliteitsnet utiliteitsnet, String xLinkCodelistValue) {
        long themaId = themaDao.getThemaId(xLinkCodelistValue);
        utiliteitsnet.setUtilityNetworkType(xLinkCodelistValue);
        utiliteitsnet.setInspirethema(themaId);
    }
}
