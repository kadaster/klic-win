package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.tasklet;

import nl.kadaster.klic.util.FileStore;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.context.BatchJobContext;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.data.BatchJobData;
import nl.kadaster.klic.win.feature.domain.InformatieSoort;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.File;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;

public class ProcessZipTasklet implements Tasklet {

    private static final Logger LOG = LoggerFactory.getLogger(ProcessZipTasklet.class);

    private final FileStore aanleveringFileStore;
    private final BatchJobContext batchJobContext;

    private long actualisatieId;

    @Autowired
    public ProcessZipTasklet(final BatchJobContext batchJobContext,
                             final FileStore aanleveringFileStore) {
        this.batchJobContext = batchJobContext;
        this.aanleveringFileStore = aanleveringFileStore;
    }

    public void setActualisatieId(final long actualisatieId) {
        this.actualisatieId = actualisatieId;
    }

    @Override
    public RepeatStatus execute(final StepContribution contribution, final ChunkContext chunkContext) throws Exception {

        final BatchJobData batchJobData = batchJobContext.getBatchJobData(actualisatieId);

        final String filename = batchJobData.getFilename();
        LOG.info("Processing ZIP file...");

        final File file = aanleveringFileStore.retrieveFile(filename);
        try (ZipFile zipFile = new ZipFile(file)) {

            int numberOfXmlFiles = 0;

            Enumeration<? extends ZipEntry> entries = zipFile.entries();
            while (entries.hasMoreElements()) {
                ZipEntry zipEntry = entries.nextElement();

                if (isXmlFile(zipEntry.getName())) {
                    numberOfXmlFiles++;
                } else {
                    batchJobData.getFilesInZipFile().add(zipEntry.getName());
                }
            }

            if (numberOfXmlFiles > 1) {
                LOG.error("Found {} XML files in the zip file", numberOfXmlFiles);
                batchJobData.getValidationMessageBuilder().addErrorMultipleImklFiles();
                chunkContext.getStepContext().getStepExecution().setExitStatus(ExitStatus.FAILED);
            }

            if (numberOfXmlFiles < 1) {
                LOG.error("No XML file found in the zip file");
                batchJobData.getValidationMessageBuilder().addErrorNoImklFile();
                chunkContext.getStepContext().getStepExecution().setExitStatus(ExitStatus.FAILED);
            }

            if (InformatieSoort.NETINFORMATIE == batchJobData.getInformatieSoort() &&
                    !batchJobData.getFilesInZipFile().isEmpty()) {
                LOG.error("Found {} files other than the XML file in the zip file.", batchJobData.getFilesInZipFile().size());
                batchJobData.getValidationMessageBuilder().addErrorNoAttachmentsAllowed();
                chunkContext.getStepContext().getStepExecution().setExitStatus(ExitStatus.FAILED);
            }
        } catch (ZipException ze) {
            LOG.error("Unable to read zip-file", ze);
            batchJobData.getValidationMessageBuilder().addErrorInvalidZipFile(ze.getLocalizedMessage());
            chunkContext.getStepContext().getStepExecution().setExitStatus(ExitStatus.FAILED);
        }
        return RepeatStatus.FINISHED;
    }


    private static boolean isXmlFile(final String filename){
        return filename.toLowerCase().endsWith(".xml");
    }
}
