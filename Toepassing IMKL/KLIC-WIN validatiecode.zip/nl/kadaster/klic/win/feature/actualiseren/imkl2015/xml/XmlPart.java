package nl.kadaster.klic.win.feature.actualiseren.imkl2015.xml;

public class XmlPart {

    private final XmlRootElement xmlRootElement;
    private final XmlElement xmlElement;

    XmlPart(final XmlRootElement xmlRootElement, final XmlElement xmlElement) {
        this.xmlRootElement =xmlRootElement;
        this.xmlElement = xmlElement;
    }

    public XmlRootElement getXmlRootElement() {
        return xmlRootElement;
    }

    public XmlElement getXmlElement() {
        return xmlElement;
    }

    public String getCompleteXmlPart() {
        return XmlRootElement.getXmlDeclarationUtf8() + getXmlRootElement().getStartTag() + getXmlElement().getXml() + getXmlRootElement().getEndTag();

    }
}
