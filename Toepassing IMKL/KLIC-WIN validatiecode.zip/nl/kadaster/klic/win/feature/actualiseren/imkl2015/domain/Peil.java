package nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain;

import org.joda.time.DateTime;

public class Peil {
    
    private Double measure;
    private String uom;
    private DateTime datumOpmeting;
    
    public Double getMeasure() {
        return measure;
    }
    
    public void setMeasure(final Double measure) {
        this.measure = measure;
    }
    
    public String getUnitsOfMeasure() {
        return uom;
    }
    
    public void setUnitsOfMeasure(final String unitsOfMeasure) {
        this.uom = unitsOfMeasure;
    }
    
    public DateTime getDatumOpmeting() {
        return datumOpmeting;
    }
    
    public void setDatumOpmeting(final DateTime datumOpmeting) {
        this.datumOpmeting = datumOpmeting;
    }
    
    
    /**
     * Gets the 'measure' (level) in cm (rounded half/even) or
     * NULL if UOM is not one of mm, cm or m.
     * @return measure in cm
     */
    public Integer getMeasureInCm() {
        Integer measureInCm = null;
        if (uom != null && measure != null) {
            switch(uom) {
                case "m":
                    measureInCm = (int) Math.round(100d * measure);
                    break;
                case "cm":
                    measureInCm = (int) Math.round(measure);
                    break;
                case "mm":
                    measureInCm = (int) Math.round(measure/10d);
                    break;
                default:
                    measureInCm = null;
            }
        }
        return measureInCm;
    }
    
}
