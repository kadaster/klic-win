package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.Annotatie;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ValidationRule;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.AangrijpingHorizontaalHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.AangrijpingVerticaalHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.AnnotatieLiggingHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.AnnotatieTypeHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ImklIdentificatieHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ImklInNetworkHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.LabelHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.OmschrijvingHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.RotatiehoekHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.LabelValuePresenceValidationRuleFactory;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;
import org.springframework.beans.factory.annotation.Autowired;

import javax.xml.namespace.QName;
import java.util.List;

public class AnnotatieStaxMapper extends StaxMapper<Annotatie> {

    private final AnnotatieTypeHandler annotatieTypeHandler;
    private final AangrijpingHorizontaalHandler aangrijpingHorizontaalHandler;
    private final AangrijpingVerticaalHandler aangrijpingVerticaalHandler;

    @Autowired
    public AnnotatieStaxMapper(final AnnotatieTypeHandler annotatieTypeHandler, final AangrijpingVerticaalHandler aangrijpingVerticaalHandler, final AangrijpingHorizontaalHandler aangrijpingHorizontaalHandler) {
        this.annotatieTypeHandler = annotatieTypeHandler;
        this.aangrijpingVerticaalHandler = aangrijpingVerticaalHandler;
        this.aangrijpingHorizontaalHandler = aangrijpingHorizontaalHandler;
    }

    @Override
    void initElementHandlers() {
        super.initElementHandlers();
        addElementHandler(new ImklIdentificatieHandler());
        addElementHandler(new LabelHandler());
        addElementHandler(aangrijpingHorizontaalHandler);
        addElementHandler(aangrijpingVerticaalHandler);
        addElementHandler(new OmschrijvingHandler());
        addElementHandler(new ImklInNetworkHandler());

        addElementHandler(annotatieTypeHandler);
        addElementHandler(new RotatiehoekHandler());
        addElementHandler(new AnnotatieLiggingHandler());
    }

    @Override
    boolean canHandle(final QName element) {
        return Elements.ANNOTATIE.equals(element);
    }

    @Override
    List<ValidationRule> getValidationRules() {
        final List<ValidationRule> validationRules = super.getValidationRules();
        validationRules.add(new ValidationRule(Elements.IMKL_IDENTIFICATIE).withImklStrictlyMandatory());
        validationRules.add(LabelValuePresenceValidationRuleFactory.createValidationRule());
        return validationRules;
    }

    @Override
    protected Annotatie createDomainObject() {
        return new Annotatie();
    }

    @Override
    public QName getInspireType() {
        return null;
    }

    @Override
    protected QName getBaseElement() {
        return Elements.ANNOTATIE;
    }
}
