package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.inspireelements;

import nl.kadaster.klic.win.feature.common.util.gml.Elements;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.QNameHelper;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxHelper;
import org.apache.commons.lang3.StringUtils;

import javax.xml.stream.XMLEventFactory;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class GmlConverter implements InspireElementConverter {

    private static final String PREFIX_EPSG = "urn:ogc:def:crs:EPSG::";
    private final XMLEventFactory xmlEventFactory = XMLEventFactory.newInstance();

    @Override
    public boolean shouldHandle(final StartElement element) {
        return QNameHelper.sameQName(Elements.GML_POINT, element.getName()) || QNameHelper.sameQName(Elements.GML_LINESTRING, element.getName())
                && StaxHelper.containsAttribute(element, Elements.ATTR_GML_SRS_NAME);
    }

    @Override
    public boolean shouldHandle(final EndElement element) {
        return false;
    }

    @Override
    public XMLEvent convertStartElement(final StartElement element) {
        return createElementWithUpdatedSrsName(element);
    }

    private StartElement createElementWithUpdatedSrsName(final StartElement baseElement) {
        List<Attribute> attributes = new ArrayList<>();
        @SuppressWarnings("unchecked")
        Iterator<Attribute> iterator = baseElement.getAttributes();
        while (iterator.hasNext()) {
            Attribute baseAttribute = iterator.next();
            if (QNameHelper.sameQName(Elements.ATTR_GML_SRS_NAME, baseAttribute.getName())) {
                attributes.add(xmlEventFactory.createAttribute(baseAttribute.getName(), createSrsName(baseAttribute.getValue())));
            } else {
                attributes.add(baseAttribute);
            }
        }
        return xmlEventFactory.createStartElement(baseElement.getName(), attributes.iterator(), baseElement.getNamespaces());
    }

    private static String createSrsName(final String originalSrsName) {
        String newSrsName = originalSrsName;
        String[] split = StringUtils.split(originalSrsName, "/");
        if (split.length > 0) {
            String epsgCode = split[split.length - 1];
            newSrsName = PREFIX_EPSG + epsgCode;
        }
        return newSrsName;
    }

    @Override
    public XMLEvent convertEndElement(final EndElement element) {
        return null;
    }

}
