package nl.kadaster.klic.win.feature.actualiseren.imkl2015.storage;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.Thema;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class ThemaRowMapper implements RowMapper<Thema> {

    @Override
    public Thema mapRow(ResultSet resultSet, int i) throws SQLException {
        Thema thema = new Thema();
        int col = 1;
        thema.setId(resultSet.getLong(col++));
        thema.setThema(resultSet.getString(col));
        return thema;
    }
}
