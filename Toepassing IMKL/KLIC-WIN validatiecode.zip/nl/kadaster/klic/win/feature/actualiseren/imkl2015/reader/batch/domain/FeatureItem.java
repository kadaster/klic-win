package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.domain;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.FeatureWithValidation;
import nl.kadaster.klic.win.feature.domain.imkl2015.FeatureLink;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.GmlObject;

import java.util.List;

public class FeatureItem {

    private final int lineNr;
    private final String xmlString;
    private final long actualisatieId;
    private final String bronhoudercode;
    
    private FeatureWithValidation feature;
    private GmlObject wionGmlObject;
    private GmlObject inspireGmlObject;
    private List<FeatureLink> featureLinks;

    public FeatureItem(final long actualisatieId, final String bronhoudercode, final String xmlString, final int lineNr) {
        this.actualisatieId = actualisatieId;
        this.bronhoudercode = bronhoudercode;
        this.xmlString = xmlString;
        this.lineNr = lineNr;
    }

    public long getActualisatieId() {
        return actualisatieId;
    }

    public String getBronhoudercode() {
        return bronhoudercode;
    }

    public String getXmlString() {
        return xmlString;
    }

    public int getLineNr() {
        return lineNr;
    }

    public FeatureWithValidation getFeature() {
        return feature;
    }

    public void setFeature(final FeatureWithValidation feature) {
        this.feature = feature;
    }

    public GmlObject getWionGmlObject() {
        return wionGmlObject;
    }

    public void setWionGmlObject(final GmlObject wionGmlObject) {
        this.wionGmlObject = wionGmlObject;
    }

    public GmlObject getInspireGmlObject() {
        return inspireGmlObject;
    }

    public void setInspireGmlObject(final GmlObject inspireGmlObject) {
        this.inspireGmlObject = inspireGmlObject;
    }

    public List<FeatureLink> getFeatureLinks() {
        return featureLinks;
    }

    public void setFeatureLinks(final List<FeatureLink> featureLinks) {
        this.featureLinks = featureLinks;
    }
}
