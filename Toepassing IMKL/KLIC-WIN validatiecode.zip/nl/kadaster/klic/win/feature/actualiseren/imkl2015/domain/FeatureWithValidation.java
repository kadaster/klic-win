package nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain;

import nl.kadaster.klic.win.feature.domain.imkl2015.Feature;

import javax.xml.namespace.QName;
import java.util.ArrayList;
import java.util.List;

public class FeatureWithValidation extends Feature {
    private List<ValidationRule> validationRules = new ArrayList<>();
    private final List<SeenElement> elementsSeen  = new ArrayList<>();

    public List<ValidationRule> getValidationRules() {
        return validationRules;
    }

    public void setValidationRules(final List<ValidationRule> validationRules) {
        this.validationRules = validationRules;
    }

    public void setSeenElementValue(final QName qName, final int lineNumber, final boolean valuePresent) {
        elementsSeen.add(new SeenElement(qName, lineNumber, valuePresent));
    }

    public SeenElement getSeenElement(final QName qName) {
        for (SeenElement seenElement : elementsSeen) {
            if (seenElement.getName().equals(qName)) {
                return seenElement;
            }
        }
        return null;
    }

}
