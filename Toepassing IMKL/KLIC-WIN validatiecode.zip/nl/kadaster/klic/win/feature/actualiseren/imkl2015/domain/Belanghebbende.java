package nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain;

public class Belanghebbende extends ImklFeatureWithValidationDomainObject {

    private boolean eisVoorzorgsmaatregel;
    private boolean betrokkenBijAanvraag;
    private String utiliteitsnet;

    public boolean isEisVoorzorgsmaatregel() {
        return eisVoorzorgsmaatregel;
    }

    public void setEisVoorzorgsmaatregel(final boolean eisVoorzorgsmaatregel) {
        this.eisVoorzorgsmaatregel = eisVoorzorgsmaatregel;
    }

    public boolean isBetrokkenBijAanvraag() {
        return betrokkenBijAanvraag;
    }

    public void setBetrokkenBijAanvraag(final boolean betrokkenBijAanvraag) {
        this.betrokkenBijAanvraag = betrokkenBijAanvraag;
    }

    public String getUtiliteitsnet() {
        return utiliteitsnet;
    }

    public void setUtiliteitsnet(final String utiliteitsnet) {
        this.utiliteitsnet = utiliteitsnet;
    }
}
