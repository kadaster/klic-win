package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.gml;

import java.util.ArrayList;
import java.util.List;

import org.postgis.PGgeometry;
import org.postgis.Point;

import nl.kadaster.klic.win.storage.DatabaseHelper;
import nl.kadaster.klic.win.storage.GeometryException;

class GmlCurve implements GmlGeometry {

    private static final String NO_SEGMENTS = "Curve zonder segmenten.";
    private static final String SEGMENTS_NOT_CONNECTED = "De segmenten in the curve zijn niet verbonden.";
    
    private final List<GmlCurveSegment> segments = new ArrayList<>();
    private List<Point> points;
    
    public void add(final GmlCurveSegment segment) throws GeometryException {
        if (segments.isEmpty()) {
            segments.add(segment);
        } else {
            if (!connected(getLastSegment(), segment)) {
                throw new GeometryException(SEGMENTS_NOT_CONNECTED);
            }
            segments.add(segment);
        }
    }
    
    void endCurveTag() throws GeometryException {
        if (segments.isEmpty()) {
            throw new GeometryException(NO_SEGMENTS);
        }
        points = mergeSegments();
    }
    
    @Override
    public PGgeometry getPGgeometry() {
        return DatabaseHelper.gmlPosListToPgLineString(points);
    }
    
    private GmlCurveSegment getLastSegment() {
        return segments.get(segments.size()-1);
    }
    
    private static boolean connected(final GmlCurveSegment segment0, final GmlCurveSegment segment1) {
        return samePoints( segment0.getLastPoint(), segment1.getFirstPoint() );
    }
    
    @SuppressWarnings("FloatingPointEquality")
    private static boolean samePoints(final Point point0, final Point point1) {
        return point0.getX() == point1.getX() && point0.getY() == point1.getY();
    }
    
    private List<Point> mergeSegments() {
        List<Point> pointsList = null;
        for (GmlCurveSegment segment: segments) {
            if (pointsList == null) {
                pointsList = segment.getPoints();
            } else {
                List<Point> segmentPoints = segment.getPoints();
                pointsList.addAll( segmentPoints.subList(1, segmentPoints.size()) );
            }
        }
        return pointsList;
    } 

}
