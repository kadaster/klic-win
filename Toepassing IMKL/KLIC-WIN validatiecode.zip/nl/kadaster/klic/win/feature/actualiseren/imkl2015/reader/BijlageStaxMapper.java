package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import java.util.List;

import javax.xml.namespace.QName;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.Bijlage;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ValidationRule;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ElementHandlerFactory;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.AanleveringCharacteristics;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationRuleFactory;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

public class BijlageStaxMapper extends StaxMapper<Bijlage> {

    private static final String BIJLAGETYPE_NIET_BETROKKEN = "nietBetrokken";
    private static final String BIJLAGETYPE_EIS_VOORZORGSMAATREGEL = "eisVoorzorgsmaatregel";
    private final ElementHandlerFactory elementHandlerFactory;

    private final ValidationRuleFactory validationRuleFactory;

    public BijlageStaxMapper(final ElementHandlerFactory elementHandlerFactory, final ValidationRuleFactory validationRuleFactory) {
        assert elementHandlerFactory != null;
        assert validationRuleFactory != null;

        this.elementHandlerFactory = elementHandlerFactory;
        this.validationRuleFactory = validationRuleFactory;
    }

    @Override
    void initElementHandlers() {
        super.initElementHandlers();

        addElementHandler(elementHandlerFactory.getImklIdentificatieHandler());
        addElementHandler(elementHandlerFactory.getBijlageTypeHandler());
        addElementHandler(elementHandlerFactory.getBestandMediaTypeHandler());
        addElementHandler(elementHandlerFactory.getBestandIdentificatorHandler());
        addElementHandler(elementHandlerFactory.getBestandLocatieHandler());
    }

    @Override
    boolean canHandle(final QName element) {
        return Elements.BIJLAGE.equals(element);
    }

    @Override
    public QName getInspireType() {
        return null;
    }

    @Override
    protected Bijlage createDomainObject() {
        return new Bijlage();
    }

    @Override
    List<ValidationRule> getValidationRules() {
        final List<ValidationRule> validationRules = super.getValidationRules();
        validationRules.add(validationRuleFactory.getImklIdentificatieValidationRule());
        validationRules.add(validationRuleFactory.getBestandLocatieValidationRule());
        validationRules.add(validationRuleFactory.getBestandMediaTypeValidationRule());
        return validationRules;
    }

    @Override
    protected QName getBaseElement() {
        return Elements.BIJLAGE;
    }

    @Override
    protected void fillAanleveringCharacteristics(final AanleveringCharacteristics aanleveringCharacteristics, final Bijlage bijlage) {
        if (BIJLAGETYPE_NIET_BETROKKEN.equals(bijlage.getBijlageType())) {
            aanleveringCharacteristics.setHasNietBetrokkenBijlage(true);
        } else if (BIJLAGETYPE_EIS_VOORZORGSMAATREGEL.equals(bijlage.getBijlageType())) {
            aanleveringCharacteristics.setHasEisVoorzorgsmaatregelBijlage(true);
        }
    }
}
