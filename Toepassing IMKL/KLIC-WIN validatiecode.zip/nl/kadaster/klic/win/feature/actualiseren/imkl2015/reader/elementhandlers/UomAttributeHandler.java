package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.FeatureWithValidationDomainObject;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxHelper;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;
import org.apache.commons.lang3.StringUtils;

import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.StartElement;
import java.util.List;

final class UomAttributeHandler {

    private UomAttributeHandler() {
    }

    static void handleErrorIfUomIsNotOneOfTheAllowedValues(final StartElement element, final FeatureWithValidationDomainObject featureDomainObject,
                                                           final ValidationMessageBuilder validationMessageBuilder,
                                                           final List<String> allowedValues) {
        final Attribute uom = element.getAttributeByName(Elements.ATTRIBUTE_UOM);
        boolean uomPresent = uom != null && !StringUtils.isEmpty(uom.getValue());
        if (uomPresent && !allowedValues.contains(uom.getValue())) {
            final String elementName = StaxHelper.getQName(element);
            final String gmlId = featureDomainObject.getGmlId();
            validationMessageBuilder.addErrorInvalidUomValueSpecified(gmlId, elementName, allowedValues);
        }
    }

}