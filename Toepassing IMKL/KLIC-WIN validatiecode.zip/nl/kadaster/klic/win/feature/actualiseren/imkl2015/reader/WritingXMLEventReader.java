package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;


import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.inspireelements.InspireConvertibleElementProvider;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.inspireelements.MappedFeaturetypeProvider;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLEventWriter;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Namespace;
import javax.xml.stream.events.XMLEvent;
import java.io.StringWriter;
import java.util.List;

/**
 * Handles the reading of the input stream during handling of a featuremember and, using this input, writes an xml String for inspire and imkl.
 */
class WritingXMLEventReader implements StaxEventReader {

    private final XMLEventReader eventReader;
    private final XMLEventWriter xmlEventWriterImkl;
    private final StringWriter writerImklXml;
    private final XMLEventWriter xmlEventWriterInspire;
    private final StringWriter writerInspireXml;

    private final InspireElementConverters inspireElementConverters;


    WritingXMLEventReader(final XMLEventReader eventReader, final List<Namespace> globalNamespaces,
                          final InspireConvertibleElementProvider inspireConvertibleElementProvider,
                          final MappedFeaturetypeProvider mappedFeaturetypeProvider) throws XMLStreamException {
        this.eventReader = eventReader;

        inspireElementConverters = new InspireElementConverters(
                globalNamespaces, inspireConvertibleElementProvider, mappedFeaturetypeProvider
        );

        writerImklXml = new StringWriter();
        xmlEventWriterImkl = createXmlEventWriter(writerImklXml);

        writerInspireXml = new StringWriter();
        xmlEventWriterInspire = createXmlEventWriter(writerInspireXml);
    }

    private static XMLEventWriter createXmlEventWriter(final StringWriter writerImklXml) throws XMLStreamException {
        final XMLOutputFactory xmlOutputFacReparingNamespaces = XMLOutputFactory.newInstance();
        xmlOutputFacReparingNamespaces.setProperty(XMLOutputFactory.IS_REPAIRING_NAMESPACES, Boolean.TRUE);
        return xmlOutputFacReparingNamespaces.createXMLEventWriter(writerImklXml);
    }

    @Override
    public XMLEvent nextEvent() throws XMLException {
        XMLEvent event = null;
        if (eventReader.hasNext()) {
            try {
                event = eventReader.nextEvent();
            } catch (XMLStreamException e) {
                throw new XMLException("Error reading XML: " + e.getMessage(), e);
            }
            writeEventXml(event);
        }
        return event;
    }

    void writeEventXml(final XMLEvent event) throws XMLException {
        try {
            xmlEventWriterImkl.add(event);
            xmlEventWriterInspire.add(inspireElementConverters.toInspire(event));
        } catch (XMLStreamException e) {
            throw new XMLException("Error reading XML", e);
        }
    }

    String getInspireXml() {
        return writerInspireXml.toString();
    }

    String getImklXml() {
        return writerImklXml.toString();
    }
}
