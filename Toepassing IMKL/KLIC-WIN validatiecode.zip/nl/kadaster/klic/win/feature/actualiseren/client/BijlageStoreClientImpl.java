package nl.kadaster.klic.win.feature.actualiseren.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

public class BijlageStoreClientImpl implements BijlageStoreClient {

    private static final Logger LOG = LoggerFactory.getLogger(BijlageStoreClientImpl.class);
    private String fileIdentificatorUrl;

    @Override
    public boolean checkIfFileExist(final String fileIdentificator) {
        String url = fileIdentificatorUrl + fileIdentificator;
        LOG.debug("Calling rest service with GET url: {}", url);

        boolean result;
        try {
            RestTemplate template = new RestTemplate();
            String answer = template.getForObject(url, String.class);
            result = "true".equals(answer);
        } catch (RestClientException ex) {
            final String message = "Unable to execute GET rest service call. [url: " + url + "]";
            LOG.warn(message, ex);
            throw new BijlageStoreClientException(message);
        }
        return result;
    }

    public void setFileIdentificatorUrl(final String fileIdentificatorUrl) {
        this.fileIdentificatorUrl = fileIdentificatorUrl;
    }

}
