package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ImklFeatureWithValidationDomainObject;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ValidationRule;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.BronhouderCodeHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ImklIdentificatieHandler;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;
import org.springframework.beans.factory.annotation.Autowired;

import javax.xml.namespace.QName;
import java.util.List;

public class BeheerderStaxMapper extends StaxMapper<ImklFeatureWithValidationDomainObject> {

    @Autowired
    private BronhouderCodeHandler bronhouderCodeHandler;

    @Override
    void initElementHandlers() {
        super.initElementHandlers();

        addElementHandler(new ImklIdentificatieHandler());
        addElementHandler(bronhouderCodeHandler);
    }

    @Override
    boolean canHandle(final QName element) {
        return Elements.BEHEERDER.equals(element);
    }

    @Override
    public QName getInspireType() {
        return null;
    }

    @Override
    protected ImklFeatureWithValidationDomainObject createDomainObject() {
        return new ImklFeatureWithValidationDomainObject();
    }

    @Override
    List<ValidationRule> getValidationRules() {
        final List<ValidationRule> validationRules = super.getValidationRules();
        validationRules.add(new ValidationRule(Elements.BRONHOUDERCODE).withImklStrictlyMandatory());
        return validationRules;
    }

    @Override
    protected QName getBaseElement() {
        return Elements.BEHEERDER;
    }
}
