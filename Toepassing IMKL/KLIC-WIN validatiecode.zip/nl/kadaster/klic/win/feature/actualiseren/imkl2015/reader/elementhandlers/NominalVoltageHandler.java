package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.KabelOfLeiding;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxHelper;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.stream.events.StartElement;
import java.util.Collections;
import java.util.List;

public class NominalVoltageHandler extends AbstractElementHandler implements ElementHandler<KabelOfLeiding> {

    private static final List<String> ALLOWED_UOM_VALUES = Collections.singletonList(
            "urn:ogc:def:uom:OGC::V"
    );

    @Override
    public boolean shouldHandle(StartElement element) {
        return sameQName(Elements.NOMINAL_VOLTAGE, element.getName());
    }

    @Override
    public void handle(StartElement element, FeatureLinks featureLinks, KabelOfLeiding kabelOfLeiding, StaxEventReader staxEventReader, ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        final Double nominalVoltage = StaxHelper.readDouble(staxEventReader);
        UomAttributeHandler.handleErrorIfUomIsNotOneOfTheAllowedValues(element, kabelOfLeiding, validationMessageBuilder, ALLOWED_UOM_VALUES);
        kabelOfLeiding.setNominalVoltage(nominalVoltage);
        kabelOfLeiding.setSeenElementValue(Elements.NOMINAL_VOLTAGE, element.getLocation().getLineNumber(), nominalVoltage != null);
    }

}
