package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import nl.kadaster.klic.geo.BboxCreator;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.FeatureWithValidationDomainObject;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.GmlObject;
import nl.kadaster.klic.win.feature.domain.imkl2015.ImklFeatureType;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ValidationRule;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.domain.FeatureItem;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.BeginLifespanVersionHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.BoundedByHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ElementHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.EndLifespanVersionHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.ImklFeaturetypeProvider;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxHelper;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.StaxMapperException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.inspireelements.InspireConvertibleElementProvider;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.inspireelements.MappedFeaturetypeProvider;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.AanleveringCharacteristics;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.DomainObjectValidator;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.storage.InspireFeatureTypeDao;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.storage.WionFeatureTypeDao;
import nl.kadaster.klic.win.feature.domain.DomainObject;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.UncategorizedSQLException;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.Namespace;
import javax.xml.stream.events.XMLEvent;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public abstract class StaxMapper<T extends FeatureWithValidationDomainObject> {

    private static final Logger LOG = LoggerFactory.getLogger(StaxMapper.class);

    private final List<ElementHandler> elementHandlers = new ArrayList<>();

    private MappedFeaturetypeProvider mappedFeaturetypeProvider;

    private InspireConvertibleElementProvider inspireConvertibleElementProvider;

    @Autowired
    private ImklFeaturetypeProvider imklFeaturetypeProvider;

    @Autowired
    private DomainObjectValidator domainObjectValidator;

    @Autowired
    private InspireFeatureTypeDao inspireFeatureTypeDao;

    @Autowired
    private WionFeatureTypeDao wionFeatureTypeDao;

    public StaxMapper() {
        super();
    }

    public abstract QName getInspireType();

    void initElementHandlers() {
        addElementHandler(new BeginLifespanVersionHandler());
        addElementHandler(new EndLifespanVersionHandler());
        addElementHandler(new BoundedByHandler());
    }

    abstract boolean canHandle(final QName element);

    abstract T createDomainObject();
    abstract QName getBaseElement();

    List<ValidationRule> getValidationRules() {
        return new ArrayList<>();
    }

    void readFeatureMember(final FeatureItem featureItem, final XMLEventReader eventReader, final XMLEvent event,
                           final List<Namespace> globalNamespaces, final ValidationMessageBuilder validationMessageBuilder,
                           final AanleveringCharacteristics aanleveringCharacteristics)
            throws StaxMapperException {
        final int errorCountOffset = validationMessageBuilder.getErrorCount();
        FeatureLinks featureLinks = new FeatureLinks(imklFeaturetypeProvider, getBaseElement(), getInspireType());
        try {
            T domainObject = createDomainObject();
            domainObject.setSeenElementValue(getBaseElement(), 0, true);

            ImklFeatureType imklFeatureType = imklFeaturetypeProvider.getImklFeaturetype(getBaseElement().getLocalPart());
            if (imklFeatureType != null) {
                domainObject.setFeatureType(imklFeatureType);
            }
            //noinspection unchecked
            WritingXMLEventReader writingEventReader = new WritingXMLEventReader(eventReader, globalNamespaces, inspireConvertibleElementProvider, mappedFeaturetypeProvider);
            writingEventReader.writeEventXml(event);

            initDomainObjectAndValidateElements(domainObject, featureItem, event, writingEventReader, featureLinks, validationMessageBuilder);
            validateDomainObject(domainObject, validationMessageBuilder);

            FeatureEditor.edit(domainObject);

            if (noErrorsOccurred(errorCountOffset, validationMessageBuilder)) {
                featureItem.setFeature(domainObject);
                featureItem.setFeatureLinks(featureLinks.getLinks());
                featureItem.setWionGmlObject(getWionGmlObject(domainObject));
                featureItem.setInspireGmlObject(getInspireGmlObject(domainObject));
            }
            fillAanleveringCharacteristics(aanleveringCharacteristics, domainObject);

        } catch (XMLStreamException e) {
            throw new StaxMapperException("XML Stream error ocured", e);
        } catch (XMLException e) {
            validationMessageBuilder.addXMLProcessingError(e.getMessage(), e.getGmlId());
            throw new StaxMapperException("Error occured while reading and writing XML", e);
        } catch (UncategorizedSQLException e) {
            throw new StaxMapperException("Errow while writing to the database", e);
        }
    }

    protected void fillAanleveringCharacteristics(final AanleveringCharacteristics aanleveringCharacteristics, final T domainObject) {}

    private void initDomainObjectAndValidateElements(final T domainObject, final FeatureItem featureItem, final XMLEvent event,
                                                     final WritingXMLEventReader writingEventReader, final FeatureLinks featureLinks,
                                                     final ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        domainObject.setValidationRules(getValidationRules());
        domainObject.setActualisatieId(featureItem.getActualisatieId());
        domainObject.setBronhoudercode(featureItem.getBronhoudercode());
        domainObject.setGmlId(getGmlIdFromXml(event, validationMessageBuilder));
        domainObject.setImklFeatureType(imklFeaturetypeProvider.getImklFeaturetype(getBaseElement().getLocalPart()));

        try {
            readFeatureElements(domainObject, featureLinks, event, writingEventReader, validationMessageBuilder);
        } catch (XMLException xmlEx) {
            ImklFeatureType ft = domainObject.getImklFeatureType();
            String gmlId = domainObject.getGmlId();
            LOG.error("Failed to process {} with gmlId {}", ft != null ? ft : "null", gmlId != null ? gmlId : "null");
            throw xmlEx;
        }
        initFeatureType(domainObject, validationMessageBuilder);

        domainObject.setXmlInspire(writingEventReader.getInspireXml());
        domainObject.setXmlImkl(writingEventReader.getImklXml());
    }

    void addElementHandler(final ElementHandler elementHandler) {
        elementHandlers.add(elementHandler);
    }

    private static GmlObject createGmlObjectFor(final FeatureWithValidationDomainObject feature) {
        final GmlObject gmlObject = new GmlObject();
        gmlObject.setGmlId(feature.getGmlId());
        gmlObject.setBronhoudercode(feature.getBronhoudercode());
        gmlObject.setGmlBoundedBy(BboxCreator.createBBox(feature.getGeometry()));
        gmlObject.setGeometry(feature.getGeometry());
        return gmlObject;
    }

    private static GmlObject getWionGmlObject(final FeatureWithValidationDomainObject feature) {
        GmlObject gmlObject = null;
        if(feature.getWionFeatureTypeId() != null) {
            gmlObject = createGmlObjectFor(feature);
            gmlObject.setFeatureTypeId(feature.getWionFeatureTypeId());
            String xmlImkl = feature.getXmlImkl();
            gmlObject.setBinaryObject(xmlImkl.getBytes(StandardCharsets.UTF_8));
        }

        return gmlObject;
    }

    private static String getGmlIdFromXml(final XMLEvent event, final ValidationMessageBuilder validationMessageBuilder) {
        String gmlId = null;
        Attribute gmlIdAttribute = event.asStartElement().getAttributeByName(Elements.ATTR_GML_ID);
        if (gmlIdAttribute != null) {// gml:id="NL.IMKL-NETBH.103" )
            gmlId = gmlIdAttribute.getValue();
        } else {
            validationMessageBuilder.addErrorNoGmlId(event.asStartElement().getName().toString());
        }
        return gmlId;
    }

    private void initFeatureType(final T domainObject, final ValidationMessageBuilder validationMessageBuilder) {
        if (domainObject.getInspireId() != null) {
            final boolean isInspireFeatureType = domainObject.getInspireId().getType() != null;
            if (isInspireFeatureType) {
                domainObject.wionOnly(false);
                initInspireFeatureType(domainObject, validationMessageBuilder);
            } else {
                domainObject.wionOnly(true);
            }
        }
        domainObject.setWionFeatureTypeId(wionFeatureTypeDao.findId(getBaseElement().toString()));
    }

    private void initInspireFeatureType(final T domainObject, final ValidationMessageBuilder validationMessageBuilder) {
        final String featureTypeId = toFeatureTypeIdentifier(domainObject.getInspireId().getType());
        final String baseFeatureTypeId = toFeatureTypeIdentifier(domainObject.getInspireId().getBaseType());
        domainObject.setInspireFeatureTypeId(findFeatureTypeId(featureTypeId));
        if (domainObject.getInspireFeatureTypeId() == null) {
            LOG.error("Inspire feature not found. FeatureTypeId: {}, BaseType: {}, Gml-id: {}", featureTypeId, baseFeatureTypeId, domainObject.getGmlId());
            validationMessageBuilder.addErrorTechnical();
        }
    }

    private Long findFeatureTypeId(final String featureTypeId) {
        return inspireFeatureTypeDao.findId(featureTypeId);
    }

    private static String toFeatureTypeIdentifier(final QName inspireType) {
        return "{" + inspireType.getNamespaceURI() + "}" + inspireType.getLocalPart();
    }

    /**
     * Checks if no new errors are added to the validation messages.
     *
     * @param errorCountOffset         number of errors at the beginning.
     * @param validationMessageBuilder current validationMessageBuilder.
     * @return true if the number of errors at the beginning is the same as now.
     */
    private static boolean noErrorsOccurred(final int errorCountOffset, final ValidationMessageBuilder validationMessageBuilder) {
        return errorCountOffset == validationMessageBuilder.getErrorCount();
    }

    private void readFeatureElements(final T domainObject, final FeatureLinks featureLinks, final XMLEvent startEvent,
                                     final WritingXMLEventReader writingEventReader, final ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        XMLEvent event = startEvent;
        while (StaxHelper.isNoEndElement(event, getBaseElement())) {
            if (event.isStartElement()) {
                // The feature member tag should be skipped before handling the feature member elements:
                if (!canHandle(event.asStartElement().getName())) {
                    handleElement(domainObject, featureLinks, event, writingEventReader, validationMessageBuilder);
                }
            }
            event = writingEventReader.nextEvent();
        }
    }

    @SuppressWarnings("unchecked")
    private void handleElement(final T domainObject, final FeatureLinks featureLinks, final XMLEvent event,
                               final WritingXMLEventReader writingEventReader, final ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        for (ElementHandler<DomainObject> elementHandler : elementHandlers) {
            if (elementHandler.shouldHandle(event.asStartElement())) {
                    elementHandler.handle(event.asStartElement(), featureLinks, domainObject, writingEventReader, validationMessageBuilder);
                break;
            }
        }
    }

    private void validateDomainObject(final T domainObject, final ValidationMessageBuilder validationMessageBuilder) {
        domainObjectValidator.validate(domainObject, validationMessageBuilder);
    }

    void setMappedFeaturetypeProvider(final MappedFeaturetypeProvider mappedFeaturetypeProvider) {
        this.mappedFeaturetypeProvider = mappedFeaturetypeProvider;
    }

    void setInspireConvertibleElementProvider(final InspireConvertibleElementProvider inspireConvertibleElementProvider) {
        this.inspireConvertibleElementProvider = inspireConvertibleElementProvider;
    }

    private static GmlObject getInspireGmlObject(final FeatureWithValidationDomainObject feature) {
        GmlObject gmlObject = null;
        if (!feature.isWionOnly()) {
            gmlObject = createGmlObjectFor(feature);
            gmlObject.setFeatureTypeId(feature.getInspireFeatureTypeId());
            gmlObject.setBinaryObject(feature.getXmlInspire().getBytes(StandardCharsets.UTF_8));
        }
        return gmlObject;
    }

}
