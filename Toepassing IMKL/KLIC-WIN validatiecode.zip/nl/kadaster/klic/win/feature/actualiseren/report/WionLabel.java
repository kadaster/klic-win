package nl.kadaster.klic.win.feature.actualiseren.report;

import nl.kadaster.klic.win.model.FeatureGroup;
import nl.kadaster.klic.win.model.WionThema;

public enum WionLabel implements ReportLabel {

     UTILITEITSNET("utiliteitsnet", FeatureGroup.UTILITEITSNET)
    ,KABEL_OF_LEIDING("kabelOfLeiding", FeatureGroup.KABELS_EN_LEIDINGEN)
    ,KABEL_EN_LEIDING_CONTAINER("kabelEnLeidingContainer", FeatureGroup.KABEL_EN_LEIDINGCONTAINERS)
    ,LEIDINGELEMENT("leidingelement", FeatureGroup.LEIDINGELEMENTEN)
    ,CONTAINER_LEIDINGELEMENT("containerLeidingelement", FeatureGroup.CONTAINER_LEIDINGELEMENTEN)
    ,UTILITYLINK("utilityLink", FeatureGroup.UTILITYLINK)
    
    ,BUISLEIDING_GEVAARLIJKE_INHOUD("buisleidingGevaarlijkeInhoud", WionThema.BUISLEIDINGGEVAARLIJKEINHOUD)
    ,DATATRANSPORT("datatransport", WionThema.DATATRANSPORT)
    ,GAS_HOGE_DRUK("gasHogeDruk", WionThema.GASHOGEDRUK)
    ,GAS_LAGE_DRUK("gasLageDruk", WionThema.GASLAGEDRUK)
    ,HOOGSPANNING("hoogspanning", WionThema.HOOGSPANNING)
    ,LAAGSPANNING("laagSpanning", WionThema.LAAGSPANNING)
    ,LANDELIJK_HOOGSPANNINGSNET("landelijkHoogspanningsnet", WionThema.LANDELIJKHOOGSPANNINGSNET)
    ,MIDDENSPANNING("middenSpanning", WionThema.MIDDENSPANNING)
    ,PETROCHEMIE("petrochemie", WionThema.PETROCHEMIE)
    ,RIOOL_ONDER_OF_OVERDRUK("rioolOnderOverOfOnderdruk", WionThema.RIOOLONDEROVEROFONDERDRUK)
    ,RIOOL_VRIJVERVAL("rioolVrijverval", WionThema.RIOOLVRIJVERVAL)
    ,WARMTE("warmte", WionThema.WARMTE)
    ,WATER("water", WionThema.WATER)
    ,WEES("wees", WionThema.WEES)
    ,OVERIG("overig", WionThema.OVERIG)

    ,TOREN("toren", "Toren")
    ,MAST("mast", "Mast")
    ,MANGAT("mangat", "Mangat")
    ,KAST("kast", "Kast")
    ,TECHNISCH_GEBOUW("technischGebouw", "TechnischGebouw")

    ,AANDUIDING_EIS_VOORZORGSMAATREGEL("aanduidingEisVoorzorgsmaatregel", "AanduidingEisVoorzorgsmaatregel")
    ,ANNOTATIE("annotatie", "Annotatie")
    ,DIEPTE_NAP("diepteNAP", "DiepteNAP")
    ,DIEPTE_TOV_MAAIVELD("diepteTovMaaiveld", "DiepteTovMaaiveld")
    ,EIGEN_TOPOGRAFIE("eigenTopografie", "EigenTopografie")
    ,EXTRA_DETAIL_INFO("extraDetailInfo", "ExtraDetailinfo")
    ,EXTRA_GEOMETRIE("extraGeometrie", "ExtraGeometrie")
    ,MAATVOERING("maatvoering", "Maatvoering")
    
    ,EDI_AANSLUITING("aansluiting", "aansluiting")
    ,EDI_HUISAANSLUITING("huisaansluiting", "huisaansluiting")
    ,EDI_PROFIELSCHETS("profielschets", "profielschets")
    ,EDI_VERZOEKTOTCONTACT("verzoekTotContact", "verzoekTotContact")
    ,EDI_OVERIG("overig", "overig")
    ;

    private final String displayName;
    private final String dbCode;
    
    WionLabel(final String displayName, final String dbCode) {
       this.displayName = displayName;
       this.dbCode = dbCode;
    }

    WionLabel(final String displayName, final FeatureGroup featureGroup) {
        this.displayName = displayName;
        dbCode = featureGroup.getValue();
    }
    
    WionLabel(final String displayName, final WionThema wionThema) {
        this.displayName = displayName;
        dbCode = wionThema.getValue();
     }

    @Override
    public String getDisplayName() {
       return displayName;
    }
   
    @Override
    public String getDbCode() {
       return dbCode;
    }

}
