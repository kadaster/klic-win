package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch;

import com.google.common.base.Function;
import com.google.common.base.Predicates;
import com.google.common.collect.FluentIterable;
import com.google.common.collect.Lists;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.FeatureWithValidation;
import nl.kadaster.klic.win.feature.domain.imkl2015.FeatureLink;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.GmlObject;
import nl.kadaster.klic.win.feature.domain.imkl2015.ImklFeatureType;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.domain.FeatureItem;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class BatchSupport {

    private static final Function<FeatureItem, FeatureWithValidation> TO_FEATURE_LIST = new Function<FeatureItem, FeatureWithValidation>(){
        @Override
        public FeatureWithValidation apply(FeatureItem input) {
            final FeatureWithValidation feature = input.getFeature();
            if (feature != null) {
                feature.setBronhoudercode(input.getBronhoudercode());
            }
            return feature;
        }
    };

    private static final Function<FeatureItem, List<FeatureLink>> TO_FEATURE_LINK_LIST = new Function<FeatureItem, List<FeatureLink>>(){
        @Override
        public List<FeatureLink> apply(FeatureItem input) {
            final List<FeatureLink> featureLinks = input.getFeatureLinks();
            final FeatureWithValidation feature = input.getFeature();
            if (featureLinks == null || feature == null) {
                return Collections.emptyList();
            }
            final ImklFeatureType featureType = feature.getFeatureType();
            for (FeatureLink featureLink : featureLinks) {
                featureLink.setFeatureId(feature.getId());
                featureLink.setBronhoudercode(input.getBronhoudercode());
                featureLink.setDuctOfKabelbed(featureType.isDuctOfKabelbed());
                featureLink.setKabelOfLeiding(featureType.isKabelOfLeiding());
                featureLink.setContainerleidingElement(featureType.isContainerleidingelement());
            }
            return featureLinks;
        }
    };

    // Assumes the FeatureItem has its primary key set
    private static final Function<FeatureItem, GmlObject> TO_WION_GML_OBJECT_LIST = new Function<FeatureItem, GmlObject>(){
        @Override
        public GmlObject apply(FeatureItem input) {
            GmlObject gmlObject = input.getWionGmlObject();
            if (gmlObject == null) {
                return null;
            }
            gmlObject.setFeatureId(input.getFeature().getId());
            gmlObject.setBronhoudercode(input.getBronhoudercode());
            return gmlObject;
        }
    };

    // Assumes the FeatureItems have their primary key set
    private static final Function<FeatureItem, GmlObject> TO_INSPIRE_GML_OBJECT_LIST = new Function<FeatureItem, GmlObject>(){
        @Override
        public GmlObject apply(FeatureItem input) {
            GmlObject gmlObject = input.getInspireGmlObject();
            if (gmlObject == null) {
                return null;
            }
            FeatureWithValidation feature = input.getFeature();
            if (feature != null) {
                Long featureId = feature.getId();
                gmlObject.setFeatureId(featureId);
                
            }
            gmlObject.setBronhoudercode(input.getBronhoudercode());
            return gmlObject;
        }
    };

    private BatchSupport() {
    }

    private static List<GmlObject> toGmlObjects(final List<? extends FeatureItem> featureItemList, final Function<FeatureItem, GmlObject> gmlObjectListKind) {
        return FluentIterable.from(featureItemList)
                .transform(gmlObjectListKind)
                .filter(Predicates.notNull())
                .toList();
    }

    /**
     * List is also filtered from null values because when there are validation errors the feature
     * is not present in the list (is null)
     */
    public static List<FeatureWithValidation> toFeatureList(final List<? extends FeatureItem> featureItemList) {
        return FluentIterable.from(featureItemList)
                .transform(BatchSupport.TO_FEATURE_LIST)
                .filter(Predicates.<FeatureWithValidation>notNull())
                .toList();
    }

    public static List<FeatureLink> toFeatureLinkList(final List<? extends FeatureItem> featureItemList) {
        final List<FeatureLink> featureLinkList = new ArrayList<>();
        final List<List<FeatureLink>> featureLinksList = Lists.transform(featureItemList, TO_FEATURE_LINK_LIST);
        for (List<FeatureLink> featureLinks : featureLinksList) {
            featureLinkList.addAll(featureLinks);
        }
        return featureLinkList;
    }

    public static List<GmlObject> toWionGmlObjectList(final List<? extends FeatureItem> featureItemList) {
        return toGmlObjects(featureItemList, TO_WION_GML_OBJECT_LIST);
    }

    public static List<GmlObject> toInspireGmlObjectList(final List<? extends FeatureItem> featureItemList) {
        return toGmlObjects(featureItemList, TO_INSPIRE_GML_OBJECT_LIST);
    }


}
