package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.Belanghebbende;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.stream.events.StartElement;

public class GeraaktBelangBijOrientatiepolygoonHandler extends AbstractElementHandler implements ElementHandler<Belanghebbende> {

    @Override
    public boolean shouldHandle(final StartElement element) {
        return sameQName(Elements.GERAAKT_BELANG_BIJ_ORIENTATIE_POLYGOON, element.getName());
    }

    @Override
    public void handle(final StartElement element, final FeatureLinks featureLinks, final Belanghebbende belanghebbende,
                       final StaxEventReader staxEventReader, final ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        belanghebbende.setSeenElementValue(Elements.GERAAKT_BELANG_BIJ_ORIENTATIE_POLYGOON, element.getLocation().getLineNumber(), true);
    }
}