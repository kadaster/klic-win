package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.beheerdersinformatie.BiElementHandlerFactory;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationRuleFactory;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.namespace.QName;

public class EisVoorzorgsmaatregelBijlageStaxMapper extends BijlageStaxMapper {

    public EisVoorzorgsmaatregelBijlageStaxMapper(final BiElementHandlerFactory biElementHandlerFactory,
                                                  final ValidationRuleFactory validationRuleFactory) {
        super(biElementHandlerFactory, validationRuleFactory);
    }

    @Override
    boolean canHandle(final QName element) {
        return Elements.EISVOORZORGMAATREGEL_BIJLAGE.equals(element);
    }

    @Override
    protected QName getBaseElement() {
        return Elements.EISVOORZORGMAATREGEL_BIJLAGE;
    }
}
