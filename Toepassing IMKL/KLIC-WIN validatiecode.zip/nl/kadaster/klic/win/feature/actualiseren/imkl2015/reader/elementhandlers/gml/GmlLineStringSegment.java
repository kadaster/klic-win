package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.gml;

import java.util.List;

import org.postgis.Point;

import nl.kadaster.klic.win.storage.GeometryException;

class GmlLineStringSegment implements GmlCurveSegment {

    private static final String LINE_STRING_SEGMENT_TOO_SHORT = "LineStringSegment moet minstens 2 punten bevatten";
    
    private final List<Point> points;

    GmlLineStringSegment(final List<Point> points) throws GeometryException {
        if (points.size()<=1) {
            throw new GeometryException(LINE_STRING_SEGMENT_TOO_SHORT);
        }
        this.points = points;
    }

    @Override
    public List<Point> getPoints() {
        return points;
    }

    @Override
    public Point getFirstPoint() {
        return points.get(0);
    }

    @Override
    public Point getLastPoint() {
        return points.get(points.size()-1);
    }

}
