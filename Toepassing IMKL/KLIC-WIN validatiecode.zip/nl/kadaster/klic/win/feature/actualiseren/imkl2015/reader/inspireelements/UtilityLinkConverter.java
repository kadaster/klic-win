package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.inspireelements;

import nl.kadaster.klic.win.feature.common.util.gml.Elements;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.QNameHelper;

import javax.xml.stream.XMLEventFactory;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.Namespace;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;
import java.util.List;

public class UtilityLinkConverter extends CommonFeatureMemberConverter implements InspireElementConverter {

    private final XMLEventFactory xmlEventFactory = XMLEventFactory.newInstance();

    public UtilityLinkConverter(final List<Namespace> globalNamespaces) {
        super(globalNamespaces);
    }

    @Override
    public boolean shouldHandle(final StartElement element) {
        return QNameHelper.sameQName(Elements.UTILITY_LINK, element.getName());
    }

    @Override
    public boolean shouldHandle(final EndElement element) {
        return false;
    }

    @Override
    public XMLEvent convertStartElement(final StartElement element) {
        @SuppressWarnings("unchecked")
        List<Namespace> namespaces = mergeWithGlobalNamespaces(element.getNamespaces());
        namespaces = stripImklNamespaces(namespaces.iterator());
        return xmlEventFactory.createStartElement(element.getName(), element.getAttributes(), namespaces.iterator());
    }


    @Override
    public XMLEvent convertEndElement(final EndElement element) {
        return null;
    }

}
