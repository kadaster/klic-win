package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.namespace.QName;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.XMLEvent;

abstract class AbstractElementHandler {

    AbstractElementHandler() {
        super();
    }

    boolean sameQName(final QName qName1, final QName qName2) {
        return QNameHelper.sameQName(qName1, qName2);
    }

    static String getXLink(final XMLEvent event) {
        String xLink = null;
        Attribute attributeByName = event.asStartElement().getAttributeByName(Elements.XLINK_HREF);
        if (attributeByName != null) {
            xLink = attributeByName.getValue();
        }
        return xLink;
    }

    /**
     * Returns the value of a codelist URL, so only the last part of the URL.
     * F.i. Providing the method with 'http://definities.geostandaarden.nl/imkl2015/id/waardelijst/TopografischObjectTypeValue/BuildingPart'
     * will return BuildingPart as the codelist value.
     */
    static String getCodelistValue(final String codelistValueUrl) {
        String codelistValue = codelistValueUrl;
        int lastSlash = codelistValueUrl.lastIndexOf('/');
        if (lastSlash >= 0) {
            codelistValue = codelistValueUrl.substring(lastSlash + 1);
        }
        return codelistValue;
    }
}
