package nl.kadaster.klic.win.feature.actualiseren.report;

public interface ReportLabel {

    String getDisplayName();
    String getDbCode();
}
