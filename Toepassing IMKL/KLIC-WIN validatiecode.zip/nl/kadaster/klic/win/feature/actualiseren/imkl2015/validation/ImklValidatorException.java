package nl.kadaster.klic.win.feature.actualiseren.imkl2015.validation;

public class ImklValidatorException extends Exception {

    private static final long serialVersionUID = -3404971182445786132L;

    public ImklValidatorException(final String message) {
        super(message);
    }

    public ImklValidatorException(final String message, final Throwable cause) {
        super(message, cause);
    }
}
