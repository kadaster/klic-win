package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import nl.kadaster.klic.win.feature.domain.imkl2015.FeatureLink;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.storage.FeatureLinkDao;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class FeatureLinkWriter {

    private static final Logger LOG = LoggerFactory.getLogger(FeatureLinkWriter.class);

    @Autowired
    private FeatureLinkDao featureLinkDao;

    private boolean doInNetworkValidation;

    public void finishFeatureLinks(final String bronhoudercode, final ValidationMessageBuilder validationMessageBuilder) {
        LOG.info("Updating features, setting it's themes");
        featureLinkDao.updateMissingFeatureThemes(bronhoudercode);
        LOG.info("Updating features, setting linked feature id's");
        featureLinkDao.updateWithLinkedFeatureIds(bronhoudercode);
        if(doInNetworkValidation) {
            validateOnLinksToMissingFeatures(bronhoudercode, validationMessageBuilder);
        }
        LOG.info("Removing references to unknown features");
        featureLinkDao.deleteWhereMissingLinkedFeatureIds(bronhoudercode);
    }

    private void validateOnLinksToMissingFeatures(final String bronhoudercode, final ValidationMessageBuilder validationMessageBuilder) {
        List<FeatureLink> featureLinks = featureLinkDao.getWhereMissingLinkedFeatureIds(bronhoudercode);
        for (FeatureLink featurelink: featureLinks) {
            validationMessageBuilder.addErrorUnknownLinkedFeature(featurelink.getGmlidFeaturemember(), featurelink.getGmlidLinkedFeaturemember());
        }
    }

    public void setDoInNetworkValidation(final boolean doInNetworkValidation) {
        this.doInNetworkValidation = doInNetworkValidation;
    }
}
