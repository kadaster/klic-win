package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.FeatureWithValidationDomainObject;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.domain.DomainObject;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.stream.events.StartElement;

public class InNetworkNetworkHandler extends AbstractElementHandler implements ElementHandler<DomainObject> {

    private static final String IMKL_FEATURETYPE_NAME = "Utiliteitsnet";

    @Override
    public boolean shouldHandle(StartElement element) {
        return sameQName(Elements.INNETWORK_NETWORK, element.getName());
    }

    @Override
    public void handle(StartElement element, FeatureLinks featureLinks, DomainObject domainObject, StaxEventReader staxEventReader, ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        if (domainObject instanceof FeatureWithValidationDomainObject) {
            FeatureWithValidationDomainObject feature = (FeatureWithValidationDomainObject) domainObject;
            String xlink = getXLink(element);
            if (xlink != null) {
                featureLinks.addFeatureLink(xlink, feature, IMKL_FEATURETYPE_NAME);
            } else {
                String gmlId = feature.getGmlId();
                validationMessageBuilder.addErrorImklElementMandatory(gmlId, element.getName().getLocalPart());
            }
        }
    }

}
