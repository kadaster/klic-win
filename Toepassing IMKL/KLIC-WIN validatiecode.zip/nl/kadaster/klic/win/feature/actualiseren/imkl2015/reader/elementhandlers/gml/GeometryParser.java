package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.gml;

import java.util.HashMap;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.stream.events.XMLEvent;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.FeatureWithValidationDomainObject;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.storage.GeometryException;

public final class GeometryParser {
    
    private static final Logger LOG = LoggerFactory.getLogger(GeometryParser.class);
    
    private static final Map<QName, Handler> START_TAG_HANDLERS = new HashMap<>(); 
    private static final Map<QName, Handler> END_TAG_HANDLERS = new HashMap<>();
    
    static {
        initStartTagHandlers();
        initEndTagHandlers();
    }

    private GeometryParser() {
    }

    private static void initStartTagHandlers() {
        
        START_TAG_HANDLERS.put(Elements.GML_CURVE, new Handler() {
            
            @Override
            public void handle(GmlGeometryBuilder gBld) {
                gBld.startCurveTag();
             } 
        });
        
        START_TAG_HANDLERS.put(Elements.GML_ARC, new Handler() {
            
            @Override
            public void handle(GmlGeometryBuilder gBld) throws GeometryException {
                GmlGeometryBuilder.startArcTag();
             } 
        });
        
        START_TAG_HANDLERS.put(Elements.GML_CIRCLE, new Handler() {
            
            @Override
            public void handle(GmlGeometryBuilder gBld) throws GeometryException {
                GmlGeometryBuilder.startCircleTag();
             } 
        });
        
        START_TAG_HANDLERS.put(Elements.GML_CIRCLE_BY_CENTER_POINT, new Handler() {
            
            @Override
            public void handle(GmlGeometryBuilder gBld) throws GeometryException {
                GmlGeometryBuilder.startCircleByCenterPointTag();
             } 
        });

        START_TAG_HANDLERS.put(Elements.GML_POLYGON, new Handler() {
            
            @Override
            public void handle(GmlGeometryBuilder gBld) {
                gBld.startPolygonTag();
             } 
        });
        
        START_TAG_HANDLERS.put(Elements.GML_EXTERIOR, new Handler() {
            
            @Override
            public void handle(GmlGeometryBuilder gBld) {
                gBld.startExteriorTag();
             } 
        });
        
        START_TAG_HANDLERS.put(Elements.GML_INTERIOR, new Handler() {
            
            @Override
            public void handle(GmlGeometryBuilder gBld) {
                gBld.startInteriorTag();
             } 
        });
    }
    
    private static void initEndTagHandlers() {
        
        END_TAG_HANDLERS.put(Elements.GML_POINT, new Handler() { 
            
            @Override
            public void handle(GmlGeometryBuilder gBld) throws GeometryException {
                gBld.endPointTag();
             } 
        });
        
        END_TAG_HANDLERS.put(Elements.GML_LINESTRING, new Handler() {
            
            @Override
            public void handle(GmlGeometryBuilder gBld) throws GeometryException {
                gBld.endLineStringTag();
             } 
        });
        
        END_TAG_HANDLERS.put(Elements.GML_CURVE, new Handler() {
            
            @Override
            public void handle(GmlGeometryBuilder gBld) throws GeometryException {
                gBld.endCurveTag();
             } 
        });
        
        END_TAG_HANDLERS.put(Elements.GML_LINESTRING_SEGMENT, new Handler() {
            
            @Override
            public void handle(GmlGeometryBuilder gBld) throws GeometryException {
                gBld.endLineStringSegmentTag();
             } 
        });
        
        END_TAG_HANDLERS.put(Elements.GML_POLYGON, new Handler() {
            
            @Override
            public void handle(GmlGeometryBuilder gBld) {
                gBld.endPolygonTag();
             } 
        });
        
        END_TAG_HANDLERS.put(Elements.GML_LINEAR_RING, new Handler() {
            
            @Override
            public void handle(GmlGeometryBuilder gBld) throws GeometryException {
                gBld.endLinearRingTag();
             } 
        });
    }
    
    public static GmlGeometry parse(final QName geometryElement, final FeatureWithValidationDomainObject featureDomainObject, final StaxEventReader staxEventReader, final ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        GmlGeometryBuilder gBld = new GmlGeometryBuilder();
        GmlGeometry gmlGeometry = null;
        XMLEvent event;
        boolean done = false;
        boolean firstElement = true;
        try {
            while ((event = staxEventReader.nextEvent()) != null && !done) {
                QName qName;
                switch (event.getEventType()) {
                case XMLEvent.CHARACTERS: 
                        gBld.charData(event.asCharacters().getData());
                        break;
                case XMLEvent.START_ELEMENT:
                        gBld.clearCharData();
                        qName = event.asStartElement().getName();
                        handleStartElement(gBld, qName, firstElement);
                        firstElement = false;
                    break;
                case XMLEvent.END_ELEMENT:
                    done = handleEndElement(geometryElement, gBld, event);
                    break;
                default: // DO NOTHING
                }
        }
        gmlGeometry = gBld.build();
        } catch (GeometryException e) {
            LOG.warn("Encountered invalid geometry", e);
            validationMessageBuilder.addErrorInvalidGeometryExactLineNr(featureDomainObject.getGmlId(), e.getMessage());
        }
        return gmlGeometry;
    }

    private static boolean handleEndElement(final QName geometryElement, final GmlGeometryBuilder gBld, final XMLEvent event) throws GeometryException {
        boolean done = false;
        final QName qName;
        qName = event.asEndElement().getName();
        if (geometryElement.equals(qName)) {
            done = true;
        } else {
            handleEndElement(gBld, qName);
        }
        return done;
    }

    private static void handleStartElement(final GmlGeometryBuilder gBld, final QName qName, final boolean firstElement) throws GeometryException {
        Handler handler = START_TAG_HANDLERS.get(qName);
        if (handler != null) {
            handler.handle(gBld);
        } else {
            if (firstElement && END_TAG_HANDLERS.get(qName) == null) {
                throw new GeometryException("Geometry type " + qName.getLocalPart() + " wordt niet ondersteund");
            }
        }
    }
    
    private static void handleEndElement(final GmlGeometryBuilder gBld, final QName qName) throws GeometryException {
        Handler handler = END_TAG_HANDLERS.get(qName);
        if (handler != null) {
            handler.handle(gBld);
        }
    }
    
    private interface Handler {
        void handle(GmlGeometryBuilder gBld) throws GeometryException;
    }
    
}
