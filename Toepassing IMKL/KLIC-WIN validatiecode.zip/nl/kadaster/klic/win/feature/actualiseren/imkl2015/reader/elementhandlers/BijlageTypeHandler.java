package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.Bijlage;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.namespace.QName;

public class BijlageTypeHandler extends AbstractCodelistElementHandler<Bijlage> {

    private static final String CODELIST_NAME_IMKL = "BijlageTypeValue";

    @Override
    protected QName getHandlingElement() {
        return Elements.BIJLAGETYPE;
    }

    @Override
    protected void preValidate() {
        setCodelist(CODELIST_NAME_IMKL);
    }

    @Override
    protected void postValidate(final Bijlage bijlage, final String xLinkCodelistValue) {
        String bijlageType = getCodelistValue(xLinkCodelistValue);
        bijlage.setBijlageType(bijlageType);
        bijlage.setType(bijlageType);
    }

}
