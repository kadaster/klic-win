package nl.kadaster.klic.win.feature.actualiseren.imkl2015.validation;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.FeatureWithValidationDomainObject;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.GmlId;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.LocalId;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;

public class GmlIdContainingBronhouderCodeValidatorImpl implements GmlIdContainingBronhouderCodeValidator {

    @Override
    public boolean validateGmlId(final FeatureWithValidationDomainObject domainObj, final ValidationMessageBuilder validationMessageBuilder) {
        final GmlId gmlId = new GmlId(domainObj.getGmlId());
        final LocalId localId = gmlId.getLocalId();
        boolean valid = localId != null && localId.isValid() && localId.getBronhouderCode().equals(domainObj.getBronhoudercode());
        if (!valid) {
            validationMessageBuilder.addErrorVerkeerdeNamespace(domainObj.getGmlId());
        }
        return valid;
    }

}
