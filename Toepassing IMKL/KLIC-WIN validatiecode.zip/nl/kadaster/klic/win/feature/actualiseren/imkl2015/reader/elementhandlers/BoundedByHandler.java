package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.FeatureWithValidation;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxHelper;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.stream.events.StartElement;

import static nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.QNameHelper.sameQName;

public class BoundedByHandler implements ElementHandler<FeatureWithValidation> {

    @Override
    public boolean shouldHandle(StartElement element) {
        return sameQName(Elements.BOUNDED_BY, element.getName());
    }

    @Override
    public void handle(StartElement element, FeatureLinks featureLinks, FeatureWithValidation feature, StaxEventReader staxEventReader, ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        // A 'boundedBy' element inside a feature member is not allowed, so allways add an error
        final String gmlId = feature.getGmlId();
        final String elementName = StaxHelper.getQName(element);
        validationMessageBuilder.addErrorImklElementNotAllowed(gmlId, elementName);
    }
}
