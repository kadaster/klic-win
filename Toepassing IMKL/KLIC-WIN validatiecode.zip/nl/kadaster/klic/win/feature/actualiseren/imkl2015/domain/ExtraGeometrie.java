package nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain;

import org.postgis.PGgeometry;

/**
 * For now, we only support vlakGeometrie2D and not the other types defined in the IMKL2015 XSD.
 * Reason for this is that no netbeheerder has 3D and he/she can deliver the Z-value in other
 * attributes of the feature, like diepteTovMaaiveld
 *
 * Geometry not supported:
 * 1. puntGeometry2.5D
 * 2. lijnGeometry2.5D
 * 3. vlakGeometry2.5D
 * 4. geometry3D
 */
public class ExtraGeometrie extends ImklFeatureWithValidationDomainObject {

    public PGgeometry getVlakGeometrie2D() {
        return getGeometry();
    }

    public void setVlakGeometrie2D(final PGgeometry vlakGeometrie2D) {
        setGeometry(vlakGeometrie2D);  // used by wion_gml_objects
    }
}
