package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import javax.xml.namespace.QName;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.KabelOfLeiding;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

public class TelecommunicationsCableMaterialTypeHandler extends AbstractCodelistElementHandler<KabelOfLeiding> {

    private static final String CODELIST_NAME_IMKL = "TelecommunicationsCableMaterialTypeIMKLValue";

    @Override
    protected QName getHandlingElement() {
        return Elements.INSPIRE_TELECOMMUNICATIONS_CABLE_MATERIAL_TYPE;
    }

    @Override
    protected void preValidate() {
        setCodelist(CODELIST_NAME_IMKL);
    }

    @Override
    protected void postValidate(final KabelOfLeiding kabelOfLeiding, final String xLinkCodelistValue) {
        kabelOfLeiding.setTelecommunicationCableMaterial(xLinkCodelistValue);
    }
}