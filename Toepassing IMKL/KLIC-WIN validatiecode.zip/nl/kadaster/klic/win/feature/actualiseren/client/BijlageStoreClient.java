package nl.kadaster.klic.win.feature.actualiseren.client;

public interface BijlageStoreClient {

    boolean checkIfFileExist(final String fileIdentificator);

}
