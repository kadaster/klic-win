package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.gml;

import java.util.List;
import java.util.regex.Pattern;

import org.postgis.Point;

import nl.kadaster.klic.win.storage.DatabaseHelper;
import nl.kadaster.klic.win.storage.GeometryException;

class GmlGeometryBuilder {

    private static final String ARC_NOT_SUPPORTED = "Geometry type Arc wordt niet ondersteund";
    private static final String CIRCLE_NOT_SUPPORTED = "Geometry type Circle wordt niet ondersteund";
    private static final String CIRCLE_BY_CENTER_POINT_NOT_SUPPORTED = "Geometry type CircleByCenterPoint wordt niet ondersteund";

    private static final Pattern PATTERN_CARRIAGE_RETURN_LINEFEED = Pattern.compile("(\\r\\n|\\n)");
    private static final String SPACE = " ";

    private StringBuilder characterData = new StringBuilder();
    private GmlGeometry gmlGeometry;
    private GmlCurve gmlCurve;
    private GmlPolygon gmlPolygon;
    
    void charData(final String charData) {
        characterData.append(cleanString(charData));
    }

    void clearCharData() {
        characterData = new StringBuilder(); 
    }
    
    void startCurveTag() {
        gmlCurve = new GmlCurve();
    }
    
    static void startArcTag() throws GeometryException {
        throw new GeometryException(ARC_NOT_SUPPORTED);
    }
    
    static void startCircleTag() throws GeometryException {
        throw new GeometryException(CIRCLE_NOT_SUPPORTED);
    }
    
    static void startCircleByCenterPointTag() throws GeometryException {
        throw new GeometryException(CIRCLE_BY_CENTER_POINT_NOT_SUPPORTED);
    }
    
    void startPolygonTag() {
        gmlPolygon = new GmlPolygon();
    }
    
    void startExteriorTag() {
        gmlPolygon.startExteriorTag();
    }
    
    void startInteriorTag() {
        gmlPolygon.startInteriorTag();
    }
    
    void endPointTag() throws GeometryException {
        Point point  = DatabaseHelper.getPoint(characterData.toString());
        gmlGeometry = new GmlPoint(point);
    }
    
    void endLineStringTag() throws GeometryException {
        List<Point> points = DatabaseHelper.getPoints(characterData.toString());
        gmlGeometry = new GmlLineString(points);
    }
    
    void endCurveTag() throws GeometryException {
        gmlCurve.endCurveTag();
        gmlGeometry = gmlCurve;
    }
    
    void endLinearRingTag() throws GeometryException {
        List<Point> points = DatabaseHelper.getPoints(characterData.toString());
        gmlPolygon.add( new GmlLinearRing(points) );
    }
    
    void endLineStringSegmentTag() throws GeometryException {
       List<Point> points = DatabaseHelper.getPoints(characterData.toString());
       gmlCurve.add( new GmlLineStringSegment(points) );
    }
    
    void endPolygonTag() {
        gmlGeometry = gmlPolygon;
    }
    
    public GmlGeometry build() {
        return gmlGeometry;
    }

    private static String cleanString(final String charData) {
        return PATTERN_CARRIAGE_RETURN_LINEFEED.matcher(charData).replaceAll(SPACE);
    }
    
}
