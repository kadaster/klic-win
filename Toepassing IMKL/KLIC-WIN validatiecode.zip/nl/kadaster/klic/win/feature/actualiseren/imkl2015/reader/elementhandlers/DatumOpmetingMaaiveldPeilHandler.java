package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.Diepte;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxHelper;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;
import org.joda.time.DateTime;

import javax.xml.stream.events.StartElement;

public class DatumOpmetingMaaiveldPeilHandler extends AbstractElementHandler implements ElementHandler<Diepte> {

    @Override
    public boolean shouldHandle(final StartElement element) {
        return sameQName(Elements.DATUM_OPMETING_MAAIVELD_PEIL, element.getName());
    }

    @Override
    public void handle(final StartElement element, final FeatureLinks featureLinks, final Diepte diepte, final StaxEventReader staxEventReader, final ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        final DateTime datum = StaxHelper.readDate(staxEventReader);
        diepte.getMaaiveldPeil().setDatumOpmeting(datum);
    }
}
