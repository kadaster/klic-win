package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;

import javax.xml.stream.events.XMLEvent;

public interface StaxEventReader {
    XMLEvent nextEvent() throws XMLException;
}
