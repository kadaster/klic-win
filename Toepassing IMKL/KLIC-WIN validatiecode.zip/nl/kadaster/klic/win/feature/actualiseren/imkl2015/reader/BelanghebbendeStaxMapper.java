package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.Belanghebbende;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.ValidationRule;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.BeginLifespanVersionHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.BeheerderLinkHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.BeheerdersinformatieGeleverdHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.BelanghebbendeEisVoorzorgsmaatregelHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.BetrokkenBijAanvraagHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.BijlageLinkHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.EigenTopografieLinkHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.GeraaktBelangBijGraafpolygoonHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.GeraaktBelangBijInformatiepolygoonHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.GeraaktBelangBijOrientatiepolygoonHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.ImklIdentificatieHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.UtiliteitsnetLinkHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.AanleveringCharacteristics;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.namespace.QName;
import java.util.List;

public class BelanghebbendeStaxMapper extends StaxMapper<Belanghebbende> {

    @Override
    void initElementHandlers() {
        super.initElementHandlers();

        addElementHandler(new ImklIdentificatieHandler());
        addElementHandler(new BeginLifespanVersionHandler());
        addElementHandler(new BetrokkenBijAanvraagHandler());
        addElementHandler(new BelanghebbendeEisVoorzorgsmaatregelHandler());
        addElementHandler(new BeheerdersinformatieGeleverdHandler());
        addElementHandler(new GeraaktBelangBijGraafpolygoonHandler());
        addElementHandler(new GeraaktBelangBijInformatiepolygoonHandler());
        addElementHandler(new GeraaktBelangBijOrientatiepolygoonHandler());

        // associations
        addElementHandler(new BeheerderLinkHandler());
        addElementHandler(new EigenTopografieLinkHandler());
        addElementHandler(new BijlageLinkHandler());
        addElementHandler(new UtiliteitsnetLinkHandler());
    }

    @Override
    boolean canHandle(final QName element) {
        return Elements.BELANGHEBBENDE.equals(element);
    }

    @Override
    public QName getInspireType() {
        return null;
    }

    @Override
    protected Belanghebbende createDomainObject() {
        return new Belanghebbende();
    }

    @Override
    List<ValidationRule> getValidationRules() {
        final List<ValidationRule> validationRules = super.getValidationRules();
        validationRules.add(new ValidationRule(Elements.BETROKKEN_BIJ_AANVRAAG).withImklStrictlyMandatory());
        validationRules.add(new ValidationRule(Elements.EISVOORZORGMAATREGEL).withImklStrictlyMandatory());
        validationRules.add(new ValidationRule(Elements.BEHEERDERSINFORMATIE_GELEVERD).withImklStrictlyProhibited());
        validationRules.add(new ValidationRule(Elements.GERAAKT_BELANG_BIJ_GRAAF_POLYGOON).withImklStrictlyProhibited());
        validationRules.add(new ValidationRule(Elements.GERAAKT_BELANG_BIJ_INFORMATIE_POLYGOON).withImklStrictlyProhibited());
        validationRules.add(new ValidationRule(Elements.GERAAKT_BELANG_BIJ_ORIENTATIE_POLYGOON).withImklStrictlyProhibited());
        return validationRules;
    }

    @Override
    protected QName getBaseElement() {
        return Elements.BELANGHEBBENDE;
    }

    @Override
    protected void fillAanleveringCharacteristics(final AanleveringCharacteristics aanleveringCharacteristics, final Belanghebbende belanghebbende) {
        aanleveringCharacteristics.setBelanghebbendeHasEisVoorzorgsmaatregel(belanghebbende.isEisVoorzorgsmaatregel());
        aanleveringCharacteristics.setBetrokken(belanghebbende.isBetrokkenBijAanvraag());
        aanleveringCharacteristics.setHasUtiliteitsnet(belanghebbende.getUtiliteitsnet() != null);
    }
}
