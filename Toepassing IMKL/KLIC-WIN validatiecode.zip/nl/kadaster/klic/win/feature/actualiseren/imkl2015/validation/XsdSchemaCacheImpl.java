package nl.kadaster.klic.win.feature.actualiseren.imkl2015.validation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.Cacheable;
import org.xml.sax.SAXException;

import javax.xml.XMLConstants;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

public class XsdSchemaCacheImpl implements XsdSchemaCache {

    private static final Logger LOG = LoggerFactory.getLogger(ImklValidator.class);
    private static final SchemaFactory SCHEMA_FACTORY = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);

    @Override
    @Cacheable(value="xsds")
    public Schema getXsdSchema(final String xsd) {
        try {
            LOG.info("Loading XSD {} and putting it into the cache", xsd);
            final Schema schema = loadXsds(xsd);
            LOG.info("Done. XSD loaded into the cache");
            return schema;
        } catch (SAXException e) {
            LOG.error("Unable to load the XSDs", e);
        }
        return null;
    }


    private Schema loadXsds(final String xsd) throws SAXException {
        // look for XSD files in local package instead of the interwebs
        SCHEMA_FACTORY.setResourceResolver(new ResourceResolver());
        return SCHEMA_FACTORY.newSchema(getClass().getResource(xsd));
    }
}
