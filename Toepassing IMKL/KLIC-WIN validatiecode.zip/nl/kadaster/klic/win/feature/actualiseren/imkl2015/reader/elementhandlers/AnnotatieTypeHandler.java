package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.Annotatie;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.namespace.QName;

public class AnnotatieTypeHandler extends AbstractCodelistElementHandler<Annotatie> {

    private static final String CODELIST_NAME_IMKL = "AnnotatieTypeValue";

    @Override
    protected QName getHandlingElement() {
        return Elements.ANNOTATIETYPE;
    }

    @Override
    protected void preValidate() {
        setCodelist(CODELIST_NAME_IMKL);
    }

    @Override
    protected void postValidate(final Annotatie annotatie, final String xLinkCodelistValue) {
        annotatie.setType(getCodelistValue(xLinkCodelistValue));
    }
}
