package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.inspireelements;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.IteratorUtils;
import org.apache.commons.collections4.PredicateUtils;

import javax.xml.stream.events.Namespace;
import java.util.Iterator;
import java.util.List;

class CommonFeatureMemberConverter {

    private final List<Namespace> globalNamespaces;

    CommonFeatureMemberConverter(final List<Namespace> globalNamespaces) {
        this.globalNamespaces = globalNamespaces;
    }

    List<Namespace> mergeWithGlobalNamespaces(final Iterator<Namespace> namespaces) {
        final List<Namespace> mergedList = IteratorUtils.toList(namespaces);
        for (final Namespace globalNamespace : globalNamespaces) {
            if (!CollectionUtils.exists(mergedList, Predicates.namespacePrefixEquality(globalNamespace))) {
                mergedList.add(globalNamespace);
            }
        }
        return mergedList;
    }

    static List<Namespace> stripImklNamespaces(final Iterator<Namespace> namespaceIterator) {
        List<Namespace> filteredNamespaces = IteratorUtils.toList(namespaceIterator);
        CollectionUtils.filter(filteredNamespaces, PredicateUtils.notPredicate(Predicates.namespaceImkl()));
        return filteredNamespaces;
    }

}
