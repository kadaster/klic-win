package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.FeatureWithValidationDomainObject;
import nl.kadaster.klic.win.feature.domain.imkl2015.ImklFeatureType;
import nl.kadaster.klic.win.production.wion.service.Placeholders;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class FeatureEditor {

    private static final Logger LOG = LoggerFactory.getLogger(FeatureEditor.class);

    private FeatureEditor() {
    }

    static void edit(final FeatureWithValidationDomainObject feature) {
        if (ImklFeatureType.EXTRA_DETAILINFO == feature.getImklFeatureType()) {
            final String xmlImkl = ExtraDetailInfoEditor.edit(feature.getXmlImkl(), feature.getBronhoudercode(), feature.getBestandIdentificator());
            if (xmlImkl != null) {
                feature.setXmlImkl(xmlImkl);
            }
        }
    }

    private static final class ExtraDetailInfoEditor {

        private static final String URI_RELATIVE_PATH_PREFIX = "file://" + Placeholders.BIJLAGEN_FOLDER + "/";
        private static final String NAMESPACE = "nl.imkl-";
        private static final String FILE_EXTENSION = ".pdf";
        private static final String PATTERN = "<([^:]*)(?:(:bestandLocatie)(></[^:]*:bestandLocatie>|/>))";

        private ExtraDetailInfoEditor() {
        }

        static String edit(final String xmlImkl, final String bronhoudercode, final String bestandIdentificator) {

            if (StringUtils.isEmpty(xmlImkl) || StringUtils.isEmpty(bronhoudercode) || StringUtils.isEmpty(bestandIdentificator)) {
                LOG.error("Invalid params, skip editing. Params: bronhoudercode: {}, bestandIdentificator: {}, xmlImkl: {}",
                        bronhoudercode, bestandIdentificator, xmlImkl);
                return null;
            }

            String replacedXml = xmlImkl;

            final String fileName = bestandIdentificator.replace(NAMESPACE + bronhoudercode + ".", "") + FILE_EXTENSION;
            final String bestandLocatieURI = URI_RELATIVE_PATH_PREFIX + fileName;

            final Pattern pattern = Pattern.compile(PATTERN);
            final Matcher matcher = pattern.matcher(xmlImkl);
            if (matcher.find()) {
                final String namespacePrefix = matcher.group(1);
                final String tagName = matcher.group(2);
                final String bestandLocatieTag = namespacePrefix + tagName;

                final String replacement = "<" + bestandLocatieTag + ">" + bestandLocatieURI + "</" + bestandLocatieTag + ">";
                replacedXml = xmlImkl.replace("<" + bestandLocatieTag + matcher.group(3), replacement);
            }

            return replacedXml;
        }
    }
}
