package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.FeatureWithValidation;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.featurelinks.FeatureLinks;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxEventReader;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.util.StaxHelper;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.exception.XMLException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.stream.events.StartElement;

public class RotatiehoekHandler extends AbstractElementHandler implements ElementHandler<FeatureWithValidation> {

    private static final String MSG_BOUNDS = "Bereik (minimale/maximale waarden): [-180.0, +180.0]";
    private static final String MSG_SCALE = "Decimale precisie: 1 (= 1 cijfer achter de komma, ofwel 1/10 booggraad)";

    @Override
    public boolean shouldHandle(final StartElement element) {
        return sameQName(Elements.ROTATIEHOEK, element.getName());
    }

    @Override
    public void handle(final StartElement element, final FeatureLinks featureLinks, final FeatureWithValidation feature, final StaxEventReader staxEventReader, final ValidationMessageBuilder validationMessageBuilder) throws XMLException {
        final String rotatiehoek = StaxHelper.readElementData(staxEventReader);
        final boolean hasValidScale = hasValidScale(element, feature, validationMessageBuilder, rotatiehoek);
        final boolean withinBounds = isWithinBounds(element, feature, validationMessageBuilder, rotatiehoek);
        if (hasValidScale && withinBounds) {
            feature.setRotatiehoek(rotatiehoek);
        }
    }

    private boolean isWithinBounds(final StartElement element, final FeatureWithValidation feature, final ValidationMessageBuilder validationMessageBuilder, final String rotatiehoek) {
        // No need to catch NumberFormatException, because the XSD only allows doubles
        final Double rotatieHoekDouble = Double.parseDouble(rotatiehoek);
        if (rotatieHoekDouble.compareTo(180D) > 0 || rotatieHoekDouble.compareTo(-180D) < 0) {
            final String elementName = StaxHelper.getQName(element);
            final String gmlId = feature.getGmlId();
            validationMessageBuilder.addErrorInvalidRotatiehoek(gmlId, elementName, MSG_BOUNDS);
            return false;
        }
        return true;
    }

    private boolean hasValidScale(final StartElement element, final FeatureWithValidation feature, final ValidationMessageBuilder validationMessageBuilder, final String rotatiehoek) {
        final int indexOfDecimalPoint = rotatiehoek.lastIndexOf('.');
        if (indexOfDecimalPoint != -1 && indexOfDecimalPoint < rotatiehoek.length() - 2) {
            final String elementName = StaxHelper.getQName(element);
            final String gmlId = feature.getGmlId();
            validationMessageBuilder.addErrorInvalidRotatiehoek(gmlId, elementName, MSG_SCALE);
            return false;
        }
        return true;
    }

}
