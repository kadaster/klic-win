package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.gml;

import java.util.List;

import org.postgis.Point;

interface GmlCurveSegment {

    List<Point> getPoints();
    Point getFirstPoint();
    Point getLastPoint();

}
