package nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain;

public class Maatvoering extends ExtraInformatie implements Aangrijping, Rotatiehoek {

}
