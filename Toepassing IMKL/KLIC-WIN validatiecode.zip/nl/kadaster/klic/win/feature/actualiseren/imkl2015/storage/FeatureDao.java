package nl.kadaster.klic.win.feature.actualiseren.imkl2015.storage;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.FeatureWithValidation;

import java.sql.BatchUpdateException;
import java.util.List;
import java.util.Map;

public interface FeatureDao {

    /**
     * Stores the given feature list batch wise
     * @param features A list of features to store
     * @throws BatchUpdateException When the batched update failes
     */
    void storeBatch(final List<FeatureWithValidation> features) throws BatchUpdateException;

    /**
     * Returns the IMKL themes belonging to a certain netbeheerder's bronhoudercode and
     * WKT (Well Known Text) geometry area
     * @param bronhoudercode The bronhoudercode of the netbeheerder
     * @param wktArea The WKT geometry area
     * @return A list with IMKL themes or when no themes are found an empty list
     */
    List<String> getImklThemesByNetbeheerderAndArea(final String bronhoudercode, final String wktArea);

    List<String> getFeaturesWithIncorrectAppurtenanceType(final String bronhoudercode);

    Map<String, String> getGeometryErrors(String bronhoudercode);

}
