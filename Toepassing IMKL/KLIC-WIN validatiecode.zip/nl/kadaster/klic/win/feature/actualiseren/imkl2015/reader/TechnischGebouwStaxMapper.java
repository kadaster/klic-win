package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader;

import javax.xml.namespace.QName;

import nl.kadaster.klic.win.feature.common.util.gml.Elements;

public class TechnischGebouwStaxMapper extends AbstractContainerLeidingElementStaxMapper {

    @Override
    boolean canHandle(final QName element) {
        return Elements.TECHNISCH_GEBOUW.equals(element);
    }

    @Override
    public QName getInspireType() {
        return Elements.INSPIRE_CABINET; // TechnischGebouw is mapped to INSPIRE Cabinet
    }

    @Override
    protected QName getBaseElement() {
        return Elements.TECHNISCH_GEBOUW;
    }

}
