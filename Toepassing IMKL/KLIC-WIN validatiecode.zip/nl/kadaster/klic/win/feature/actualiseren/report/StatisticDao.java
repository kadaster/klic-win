package nl.kadaster.klic.win.feature.actualiseren.report;

public interface StatisticDao {

    void loadRawStatistics(String bronhoudercode);
    
    int countByGroepAndWionThema(String groep, String thema);

    int countByGroepAndInspireThema(String groep, String thema);
    
    int countByFeaturetypeAndType(String featuretype, String type);

    int countByFeaturetype(String featuretype);

}