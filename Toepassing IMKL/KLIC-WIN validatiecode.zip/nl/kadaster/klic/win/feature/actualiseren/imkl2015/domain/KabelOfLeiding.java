package nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain;

import java.util.ArrayList;
import java.util.List;

public class KabelOfLeiding extends ImklFeatureWithValidationDomainObject {

    private String utilityDeliveryType;
    private String warningType;
    private String currentStatus;
    private String verticalPosition;
    private String utilityFacilityReference;
    private String governmentalServiceReference;
    private Integer kabeldiameter;
    private Double operatingVoltage;
    private Double nominalVoltage;
    private String telecommunicationCableMaterial;
    private String waterType;
    private String oilGasChemicalsProductType;
    private String sewerWaterType;
    private String thermalProductType;
    private String utiliteitsnetInspireId;
    private List<String> utilityLinkInspireIds = new ArrayList<>();

    public KabelOfLeiding() {
        super();
    }

    public String getUtilityDeliveryType() {
        return utilityDeliveryType;
    }

    public void setUtilityDeliveryType(String utilityDeliveryType) {
        this.utilityDeliveryType = utilityDeliveryType;
    }

    public String getWarningType() {
        return warningType;
    }

    public void setWarningType(String warningType) {
        this.warningType = warningType;
    }

    @Override
    public String getCurrentStatus() {
        return currentStatus;
    }

    @Override
    public void setCurrentStatus(String currentStatus) {
        this.currentStatus = currentStatus;
    }

    @Override
    public String getUtilityFacilityReference() {
        return utilityFacilityReference;
    }

    @Override
    public void setUtilityFacilityReference(String utilityFacilityReference) {
        this.utilityFacilityReference = utilityFacilityReference;
    }

    public String getGovernmentalServiceReference() {
        return governmentalServiceReference;
    }

    public void setGovernmentalServiceReference(String governmentalServiceReference) {
        this.governmentalServiceReference = governmentalServiceReference;
    }

    public Integer getKabeldiameter() {
        return kabeldiameter;
    }

    public void setKabeldiameter(Integer kabeldiameter) {
        this.kabeldiameter = kabeldiameter;
    }

    public Double getOperatingVoltage() {
        return operatingVoltage;
    }

    public void setOperatingVoltage(Double operatingVoltage) {
        this.operatingVoltage = operatingVoltage;
    }

    public Double getNominalVoltage() {
        return nominalVoltage;
    }

    public void setNominalVoltage(Double nominalVoltage) {
        this.nominalVoltage = nominalVoltage;
    }

    public String getTelecommunicationCableMaterial() {
        return telecommunicationCableMaterial;
    }

    public void setTelecommunicationCableMaterial(String telecommunicationCableMaterial) {
        this.telecommunicationCableMaterial = telecommunicationCableMaterial;
    }

    public String getWaterType() {
        return waterType;
    }

    public void setWaterType(String waterType) {
        this.waterType = waterType;
    }

    public String getOilGasChemicalsProductType() {
        return oilGasChemicalsProductType;
    }

    public void setOilGasChemicalsProductType(String oilGasChemicalsProductType) {
        this.oilGasChemicalsProductType = oilGasChemicalsProductType;
    }

    public String getSewerWaterType() {
        return sewerWaterType;
    }

    public void setSewerWaterType(String sewerWaterType) {
        this.sewerWaterType = sewerWaterType;
    }

    public String getThermalProductType() {
        return thermalProductType;
    }

    public void setThermalProductType(String thermalProductType) {
        this.thermalProductType = thermalProductType;
    }

    public String getUtiliteitsnetInspireId() {
        return utiliteitsnetInspireId;
    }

    public void setUtiliteitsnetInspireId(String utiliteitsnetInspireId) {
        this.utiliteitsnetInspireId = utiliteitsnetInspireId;
    }

    public List<String> getUtilityLinkInspireIds() {
        return utilityLinkInspireIds;
    }

    public void setUtilityLinkInspireIds(List<String> utilityLinkInspireIds) {
        this.utilityLinkInspireIds = utilityLinkInspireIds;
    }

    @Override
    public String getVerticalPosition() {
        return verticalPosition;
    }

    @Override
    public void setVerticalPosition(String verticalPosition) {
        this.verticalPosition = verticalPosition;
    }

}
