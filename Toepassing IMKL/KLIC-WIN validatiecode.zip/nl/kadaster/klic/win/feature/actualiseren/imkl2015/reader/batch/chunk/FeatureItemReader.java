package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.chunk;

import nl.kadaster.klic.util.FileStore;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.context.MultiThreadedBatchJobContext;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.data.BatchJobThreadData;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.domain.FeatureItem;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.xml.XmlIterator;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.xml.XmlIteratorException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.xml.XmlPart;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.xml.XmlSplitter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemReader;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Reads feature items (XML FeatureMember) from a file stream and does some basic validations
 * on the file stream:
 * - Verify that the first file in the ZIP is an XML file
 * - Verfiy that there is only one file in the ZIP
 */
public class FeatureItemReader implements ItemReader<FeatureItem> {

    private static final Logger LOG = LoggerFactory.getLogger(FeatureItemReader.class);

    private static final String XML_FILE_EXTENSION = ".xml";

    private static final String FEATURE_COLLECTION_TAG = "FeatureCollection";
    private static final String FEATURE_MEMBER_TAG = "featureMember";

    private final FileStore aanleveringFileStore;
    private XmlIterator xmlIterator;
    private boolean initialized = false;

    // used by threads to see if another thread already read the last content
    private boolean allContentProcessed = false;

    private long actualisatieId;
    private String bronhoudercode;

    public FeatureItemReader(final FileStore aanleveringFileStore) {
        this.aanleveringFileStore = aanleveringFileStore;
    }

    /**
     * NOTE: Synchronized because we are using multi-threaded step executions
     * See: klic-import-batch-job.xml for the configuration of Spring Batch
     */
    @Override
    public synchronized FeatureItem read() throws Exception {
        if (!initialized) {
            initialize();
        }
        return readNext();
    }

    private FeatureItem readNext() throws IOException {
        if (!initialized) {
            LOG.error("Not initialized.");
            return null;
        }
        return getNextFeatureItem();
    }

    private FeatureItem getNextFeatureItem() throws IOException {
        if (!allContentProcessed && hasNext()) {
            return getNextItem();
        } else if (!allContentProcessed){
            reportErrors();
            allContentProcessed = true;
        }
        return null;
    }

    private boolean hasNext() {
        boolean hasNext = false;
        final ValidationMessageBuilder validationMessageBuilder = MultiThreadedBatchJobContext.getBatchJobThreadData()
                .getValidationMessageBuilder();
        try {
            final boolean maxNumberOfMessagesReached = validationMessageBuilder.hasMaxNumberOfMessages();
            hasNext = !maxNumberOfMessagesReached && xmlIterator.hasNext();
        } catch (XmlIteratorException e) {
            LOG.error("Technical error while iterating XML file", e);
            validationMessageBuilder.addErrorTechnical();
        }
        return hasNext;
    }

    private FeatureItem getNextItem() {
        final XmlPart xmlPart = xmlIterator.next();
        final String xmlString = xmlPart.getCompleteXmlPart();
        return new FeatureItem(actualisatieId, bronhoudercode, xmlString, xmlPart.getXmlElement().getRowNr());
    }

    private void reportErrors() {
        final List<String> errors = xmlIterator.getErrors();
        final BatchJobThreadData batchJobThreadData = MultiThreadedBatchJobContext.getBatchJobThreadData();
        for (String error : errors) {
            batchJobThreadData.getValidationMessageBuilder().addXMLProcessingError(error);
        }
    }

    /**
     * Initialize the stream, verify that the first file in the ZIP is an XML file.
     * Initializes the xmlIterator, from which featuremembers can be requested.
     */
    private void initialize() {
        final BatchJobThreadData batchJobThreadData = MultiThreadedBatchJobContext.getBatchJobThreadData();
        final String filename = batchJobThreadData.getFilename();

        bronhoudercode = batchJobThreadData.getBronhoudercode();
        actualisatieId = batchJobThreadData.getActualisatieId();

        LOG.info("Initializing batched import for bronhoudercode: {}, actualisationId: {}", bronhoudercode, actualisatieId);
        LOG.info("Getting file content stream on file '{}'", filename);
        try {
            File file = aanleveringFileStore.retrieveFile(filename);
            ZipFile zipfile = new ZipFile(file);

            InputStream xmlInputStream = getXmlInputStream(zipfile);
            LOG.info("Setting up xml splitter");
            xmlIterator = new XmlSplitter(FEATURE_COLLECTION_TAG, FEATURE_MEMBER_TAG).split(xmlInputStream, batchJobThreadData.getValidator());
            initialized = true;
        } catch (IOException | RuntimeException e) {
            LOG.error("Technical error while processing IMKL file", e);
            batchJobThreadData.getValidationMessageBuilder().addErrorTechnical();
        }
        LOG.info("Initialization done.");
    }

    /**
     * Returns the xml entry as an InputStream, provided that the zip file contains exactly one entry with .xml extension
     */
    private InputStream getXmlInputStream(ZipFile zipfile) throws IOException {
        final Enumeration<? extends ZipEntry> entries = zipfile.entries();
        while(entries.hasMoreElements()) {
            ZipEntry entry = entries.nextElement();
            if (isXmlFile(entry.getName())){
                InputStream is = zipfile.getInputStream(entry);
                return new BufferedInputStream(is);
            }
        }
        throw new FileNotFoundException(String.format("Could not find a zip entry with %s extension in the provided zip file %s", XML_FILE_EXTENSION, zipfile.getName()));
    }

    private boolean isXmlFile(String filename){
        return filename.toLowerCase().endsWith(XML_FILE_EXTENSION);
    }

}
