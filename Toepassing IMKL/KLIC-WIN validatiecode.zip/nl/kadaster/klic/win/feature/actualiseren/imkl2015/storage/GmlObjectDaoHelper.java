package nl.kadaster.klic.win.feature.actualiseren.imkl2015.storage;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.GmlObject;
import nl.kadaster.klic.win.util.NiStoreUtil;
import nl.kadaster.klic.win.storage.DatabaseHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import static nl.kadaster.klic.win.util.NiStoreUtil.SA_PLACEHOLDER;

/**
 * Code shared by the InspireGmlObjectDao and the WionGmlObjectDao.
 */
public class GmlObjectDaoHelper {

    private static final String SQL_INSERT_CONCEPT = "INSERT INTO " + SA_PLACEHOLDER + " "
            + "( featureid " //
            + ", gml_id" //
            + ", bronhoudercode" //
            + ", ft_type" //
            + ", binary_object" //
            + ", gml_bounded_by" //
            + ", geometry" //
            + ") VALUES (" //
            + "  ?" // featureid
            + ", ?" // gml_id
            + ", ?" // bronhoudercode
            + ", ?" // ft_type
            + ", ?" // binary_object
            + ", ?" // gml_bounded_by
            + ", ?" // geometry
            + ")";

    private static final String SQL_INSERT_CONCEPT_WITHOUT_BBOX = "INSERT INTO " + SA_PLACEHOLDER + " "
            + "( featureid " //
            + ", gml_id" //
            + ", bronhoudercode" //
            + ", ft_type" //
            + ", binary_object" //
            + ") VALUES ("
            + " ?" // featureid
            + ",?" // gml_id
            + ",?" // bronhoudercode
            + ",?" // ft_type
            + ",?" // binary_object
            + ")";

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public void store(final String tableName, final GmlObject gmlObject) {
        if (gmlObject.getGeometry() != null || gmlObject.getGmlBoundedBy() != null) {
            storeWithGeometries(tableName, gmlObject);
        } else {
            storeWithoutGeometries(tableName, gmlObject);
        }
    }

    public void storeBatch(final String tableName, final List<GmlObject> gmlObjects) {
        final String sql;
        final String bronhoudercode;
        
        if (gmlObjects.isEmpty()) {
            return;
        }
        
        bronhoudercode = gmlObjects.get(0).getBronhoudercode();
        sql = NiStoreUtil.adaptQueryForStagingArea(bronhoudercode, SQL_INSERT_CONCEPT, tableName);
        jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(final PreparedStatement ps, final int i) throws SQLException {
                DatabaseHelper.initPostGisConnection(ps.getConnection());
                GmlObject gmlObject = gmlObjects.get(i);
                int pos = 1;
                ps.setLong(pos++, gmlObject.getFeatureId());
                ps.setString(pos++, gmlObject.getGmlId());
                ps.setString(pos++, gmlObject.getBronhoudercode());
                ps.setLong(pos++, gmlObject.getFeatureTypeId());
                ps.setBytes(pos++, gmlObject.getBinaryObject());
                ps.setObject(pos++, gmlObject.getGmlBoundedBy());
                ps.setObject(pos, gmlObject.getGeometry());
            }

            @Override
            public int getBatchSize() {
                return gmlObjects.size();
            }
        });

    }

    private void storeWithoutGeometries(final String tableName, final GmlObject gmlObject) {
        final String bronhoudercode = gmlObject.getBronhoudercode();
        final String sql = NiStoreUtil.adaptQueryForStagingArea(bronhoudercode, SQL_INSERT_CONCEPT_WITHOUT_BBOX, tableName);
        jdbcTemplate.update(new PreparedStatementCreator() {
            @Override
            public PreparedStatement createPreparedStatement(final Connection connection) throws SQLException {
                final PreparedStatement ps = DatabaseHelper.initPostGisConnection(connection).prepareStatement(sql);
                int pos = 1;
                ps.setLong(pos++, gmlObject.getFeatureId());
                ps.setString(pos++, gmlObject.getGmlId());
                ps.setString(pos++, gmlObject.getBronhoudercode());
                ps.setLong(pos++, gmlObject.getFeatureTypeId());
                ps.setBytes(pos, gmlObject.getBinaryObject());
                return ps;
            }
        });
    }

    private void storeWithGeometries(final String tableName, final GmlObject gmlObject) {
        final String bronhoudercode = gmlObject.getBronhoudercode();
        final String sql = NiStoreUtil.adaptQueryForStagingArea(bronhoudercode, SQL_INSERT_CONCEPT, tableName);
        jdbcTemplate.update(new PreparedStatementCreator() {
            @Override
            public PreparedStatement createPreparedStatement(final Connection connection) throws SQLException {
                final PreparedStatement ps = DatabaseHelper.initPostGisConnection(connection).prepareStatement(sql);
                int pos = 1;
                ps.setLong(pos++, gmlObject.getFeatureId());
                ps.setString(pos++, gmlObject.getGmlId());
                ps.setString(pos++, gmlObject.getBronhoudercode());
                ps.setLong(pos++, gmlObject.getFeatureTypeId());
                ps.setBytes(pos++, gmlObject.getBinaryObject());
                ps.setObject(pos++, gmlObject.getGmlBoundedBy());
                ps.setObject(pos, gmlObject.getGeometry());
                return ps;
            }
        });
    }
}
