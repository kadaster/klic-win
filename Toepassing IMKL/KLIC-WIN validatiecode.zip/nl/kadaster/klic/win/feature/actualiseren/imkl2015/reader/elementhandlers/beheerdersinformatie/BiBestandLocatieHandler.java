package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.beheerdersinformatie;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.context.MultiThreadedBatchJobContext;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.data.BatchJobThreadData;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.BestandLocatieHandler;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import org.apache.commons.lang3.StringUtils;

public class BiBestandLocatieHandler extends BestandLocatieHandler {

    @Override
    protected void validateBestandLocatie(final String bestandLocatie, final String gmlId, final ValidationMessageBuilder validationMessageBuilder) {

        if (StringUtils.isEmpty(bestandLocatie)) {
            validationMessageBuilder.addErrorEmptyElement(gmlId);
            return;
        }

        final BatchJobThreadData batchJobThreadData = MultiThreadedBatchJobContext.getBatchJobThreadData();

        if (!bestandLocatie.toLowerCase().endsWith(".pdf")) {
            validationMessageBuilder.addErrorBestandLocatieExtention(gmlId, bestandLocatie, "PDF");
            return;
        }

        if (!batchJobThreadData.getFilesInZipFile().contains(bestandLocatie)) {
            validationMessageBuilder.addErrorBestandLocatieNotFoundInZip(gmlId, bestandLocatie);
            return;
        }

        batchJobThreadData.getFilesReferencedFromFeatures().add(bestandLocatie);
    }
}
