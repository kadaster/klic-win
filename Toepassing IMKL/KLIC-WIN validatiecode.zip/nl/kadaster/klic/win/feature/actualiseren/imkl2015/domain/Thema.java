package nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain;

import nl.kadaster.klic.win.feature.domain.DomainObject;

public class Thema extends DomainObject {

    private String aThema;

    public String getThema() {
        return aThema;
    }

    public void setThema(final String thema) {
        aThema = thema;
    }
}
