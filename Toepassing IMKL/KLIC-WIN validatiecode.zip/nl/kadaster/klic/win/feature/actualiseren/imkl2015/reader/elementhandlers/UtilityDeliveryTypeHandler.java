package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.domain.KabelOfLeiding;
import nl.kadaster.klic.win.feature.common.util.gml.Elements;

import javax.xml.namespace.QName;

public class UtilityDeliveryTypeHandler extends AbstractCodelistElementHandler<KabelOfLeiding> {

    private static final String CODELIST_NAME_INSPIRE = "UtilityDeliveryTypeValue";

    @Override
    protected QName getHandlingElement() {
        return Elements.UTILITY_DELIVERY_TYPE;
    }

    @Override
    protected void preValidate() {
       setCodelist(CODELIST_NAME_INSPIRE);
    }

    @Override
    protected void postValidate(final KabelOfLeiding kabelOfLeiding, final String xLinkCodelistValue) {
        kabelOfLeiding.setUtilityDeliveryType(xLinkCodelistValue);
    }
}
