package nl.kadaster.klic.win.feature.actualiseren.imkl2015.validation;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.Validator;
import java.io.IOException;
import java.io.StringReader;

/**
 * IMKL XML validator. Validates the given XML against the WION XSD's
 */
public class ImklValidator {

    private final XsdSchemaCache xsdSchemaCache;

    @Autowired
    public ImklValidator(final XsdSchemaCache xsdSchemaCache) {
        this.xsdSchemaCache = xsdSchemaCache;
    }

    public static long validate(final Validator validator, final String xmlString) throws ImklValidatorException {
        long startTime = System.currentTimeMillis();
        try {
            validator.validate(new StreamSource(new StringReader(xmlString)));
        } catch (SAXException | IOException e) {
            throw new ImklValidatorException("Unable to validate XML due to exception", e);
        }
        return System.currentTimeMillis() - startTime;
    }

    public synchronized Validator createValidator(final ValidationMessageBuilder validationMessageBuilder) throws ImklValidatorException {
        // look for XSD files in local package instead of the interwebs
        final Schema schema = xsdSchemaCache.getXsdSchema(XsdSchema.IMKL_XSD);
        if (schema == null) {
            throw new ImklValidatorException("Unable to create IMKL validator because XSD schemas are NULL");
        }
        Validator validator = schema.newValidator();
        validator.setErrorHandler(new IMKLErrorHandler(validationMessageBuilder));
        return validator;
    }

    private static class IMKLErrorHandler implements ErrorHandler {

        private final ValidationMessageBuilder validationMessageBuilder;

        IMKLErrorHandler(final ValidationMessageBuilder validationMessageBuilder) {
            this.validationMessageBuilder = validationMessageBuilder;
        }

        @Override
        public void error(final SAXParseException e) throws SAXException {
            validationMessageBuilder.addErrorXsdValidation(constructMessage(e));
            stopOnMaxMessagesReached();
        }

        @Override
        public void fatalError(final SAXParseException e) throws SAXException {
            validationMessageBuilder.addErrorXsdValidation(constructMessage(e));
            stopOnMaxMessagesReached();
        }

        @Override
        public void warning(final SAXParseException e) throws SAXException {
            validationMessageBuilder.addWarningXsdValidation(constructMessage(e));
            stopOnMaxMessagesReached();
        }

        private String constructMessage(final SAXParseException e) {
            return e.getMessage() + " [lineNr: " + (e.getLineNumber() + validationMessageBuilder.getLineNrOffset()) + ", columnNr: " + e.getColumnNumber() + "]";
        }

        // throwing SAXException here will abort validation process
        void stopOnMaxMessagesReached() throws SAXException {
            if (validationMessageBuilder.hasMaxNumberOfMessages()) {
                throw new SAXException("Max number of error messages reached. Cancelling validation.");
            }
        }
    }
}
