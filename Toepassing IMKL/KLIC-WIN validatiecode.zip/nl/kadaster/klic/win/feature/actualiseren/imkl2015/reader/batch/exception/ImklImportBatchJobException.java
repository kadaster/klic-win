package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.exception;

public class ImklImportBatchJobException extends Exception {

    public ImklImportBatchJobException(final String message, final Throwable cause) {
        super(message, cause);
    }
}
