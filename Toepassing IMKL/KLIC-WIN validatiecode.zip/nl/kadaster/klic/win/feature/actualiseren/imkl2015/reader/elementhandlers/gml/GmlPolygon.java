package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.elementhandlers.gml;

import java.util.ArrayList;
import java.util.List;

import org.postgis.PGgeometry;

import nl.kadaster.klic.win.storage.DatabaseHelper;
import nl.kadaster.klic.win.storage.GeometryException;

class GmlPolygon implements GmlGeometry {

    private final List<GmlLinearRing> rings = new ArrayList<>();
    private boolean isInterior;
    
    public void add(final GmlLinearRing ring) {
        ring.setInterior(isInterior);
        rings.add(ring);
    }
    
    void startExteriorTag() {
        isInterior = false;
    }
    
    void startInteriorTag() {
        isInterior = true;
    }

    // return null if it not supported as PGGeometry
    @Override
    public PGgeometry getPGgeometry() {
        if (rings.size() > 1) {
            return null;
        }
        GmlLinearRing ring = rings.get(0);
        return DatabaseHelper.gmlPolygonToPgPolygon(ring.getPoints());
    }
    
    // to be used if PGGeometry is not supported
    String toEWKT() throws GeometryException {
        StringBuilder buff = new StringBuilder();
        buff.append("SRID=28992;POLYGON(");
        boolean comma = false;
        for (GmlLinearRing ring : rings) {
            if (comma) {
                buff.append(",");
            }
            buff.append(ring.toEWKT());
            comma = true;
        }
        buff.append(")");
        return buff.toString();
    }

}
