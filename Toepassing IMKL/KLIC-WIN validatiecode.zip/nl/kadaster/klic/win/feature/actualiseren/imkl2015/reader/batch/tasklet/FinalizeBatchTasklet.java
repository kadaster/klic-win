package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.tasklet;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.AanleveringCharacteristicsValidator;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.PostGisGeometryValidator;
import nl.kadaster.klic.win.feature.domain.InformatieSoort;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.FeatureLinkWriter;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.context.BatchJobContext;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.data.BatchJobData;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.storage.PartitionDao;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.validation.AppurtenanceTypeValidator;
import nl.kadaster.klic.win.feature.actualiseren.report.StatisticReportService;

/**
 * Handling that needs to be done after all features are read.
 * Includes database writing and validating.
 */
public class FinalizeBatchTasklet implements Tasklet {

    private static final Logger LOG = LoggerFactory.getLogger(FinalizeBatchTasklet.class);

    private final PartitionDao partitionDao;
    private final FeatureLinkWriter featureLinkWriter;
    private final AppurtenanceTypeValidator appurtenanceTypeValidator;
    private final PostGisGeometryValidator geometryValidator;
    private final AanleveringCharacteristicsValidator aanleveringCharacteristicsValidator;
    private final StatisticReportService statisticReportService;

    private final BatchJobContext batchJobContext;
    private long actualisatieId;

    @Autowired
    public FinalizeBatchTasklet(
            final PartitionDao partitionDao,
            final FeatureLinkWriter featureLinkWriter,
            final AppurtenanceTypeValidator appurtenanceTypeValidator,
            final PostGisGeometryValidator geometryValidator,
            final StatisticReportService statisticReportService,
            final BatchJobContext batchJobContext,
            final AanleveringCharacteristicsValidator aanleveringCharacteristicsValidator
    ) {
        this.partitionDao = partitionDao;
        this.featureLinkWriter = featureLinkWriter;
        this.appurtenanceTypeValidator = appurtenanceTypeValidator;
        this.geometryValidator = geometryValidator;
        this.statisticReportService = statisticReportService;
        this.batchJobContext = batchJobContext;
        this.aanleveringCharacteristicsValidator = aanleveringCharacteristicsValidator;
    }

    @Override
    public RepeatStatus execute(final StepContribution stepContribution, final ChunkContext chunkContext) throws Exception {
        LOG.info("Running (postprocessing) finalization tasks...");
        long start = System.currentTimeMillis();
        final BatchJobData batchJobData = batchJobContext.getBatchJobData(actualisatieId);
        final String bronhoudercode = batchJobData.getBronhoudercode();
        final ValidationMessageBuilder validationMessageBuilder = batchJobData.getValidationMessageBuilder();

        if (InformatieSoort.BEHEERDERSINFORMATIE == batchJobData.getInformatieSoort()) {
            LOG.info("Validation of aanlevering characteristics");
            aanleveringCharacteristicsValidator.validate(batchJobData.getAanleveringCharacteristics(), validationMessageBuilder);
        }

        LOG.info("Validation of feature geometries in PostGis (st_isValid)");
        geometryValidator.validate(bronhoudercode, validationMessageBuilder);

        LOG.info("Finishing Staging Areas...");
        LOG.info("Creating Staging indexes...");
        partitionDao.createSaIndexes(bronhoudercode);
        LOG.info("Creating Staging constraints...");
        partitionDao.createSaConstraints(bronhoudercode);

        LOG.info("Finishing featurelinks...");
        featureLinkWriter.finishFeatureLinks(bronhoudercode, validationMessageBuilder);

        LOG.info("Validating appurtenance types in regard to their thema's...");
        appurtenanceTypeValidator.validate(bronhoudercode, validationMessageBuilder);

        LOG.info("Creating aanleverstatistiek records...");
        statisticReportService.createReport(bronhoudercode, batchJobData.getStatistiekregels());
        batchJobData.addDatabasePostUpdateTimeInMilliseconds(System.currentTimeMillis() - start);

        LOG.info("Done execution (postprocessing) finalization tasks.");
        return RepeatStatus.FINISHED;
    }

    public void setActualisatieId(final long actualisatieId) {
        this.actualisatieId = actualisatieId;
    }
}
