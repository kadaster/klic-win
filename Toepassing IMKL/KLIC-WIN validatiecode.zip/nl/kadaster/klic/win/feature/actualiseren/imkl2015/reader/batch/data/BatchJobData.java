package nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.data;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.AanleveringCharacteristics;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.model.StatistiekRegel;
import nl.kadaster.klic.win.feature.domain.InformatieSoort;

import java.util.ArrayList;
import java.util.List;

/**
 * Batch job data holder, holding data that is shared and collected among the steps in the batch job.
 * Holds generic processing data and statistics.
 */
public class BatchJobData {

    private final String bronhoudercode;
    private final long actualisatieId;
    private final String filename;
    private final long batchSize;
    private final int poolSize;
    private final InformatieSoort informatieSoort;

    private final ValidationMessagesTracker validationMessagesTracker;
    private final ValidationMessageBuilder validationMessageBuilder;
    private final List<StatistiekRegel> statistiekregels = new ArrayList<>();
    private final List<String> filesInZipFile;
    private final List<String> filesReferencedFromFeatures;
    private final AanleveringCharacteristics aanleveringCharacteristics = new AanleveringCharacteristics();
    private long totalXmlValidationTimeInMilliseconds;
    private long totalValidatedImportTimeInMilliseconds;
    private long totalDatabaseInsertTimeInMilliseconds;
    private long totalDatabasePostUpdateTimeInMilliseconds;
    private long totalDocumentReferenceCheckingTimeInMilliseconds;
    private long totalDocumentReferenceCheckedCount;

    public BatchJobData(final InformatieSoort informatieSoort, final String bronhoudercode, final long actualisatieId, final String filename,
                        final long batchSize, final int poolSize, final ValidationMessagesTracker validationMessagesTracker) {
        this.bronhoudercode = bronhoudercode;
        this.actualisatieId = actualisatieId;
        this.filename = filename;
        this.batchSize = batchSize;
        this.poolSize = poolSize;
        this.informatieSoort = informatieSoort;

        this.validationMessagesTracker = validationMessagesTracker;
        validationMessageBuilder = new ValidationMessageBuilder(actualisatieId, validationMessagesTracker);

        totalXmlValidationTimeInMilliseconds = 0L;
        totalValidatedImportTimeInMilliseconds = 0L;
        totalDatabaseInsertTimeInMilliseconds = 0L;
        totalDatabasePostUpdateTimeInMilliseconds = 0L;
        totalDocumentReferenceCheckingTimeInMilliseconds = 0L;
        totalDocumentReferenceCheckedCount = 0L;

        filesInZipFile = new ArrayList<>();
        filesReferencedFromFeatures = new ArrayList<>();
    }

    public InformatieSoort getInformatieSoort() {
        return informatieSoort;
    }

    public String getBronhoudercode() {
        return bronhoudercode;
    }

    public long getActualisatieId() {
        return actualisatieId;
    }

    public String getFilename() {
        return filename;
    }

    public long getBatchSize() {
        return batchSize;
    }

    public ValidationMessageBuilder getValidationMessageBuilder() {
        return validationMessageBuilder;
    }

    ValidationMessagesTracker getValidationMessagesTracker() {
        return validationMessagesTracker;
    }

    public long getTotalDatabasePostUpdateTimeInMilliseconds() {
        return totalDatabasePostUpdateTimeInMilliseconds;
    }

    public void addDatabasePostUpdateTimeInMilliseconds(final long databasePostUpdateTimeInMilliseconds) {
        totalDatabasePostUpdateTimeInMilliseconds += databasePostUpdateTimeInMilliseconds;
    }

    public void addXmlValidationTime(final long xmlValidationTime) {
        totalXmlValidationTimeInMilliseconds += xmlValidationTime;
    }

    public void addValidatedImportTime(final long validatedImportTime) {
        totalValidatedImportTimeInMilliseconds += validatedImportTime;
    }

    public long getTotalDatabaseInsertTimeInMilliseconds() {
        return totalDatabaseInsertTimeInMilliseconds;
    }

    public void addDatabaseInsertTime(final long databaseInsertTimeInMilliseconds) {
        totalDatabaseInsertTimeInMilliseconds += databaseInsertTimeInMilliseconds;
    }

    public long getTotalDocumentReferenceCheckingTimeInMilliseconds() {
        return totalDocumentReferenceCheckingTimeInMilliseconds;
    }

    public void addDocumentReferenceCheckingTime(final long documentReferenceCheckingTime) {
        totalDocumentReferenceCheckingTimeInMilliseconds += documentReferenceCheckingTime;
    }

    public void addDocumentReferenceCheckedCount() {
        totalDocumentReferenceCheckedCount++;
    }

    public long getTotalDocumentReferenceCheckedCount() {
        return totalDocumentReferenceCheckedCount;
    }

    public long getTotalXmlValidationTimeInMilliseconds() {
        return totalXmlValidationTimeInMilliseconds;
    }

    public long getTotalValidatedImportTimeInMilliseconds() {
        return totalValidatedImportTimeInMilliseconds;
    }

    public int getPoolSize() {
        return poolSize;
    }

    public List<StatistiekRegel> getStatistiekregels() {
        return statistiekregels;
    }

    public List<String> getFilesInZipFile() {
        return filesInZipFile;
    }

    public List<String> getFilesReferencedFromFeatures() {
        return filesReferencedFromFeatures;
    }

    public AanleveringCharacteristics getAanleveringCharacteristics() {
        return aanleveringCharacteristics;
    }

    private void addDocumentReferenceCheckedCount(final long documentReferenceCheckedCount) {
        totalDocumentReferenceCheckedCount += documentReferenceCheckedCount;
    }

    /**
     * Appends data collected from (multiple) threads executing the job to the overall batch job data
     * @param batchJobData The batch job data collected by the thread
     */
    public void appendThreadJobData(final BatchJobData batchJobData) {
        getValidationMessageBuilder().addAll(batchJobData.getValidationMessageBuilder().getValidationMessages());
        addDatabaseInsertTime(batchJobData.getTotalDatabaseInsertTimeInMilliseconds());
        addXmlValidationTime(batchJobData.getTotalXmlValidationTimeInMilliseconds());
        addValidatedImportTime(batchJobData.getTotalValidatedImportTimeInMilliseconds());
        getFilesReferencedFromFeatures().addAll(batchJobData.getFilesReferencedFromFeatures());
        if (InformatieSoort.NETINFORMATIE == batchJobData.getInformatieSoort()) {
            addDocumentReferenceCheckingTime(batchJobData.getTotalDocumentReferenceCheckingTimeInMilliseconds());
            addDocumentReferenceCheckedCount(batchJobData.getTotalDocumentReferenceCheckedCount());
        }
        if (batchJobData.getAanleveringCharacteristics().hasEigenTopo()) {
            getAanleveringCharacteristics().setHasEigenTopo(true);
        }
        if (batchJobData.getAanleveringCharacteristics().isBetrokken()) {
            getAanleveringCharacteristics().setBetrokken(true);
        }
        if (batchJobData.getAanleveringCharacteristics().hasEisVoorzorgsmaatregelBijlage()) {
            getAanleveringCharacteristics().setHasEisVoorzorgsmaatregelBijlage(true);
        }
        if (batchJobData.getAanleveringCharacteristics().isBelanghebbendeHasEisVoorzorgsmaatregel()) {
            getAanleveringCharacteristics().setBelanghebbendeHasEisVoorzorgsmaatregel(true);
        }
        if (batchJobData.getAanleveringCharacteristics().hasUtiliteitsnet()) {
            getAanleveringCharacteristics().setHasUtiliteitsnet(true);
        }
    }
}
