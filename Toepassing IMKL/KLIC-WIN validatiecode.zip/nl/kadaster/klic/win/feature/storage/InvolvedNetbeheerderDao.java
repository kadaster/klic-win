package nl.kadaster.klic.win.feature.storage;

public interface InvolvedNetbeheerderDao {

    void storeInvolvedBeheerder(final long orderId, final String involvedBeheerder, final boolean isBeheerderVeiligheidsGebied);
}
