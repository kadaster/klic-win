package nl.kadaster.klic.win.feature.storage;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class DataSourceLogger {

    private static final Logger LOG =  LoggerFactory.getLogger(DataSourceLogger.class);
    
    @Autowired
    private DataSource datasource;
    
    public void log() {
        try (Connection conn = datasource.getConnection()) {
            DatabaseMetaData md = conn.getMetaData();
            LOG.info("dbUrl = {}", md.getURL());
            LOG.info("dbUser = {}", md.getUserName());
        } catch (SQLException e) {
            LOG.error("Failed to connect", e);
        }
    }

}
