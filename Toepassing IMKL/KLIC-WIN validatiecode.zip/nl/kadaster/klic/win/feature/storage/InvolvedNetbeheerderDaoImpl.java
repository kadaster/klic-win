package nl.kadaster.klic.win.feature.storage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InvolvedNetbeheerderDaoImpl implements InvolvedNetbeheerderDao {

    private static final String TABLENAME_INVOLVED_BEHEERDER = "betrokkenbeheerder";

    private static final java.lang.String INSERT_INVOLVED_BEHEERDER =
            "INSERT INTO levering." + TABLENAME_INVOLVED_BEHEERDER + " (order_id, beheerder_identificator, bvg) VALUES (?, ?, ?)";

    @Autowired
    private DataSource datasource;

    @Override
    public void storeInvolvedBeheerder(final long orderId, final String beheerderIdentificator, final boolean isBeheerderVeiligheidsGebied) {
        new JdbcTemplate(datasource).update(new PreparedStatementCreator() {
            @Override
            public PreparedStatement createPreparedStatement(final Connection connection) throws SQLException {
                final PreparedStatement ps = connection.prepareStatement(INSERT_INVOLVED_BEHEERDER);
                ps.setLong(1, orderId);
                ps.setString(2, beheerderIdentificator);
                ps.setBoolean(3, isBeheerderVeiligheidsGebied);
                return ps;
            }
        });
    }
}
