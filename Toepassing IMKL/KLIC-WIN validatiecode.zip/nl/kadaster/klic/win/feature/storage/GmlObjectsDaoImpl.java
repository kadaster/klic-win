package nl.kadaster.klic.win.feature.storage;

import static nl.kadaster.klic.win.util.NiStoreUtil.SA_PLACEHOLDER;
import static nl.kadaster.klic.win.util.NiStoreUtil.adaptQueryForStagingArea;
import static nl.kadaster.klic.win.util.NiStoreUtil.getBronhoudercodeFromGmlId;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import nl.kadaster.klic.geo.GeometryHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;

import nl.kadaster.klic.win.feature.domain.WktBoundingbox;
import nl.kadaster.klic.win.feature.common.util.clip.dao.GmlBlobRowMapper;

public class GmlObjectsDaoImpl implements GmlObjectsDao {

    private static final String GML_BOUNDED_COLOMN_NAME = "wktarea";
    private static final String WION_RADIO_BUTTON_NAME = "wion";

    private static final String SQL_WKT_AREA = 
            "SELECT ST_AsText(gml_bounded_by) as wktarea" +
            " FROM " + SA_PLACEHOLDER +
            " WHERE gml_id = ?";

    private static final String SQL_INSPIRE_FEATURES_BY_GEOMETRY_AND_NETBEHEERDER =
            "select binary_object from " + SA_PLACEHOLDER + " where st_intersects(geometry, st_geomfromtext(?, 28992)) and bronhoudercode=?";
    
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public List<WktBoundingbox> getWKTArea(final String gmlid, final String group) {
        
        final String table =  group.equalsIgnoreCase(WION_RADIO_BUTTON_NAME) ? "wion_gml_objects" : "inspire_gml_objects";
        final String sql = adaptQueryForStagingArea(getBronhoudercodeFromGmlId(gmlid), SQL_WKT_AREA, table);
        return jdbcTemplate.query(new PreparedStatementCreator() {
            @Override
            public PreparedStatement createPreparedStatement(final Connection connection) throws SQLException {
                final PreparedStatement ps = connection.prepareStatement(sql);
                ps.setString(1, gmlid);
                return ps;
            }
        }, new RowMapper<WktBoundingbox>() {

            @Override
            public WktBoundingbox mapRow(final ResultSet rs, final int rowNum) throws SQLException {
                WktBoundingbox wktBoundingbox = new WktBoundingbox();
                wktBoundingbox.setWktBoundingbox(rs.getString(GML_BOUNDED_COLOMN_NAME));
                return wktBoundingbox;
            }

        });
    }

    @Override
    public List<String> getFeatureGmlConcept(final String bronhoudercode, final double xMin, final double yMin, final double xMax, final double yMax) {
        String sql = adaptQueryForStagingArea(bronhoudercode, SQL_INSPIRE_FEATURES_BY_GEOMETRY_AND_NETBEHEERDER, "inspire_gml_objects");
        return getFeatureGml(sql, bronhoudercode, xMin, yMin, xMax, yMax);
    }
    
    @Override
    public List<String> getFeatureGmlProd(final String bronhoudercode, final double xMin, final double yMin, final double xMax, final double yMax) {
        String sql = String.format(SQL_INSPIRE_FEATURES_BY_GEOMETRY_AND_NETBEHEERDER, "ni_store.inspire_gml_objects");
        return getFeatureGml(sql, bronhoudercode, xMin, yMin, xMax, yMax);
    }

    private List<String> getFeatureGml(final String sql, final String bronhoudercode, final double xMin, final double yMin, final double xMax, final double yMax) {
        return jdbcTemplate.query(new PreparedStatementCreator() {
            @Override
            public PreparedStatement createPreparedStatement(final Connection connection) throws SQLException {
                final PreparedStatement ps = connection.prepareStatement(sql);
                ps.setString(1, GeometryHelper.bboxToWktPolygon(xMin, yMin, xMax, yMax));
                ps.setString(2, bronhoudercode);
                return ps;
            }
        }, new GmlBlobRowMapper());
    }
}
