package nl.kadaster.klic.win.feature.storage;

import nl.kadaster.klic.win.feature.domain.WktBoundingbox;

import java.util.List;

public interface GmlObjectsDao {

    List<WktBoundingbox> getWKTArea(final String gmlid, final String group);
    List<String> getFeatureGmlConcept(final String bronhoudercode, final double xMin, final double yMin, final double xMax, final double yMax);
    List<String> getFeatureGmlProd(final String bronhoudercode, final double xMin, final double yMin, final double xMax, final double yMax);

}
