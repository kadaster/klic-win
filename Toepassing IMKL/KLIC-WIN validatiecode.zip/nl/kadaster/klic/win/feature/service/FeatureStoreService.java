package nl.kadaster.klic.win.feature.service;

import nl.kadaster.klic.win.feature.domain.ThemeRequestParameters;
import nl.kadaster.klic.win.feature.domain.ThemeResponse;
import nl.kadaster.klic.win.feature.domain.WktBoundingbox;

public interface FeatureStoreService {

    void removeConcept(final String bronhoudercode);
    void conceptToProduction(final String bronhoudercode) throws FeatureStoreException;

    ThemeResponse getThemes(final ThemeRequestParameters params);

    @SuppressWarnings("unused") // Called by Camel REST
    WktBoundingbox getWKTAreaByGMLId(final String gmlid, final String group);
}
