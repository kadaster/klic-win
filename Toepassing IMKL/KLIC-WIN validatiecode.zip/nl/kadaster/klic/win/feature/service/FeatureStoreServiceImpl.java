package nl.kadaster.klic.win.feature.service;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.storage.FeatureDao;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.storage.ImklDao;
import nl.kadaster.klic.win.feature.domain.ThemeRequestParameters;
import nl.kadaster.klic.win.feature.domain.ThemeResponse;
import nl.kadaster.klic.win.feature.domain.WktBoundingbox;
import nl.kadaster.klic.win.feature.storage.GmlObjectsDao;

public class FeatureStoreServiceImpl implements FeatureStoreService {

    private static final Logger LOG = LoggerFactory.getLogger(FeatureStoreServiceImpl.class);

    @Autowired
    private ImklDao imklDao;
    @Autowired
    private FeatureDao featureDao;
    @Autowired
    private GmlObjectsDao gmlObjectsDao;
    
    @Override
    public void removeConcept(final String bronhoudercode) {
        LOG.debug("Service removeConcept is called");
        try {
            imklDao.removeConceptData(bronhoudercode);
            LOG.debug("Concept successfully removed");
        } catch (final RuntimeException re) {
            LOG.error("Failed to remove concept data for netbeheerder with bronhoudercode '{}'. ", bronhoudercode, re);
        }
    }

    /**
     * Copies the features of the netbeheerder from the concept to the production schema.
     * @param bronhoudercode the bronhoudercode of the netbeheerder
     * @exception  FeatureStoreException if something fails but a retry is useful
     */
    @Override
    @Transactional
    public void conceptToProduction(final String bronhoudercode) throws FeatureStoreException {
        LOG.debug("Service conceptToProduction is called");
        try {
            imklDao.migrateToProduction(bronhoudercode);
            LOG.info("Migration succeeded for netinformatie of netbeheerder with bronhoudercode '{}'", bronhoudercode);
        } catch (final RuntimeException re) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            final String msg = "Failed migration for netbeheerder with bronhoudercode '" + bronhoudercode + "'.";
            LOG.error(msg, re);
            throw new FeatureStoreException(msg, re);
        }
    }

    @Override
    public ThemeResponse getThemes(final ThemeRequestParameters params) {
        LOG.info("Service getThemes is called for bronhoudercode: {} and area: {}", params.getBronhoudercode(), params.getWktArea());
        ThemeResponse response = new ThemeResponse();
        List<String> themes = new ArrayList<>();
        try {
            String decodedWktArea = URLDecoder.decode(params.getWktArea(), "UTF-8");
            themes.addAll(featureDao.getImklThemesByNetbeheerderAndArea(params.getBronhoudercode(), decodedWktArea));
            LOG.info("Levering succeeded for bronhoudercode: {} and area: {}", params.getBronhoudercode(), decodedWktArea);
            response.setStatus(ThemeResponse.STATUS.OK);
            response.setThemes(themes);
        } catch (final RuntimeException | IOException e) {
            LOG.error("Failed getThemes for bronhoudercode " + params.getBronhoudercode() + " and area " + params.getWktArea(), e);
            response.setStatus(ThemeResponse.STATUS.ERROR);
        }
        return response;
    }

    @Override
    public WktBoundingbox getWKTAreaByGMLId(final String gmlid, final String group) {
        LOG.info("Service getWKTAreaByGMLd is called for gmlId: {} on {}", gmlid, group);
        List<WktBoundingbox> boundings = gmlObjectsDao.getWKTArea(gmlid, group);
        if(boundings.isEmpty()){
            LOG.info("no gml found with gmlid {} on {}. returning empty result", gmlid, group);
            return new WktBoundingbox();
        } else {
            WktBoundingbox result = boundings.get(0);
            LOG.info("boundingbox of {} on {} is {}", gmlid, group, result.getWktBoundingbox());
            return boundings.get(0);
        }
    }
}

