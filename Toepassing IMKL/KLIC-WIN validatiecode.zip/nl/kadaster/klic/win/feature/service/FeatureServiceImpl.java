package nl.kadaster.klic.win.feature.service;

import com.github.mustachejava.DefaultMustacheFactory;
import com.github.mustachejava.Mustache;
import nl.kadaster.klic.win.feature.storage.GmlObjectsDao;
import org.apache.commons.io.IOUtils;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.List;

public class FeatureServiceImpl implements FeatureService {

    private static final String SOURCE_CONCEPT = "concept";
    private static final Logger LOG = LoggerFactory.getLogger(FeatureServiceImpl.class);
    private static final String WFS_GET_FERATURE_RESPONSE_TEMPLATE = "nl/kadaster/klic/win/feature/service/WfsResponseTemplate.xml";
    private static final DefaultMustacheFactory MUSTACHE_FACTORY = new DefaultMustacheFactory() {
        @Override
        public void encode(final String value, final Writer writer) {
            try {
                writer.write(value);
            } catch (IOException e) {
                LOG.error("Unable to write mustache", e);
            }
        }
    };
    private static final Mustache RESPONSE_MUSTACHE = readMustache(WFS_GET_FERATURE_RESPONSE_TEMPLATE);

    @Autowired
    private GmlObjectsDao gmlObjectsDao;

    @Override
    public String getFeatureGml(final String source, final String bronhoudercode, final double xMin, final double yMin, final double xMax, final double yMax) {
        final List<String> featureGmls;
        if (SOURCE_CONCEPT.equals(source)) {
            featureGmls = gmlObjectsDao.getFeatureGmlConcept(bronhoudercode, xMin, yMin, xMax, yMax);
        } else {
            featureGmls = gmlObjectsDao.getFeatureGmlProd(bronhoudercode, xMin, yMin, xMax, yMax);
        }
        final StringBuilder members = new StringBuilder("");
        for (String member: featureGmls) {
            members.append("<gml:featureMember>");
            members.append(member);
            members.append("</gml:featureMember>");
        }
        final ResponseModel responseModel = new ResponseModel();
        responseModel.setNumber(featureGmls.size());
        responseModel.setMembers(members.toString());

        final StringWriter wrt = new StringWriter();
        RESPONSE_MUSTACHE.execute(wrt, responseModel);
        return wrt.toString();
    }

    private static Mustache readMustache(final String filename) {
        String s;
        try (InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(filename)) {
            s = IOUtils.toString(is);
        } catch (IOException ioe) {
            s = ioe.getMessage();
            LOG.error("Unable to read mustache " + filename, ioe);
        }
        return MUSTACHE_FACTORY.compile(new StringReader(s), "WfsResponseTemplate.xml", "[[", "]]");
    }

    static class ResponseModel {
        private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormat.forPattern("YYYY-MM-dd'T'HH:mm:ss'Z'");
        private long number = 0;
        private String members;
        private final String timestamp;

        ResponseModel() {
            super();
            timestamp = DATE_TIME_FORMATTER.print(new DateTime());
        }

        public String getTimestamp() {
            return timestamp;
        }

        public long getNumber() {
            return number;
        }

        public void setNumber(final long number) {
            this.number = number;
        }

        public String getMembers() {
            return members;
        }

        public void setMembers(final String members) {
            this.members = members;
        }
    }
}
