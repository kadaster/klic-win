package nl.kadaster.klic.win.feature.service;

public interface FeatureService {
    String  getFeatureGml(String source, final String bronhoudercode, final double xMin, final double yMin, final double xMax, final double yMax);
}
