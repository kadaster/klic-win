package nl.kadaster.klic.win.feature.service;

public class FeatureStoreException extends Exception {
    public FeatureStoreException(final String message, final Throwable cause) {
        super(message, cause);
    }
}
