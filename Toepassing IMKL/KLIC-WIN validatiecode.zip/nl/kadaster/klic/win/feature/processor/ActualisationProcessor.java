package nl.kadaster.klic.win.feature.processor;

import nl.kadaster.klic.win.feature.service.FeatureStoreException;
import nl.kadaster.klic.win.feature.service.FeatureStoreService;
import nl.kadaster.klic.win.model.message.*;
import org.apache.camel.EndpointInject;
import org.apache.camel.Exchange;
import org.apache.camel.Handler;
import org.apache.camel.ProducerTemplate;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class ActualisationProcessor {

    private static final Logger LOG = LoggerFactory.getLogger(ActualisationProcessor.class);

    private static final String EVENTNAME_INPRODUCTIENAME_GESLAAGD = "INPRODUCTIENAME_GESLAAGD";
    
    @Autowired
    private FeatureStoreService featureStoreService;

    @EndpointInject(uri = "commonAanleveringenEventQueue")
    private ProducerTemplate eventSenderProcessor;

    @Handler
    public void process(final Exchange exchange, final String xml) {
        LOG.info("Processing actualisation from the queue. [JmsMessageID: {}]", exchange.getIn().getMessageId());
        final AanleveringMessage aanleveringMessage = Unmarshaller.unmarshal(xml, AanleveringMessage.class);
        processConceptToProduction(aanleveringMessage);

        // specifically set the productiondate time here, now we know for sure that it's migrated to production
        final DateTime productionDateTime = new DateTime();
        LOG.info("Successfully taken into production on {}", productionDateTime);
        aanleveringMessage.setAanleverDatum(productionDateTime);

        sendApprovedAcknowledgeMessage(aanleveringMessage);
    }

    private void processConceptToProduction(final AanleveringMessage aanleveringMessage) {
        final String bronhouderCode = aanleveringMessage.getBronhouderCode();
        LOG.info("Received approval for actualisation for netbeheerder with bronhoudercode '{}', moving concept to production", bronhouderCode);
        try {
            featureStoreService.conceptToProduction(bronhouderCode);
        } catch (FeatureStoreException e) {
            final String msg = "Failed to move concept to production for netbeheerder with bronhoudercode '" + bronhouderCode + "'.";
            LOG.error(msg, e);
            throw new ActualisationException(msg, e);
        }
    }

    private void sendApprovedAcknowledgeMessage(final AanleveringMessage aanleveringMessage) {
        LOG.info("Sending acknowledgement...");
        eventSenderProcessor.send(new MessageSenderProcessor(createAanleveringEventMessageToProduction(aanleveringMessage)));
    }

    public void setFeatureStoreService(final FeatureStoreService featureStoreService) {
        this.featureStoreService = featureStoreService;
    }

    private static QueueMessage createAanleveringEventMessageToProduction(final AanleveringMessage aanleveringMessage) {
        AanleveringEventMessage eventMessage = new AanleveringEventMessage();
        eventMessage.setEventName(EVENTNAME_INPRODUCTIENAME_GESLAAGD);
        eventMessage.setAanleveringId(aanleveringMessage.getAanleveringId());
        eventMessage.setAanleveringUUID(aanleveringMessage.getAanleveringUUID());
        return eventMessage;
    }
    
}
