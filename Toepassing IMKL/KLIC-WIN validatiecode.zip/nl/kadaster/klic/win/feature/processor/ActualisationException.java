package nl.kadaster.klic.win.feature.processor;

class ActualisationException extends RuntimeException {

    public ActualisationException(final String message, final Throwable cause) {
        super(message, cause);
    }
}
