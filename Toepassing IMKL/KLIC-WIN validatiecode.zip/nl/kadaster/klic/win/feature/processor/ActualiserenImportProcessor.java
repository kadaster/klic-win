package nl.kadaster.klic.win.feature.processor;

import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.ImklImportBatchJobRunner;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.batch.exception.ImklImportBatchJobException;
import nl.kadaster.klic.win.feature.actualiseren.imkl2015.reader.validation.ValidationMessageBuilder;
import nl.kadaster.klic.win.feature.domain.ImportImklAanleveringResult;
import nl.kadaster.klic.win.feature.service.FeatureStoreService;
import nl.kadaster.klic.win.model.LogRegel;
import nl.kadaster.klic.win.model.Metrics;
import nl.kadaster.klic.win.model.ValidationMessage;
import nl.kadaster.klic.win.model.message.AanleveringEventMessage;
import nl.kadaster.klic.win.model.message.AanleveringMessage;
import nl.kadaster.klic.win.model.message.MessageSenderProcessor;
import nl.kadaster.klic.win.model.message.QueueMessage;
import nl.kadaster.klic.win.model.message.Unmarshaller;
import nl.kadaster.klic.win.feature.domain.InformatieSoort;
import org.apache.camel.EndpointInject;
import org.apache.camel.Exchange;
import org.apache.camel.Handler;
import org.apache.camel.ProducerTemplate;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;


public class ActualiserenImportProcessor {

    private static final String EVENTNAME_START = "VALIDATIE_STARTEN";
    private static final String EVENTNAME_FINISHED_WITHOUT_ERRORS = "VALIDATIE_AFGEROND_ZONDER_FOUTEN";
    private static final String EVENTNAME_FINISHED_WITH_ERRORS = "VALIDATIE_AFGEROND_MET_FOUTEN";

    @Autowired
    private ImklImportBatchJobRunner imklImportBatchJobRunner;

    @Autowired
    private FeatureStoreService featureStoreService;

    @EndpointInject(uri = "commonAanleveringenEventQueue")
    private ProducerTemplate eventSenderProcessor;

    private static final Logger LOG = LoggerFactory.getLogger(ActualiserenImportProcessor.class);

    @Async
    @Handler
    public void process(final Exchange exchange, final String xml) {
        LOG.info("Processing message from the queue. [JmsMessageID: {}]", exchange.getIn().getMessageId());
        final AanleveringMessage aanleveringMessage = Unmarshaller.unmarshal(xml, AanleveringMessage.class);
        LOG.info("Message-details: [{}]", aanleveringMessage);

        final String bronhouderCode = aanleveringMessage.getBronhouderCode();
        eventSenderProcessor.send(new MessageSenderProcessor(createAanleveringEventMessageValidationStarted(aanleveringMessage)));

        prepareForImport(bronhouderCode);
        importImklFile(InformatieSoort.fromQueueMessageString(aanleveringMessage.getInformatieSoort()),
                bronhouderCode,
                aanleveringMessage.getAanleveringId(),
                aanleveringMessage.getLocatieInOpslag(),
                aanleveringMessage.getAanleveringUUID());
    }

    private void prepareForImport(final String bronhouderCode) {
        LOG.info("Removing concept data for bronhouder {}", bronhouderCode);
        featureStoreService.removeConcept(bronhouderCode);
    }

    private static QueueMessage createAanleveringEventMessageValidationStarted(final AanleveringMessage aanleveringMessage) {
        AanleveringEventMessage eventMessage = new AanleveringEventMessage();
        eventMessage.setEventName(EVENTNAME_START);
        eventMessage.setAanleveringId(aanleveringMessage.getAanleveringId());
        eventMessage.setAanleveringUUID(aanleveringMessage.getAanleveringUUID());
        return eventMessage;
    }

    private void importImklFile(
            final InformatieSoort informatieSoort,
            final String bronhouderCode,
            final long aanleveringId,
            final String filename,
            final UUID aanleveringUUID) {
        LOG.info("Entering featurestore import IMKL...");
        final ImportImklAanleveringResult result = new ImportImklAanleveringResult(aanleveringId);
        if (StringUtils.isEmpty(filename)) {
            LOG.error("Filename missing. Filename: {}", filename);
            result.getValidationMessages().add(ValidationMessageBuilder.createTechnicalError(aanleveringId));
        } else {
            try {
                imklImportBatchJobRunner.run(informatieSoort, bronhouderCode, aanleveringId, result, filename);
            } catch (ImklImportBatchJobException e) {
                LOG.error("Fatal error running the imkl import job", e);
                result.getValidationMessages().add(ValidationMessageBuilder.createTechnicalError(aanleveringId));
            }
        }
        LOG.info("Nr of messages in the result (to be transformed to XML and put on the queue) is: {}", result.getValidationMessages().size());
        LOG.info("Import result: {}", determineEventName(result));
        LOG.info("Sending import result message...");
        eventSenderProcessor.send(new MessageSenderProcessor(createAanleveringEventMessage(result, aanleveringUUID)));
        LOG.info("Done. Message import result sent.");
    }

    private static AanleveringEventMessage createAanleveringEventMessage(final ImportImklAanleveringResult result, final UUID aanleveringUUID) {
        AanleveringEventMessage eventMessage = new AanleveringEventMessage();
        eventMessage.setEventName(determineEventName(result));
        eventMessage.setAanleveringId((int) result.getActualisatieId());
        eventMessage.setAanleveringUUID(aanleveringUUID);
        eventMessage.setMeldingen(determineMeldingen(result));
        eventMessage.setStatistiekRegels(result.getStatistiekRegels());
        eventMessage.setMetrics(createMetrics(result));
        return eventMessage;
    }

    private static Metrics createMetrics(final ImportImklAanleveringResult result){
        Metrics metrics = new Metrics();
        metrics.setItemsPerSecond(result.getFeaturesPerSecond());
        metrics.setItemsProcessed(result.getItemsProcessed());
        return metrics;
    }

    private static List<LogRegel> determineMeldingen(final ImportImklAanleveringResult result) {
        final List<LogRegel> logRegels = new ArrayList<>();
        if (result.getValidationMessages() != null) {
            for (ValidationMessage interneLogRegel: result.getValidationMessages()) {
                LogRegel aanleverstapmelding = convertToLogRegel(interneLogRegel);
                logRegels.add(aanleverstapmelding);
            }
        }
        return logRegels;
    }

    private static LogRegel convertToLogRegel(final ValidationMessage validationMessage) {
        LogRegel logRegel = new LogRegel();
        logRegel.setCode(validationMessage.getCategory().name());
        logRegel.setElement(null);
        logRegel.setGradatie(determineGradatie(validationMessage.getType()));
        logRegel.setIdentificatie(validationMessage.getGmlId());
        logRegel.setOmschrijving(validationMessage.getMessage());
        return logRegel;
    }

    private static LogRegel.Gradatie determineGradatie(final ValidationMessage.ValidationMessageType type) {
        LogRegel.Gradatie gradatie = LogRegel.Gradatie.FOUT;
        if (type.equals(ValidationMessage.ValidationMessageType.INFO)) {
            gradatie = LogRegel.Gradatie.INFORMATIE;
        } else if (type.equals(ValidationMessage.ValidationMessageType.WARNING)) {
            gradatie = LogRegel.Gradatie.WAARSCHUWING;
        } 
        return gradatie;
    }

    private static String determineEventName(final ImportImklAanleveringResult result) {
        String eventName = EVENTNAME_FINISHED_WITHOUT_ERRORS;
        if(result.hasErrors()) {
            eventName = EVENTNAME_FINISHED_WITH_ERRORS;
        }
        return eventName;
    }

}
