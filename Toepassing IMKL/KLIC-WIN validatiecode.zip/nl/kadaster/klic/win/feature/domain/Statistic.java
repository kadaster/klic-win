package nl.kadaster.klic.win.feature.domain;

import nl.kadaster.klic.win.model.FeatureGroup;
import nl.kadaster.klic.win.model.InspireThema;
import nl.kadaster.klic.win.model.WionThema;

public class Statistic {

    private InspireThema themaInspire;
    private WionThema themaWion;
    private FeatureGroup group;
    private Integer amount;

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(final Integer amount) {
        this.amount = amount;
    }

    public WionThema getThemaWion() {
        return themaWion;
    }

    public void setThemaWion(final WionThema themaWion) {
        this.themaWion = themaWion;
    }

    public InspireThema getThemaInspire() {
        return themaInspire;
    }

    public void setThemaInspire(final InspireThema themaInspire) {
        this.themaInspire = themaInspire;
    }

    public FeatureGroup getGroup() {
        return group;
    }

    public void setGroup(final FeatureGroup group) {
        this.group = group;
    }
}
