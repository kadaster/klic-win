package nl.kadaster.klic.win.feature.domain;

public class ThemeRequestParameters {

    private String wktArea;
    private String bronhoudercode;

    public String getWktArea() {
        return wktArea;
    }

    public void setWktArea(String wktArea) {
        this.wktArea = wktArea;
    }

    public String getBronhoudercode() {
        return bronhoudercode;
    }

    public void setBronhoudercode(String bronhoudercode) {
        this.bronhoudercode = bronhoudercode;
    }
}
