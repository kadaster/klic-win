package nl.kadaster.klic.win.feature.domain;

public class WktBoundingbox {

    private String aWktBoundingbox;

    public String getWktBoundingbox() {
        return aWktBoundingbox;
    }

    public void setWktBoundingbox(String aWktBoundingbox) {
        this.aWktBoundingbox = aWktBoundingbox;
    }
}
