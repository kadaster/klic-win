package nl.kadaster.klic.win.feature.domain;

import java.util.ArrayList;
import java.util.List;

public class ThemeResponse {

    private List<String> themes;
    private STATUS status;

    public List<String> getThemes() {
        if (themes == null) {
            themes = new ArrayList<>();
        }
        return themes;
    }

    public void setThemes(List<String> themes) {
        this.themes = themes;
    }

    public STATUS getStatus() {
        return status;
    }

    public void setStatus(STATUS status) {
        this.status = status;
    }

    public enum STATUS {
        OK, ERROR
    }

}
