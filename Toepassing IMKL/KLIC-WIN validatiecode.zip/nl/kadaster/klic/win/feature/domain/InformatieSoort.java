package nl.kadaster.klic.win.feature.domain;

public enum InformatieSoort {

    NETINFORMATIE("netinformatie"),
    BEHEERDERSINFORMATIE("beheerdersinformatie");

    private final String queueMessageString;

    InformatieSoort(final String queueMessageString) {
        this.queueMessageString = queueMessageString;
    }

    public static InformatieSoort fromQueueMessageString(final String queueMessageString) {
        for (InformatieSoort status : InformatieSoort.values()) {
            if (status.queueMessageString.equals(queueMessageString)) {
                return status;
            }
        }
        throw new IllegalArgumentException();
    }

    public String toQueueMessageString() {
        return queueMessageString;
    }

}
