package nl.kadaster.klic.win.feature.domain;

import nl.kadaster.klic.win.model.StatistiekRegel;
import nl.kadaster.klic.win.model.ValidationMessage;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ImportImklAanleveringResult implements Serializable {

    private static final long serialVersionUID = -4115854289752839072L;

    private final long actualisatieId;
    private final List<ValidationMessage> validationMessages = new ArrayList<>();
    private final List<StatistiekRegel> statistiekregels = new ArrayList<>();
    private int featuresPerSecond;
    private int itemsProcessed;

    public ImportImklAanleveringResult(final long actualisatieId) {
        this.actualisatieId = actualisatieId;
    }

    public List<ValidationMessage> getValidationMessages() {
        return validationMessages;
    }

    public List<StatistiekRegel> getStatistiekRegels() {
        return statistiekregels;
    }

    public long getActualisatieId() {
        return actualisatieId;
    }

    public boolean hasErrors() {
        for (ValidationMessage validationMessage : validationMessages) {
            if (ValidationMessage.ValidationMessageType.ERROR == validationMessage.getType()) {
                return true;
            }
        }
        return false;
    }

    public void setFeaturesPerSecond(final int featuresPerSecond) {
        this.featuresPerSecond = featuresPerSecond;
    }

    public int getFeaturesPerSecond() {
        return featuresPerSecond;
    }

    public int getItemsProcessed() {
        return itemsProcessed;
    }

    public void setItemsProcessed(final int itemsProcessed) {
        this.itemsProcessed = itemsProcessed;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        final ImportImklAanleveringResult that = (ImportImklAanleveringResult) o;
        return new EqualsBuilder()
                .append(actualisatieId, that.actualisatieId)
                .append(featuresPerSecond, that.featuresPerSecond)
                .append(itemsProcessed, that.itemsProcessed)
                .append(validationMessages, that.validationMessages)
                .append(statistiekregels, that.statistiekregels)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(actualisatieId)
                .append(validationMessages)
                .append(statistiekregels)
                .append(featuresPerSecond)
                .append(itemsProcessed)
                .toHashCode();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("actualisatieId", actualisatieId)
                .append("validationMessages", validationMessages)
                .append("statistiekregels", statistiekregels)
                .append("featuresPerSecond", featuresPerSecond)
                .append("itemsProcessed", itemsProcessed)
                .toString();
    }
}
