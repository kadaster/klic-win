package nl.kadaster.klic.win.feature.domain;

public class Netbeheerder {
    
    private Long netbeheerderId;
    
    private String bronhouderCode;

    public Long getNetbeheerderId() {
        return netbeheerderId;
    }

    public void setNetbeheerderId(Long netbeheerderId) {
        this.netbeheerderId = netbeheerderId;
    }

    public String getBronhouderCode() {
        return bronhouderCode;
    }

    public void setBronhouderCode(String bronhouderCode) {
        this.bronhouderCode = bronhouderCode;
    }

}
