package nl.kadaster.klic.win.feature.codelist.storage;

import nl.kadaster.klic.win.storage.BaseRowMapper;
import nl.kadaster.klic.win.feature.codelist.domain.CodelistValue;

import java.sql.SQLException;

public class CodelistValueRowMapper extends BaseRowMapper<CodelistValue> {

    private static final String FIELD_ID = "id";
    private static final String FIELD_DESCRIPTION = "description";
    private static final String FIELD_LABEL = "label";
    private static final String FIELD_CODE = "code";
    private static final String FIELD_CODELIST_ID = "codelist_id";

    @Override
    protected CodelistValue mapRow() throws SQLException {
        final CodelistValue codelistValue = new CodelistValue();
        codelistValue.setId(getLong(FIELD_ID));
        codelistValue.setDescription(getString(FIELD_DESCRIPTION));
        codelistValue.setLabel(getString(FIELD_LABEL));
        codelistValue.setValue(getString(FIELD_CODE));
        codelistValue.setCodelistId(getLong(FIELD_CODELIST_ID));
        return codelistValue;
    }

}
