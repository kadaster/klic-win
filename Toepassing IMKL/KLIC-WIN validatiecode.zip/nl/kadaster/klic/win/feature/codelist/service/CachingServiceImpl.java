package nl.kadaster.klic.win.feature.codelist.service;

import nl.kadaster.klic.win.feature.codelist.domain.Codelist;
import nl.kadaster.klic.win.feature.codelist.domain.CodelistValue;
import nl.kadaster.klic.win.feature.codelist.storage.CodelistDao;
import nl.kadaster.klic.win.feature.codelist.storage.CodelistValueDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;

public class CachingServiceImpl implements CachingService {

    @Autowired
    private CodelistDao codelistDao;

    @Autowired
    private CodelistValueDao codelistValueDao;

    @Override
    @Cacheable(value="codelistvalues", key="{#root.methodName, #codelist.id, #value}")
    public CodelistValue getCodelistValueCached(final String value, final Codelist codelist) {
        return codelistValueDao.getCodelistValue(codelist.getId(), value);
    }

    @Override
    @Cacheable(value="codelists")
    public Codelist getCodelistCached(final String codelistName) {
        return codelistDao.getCodelist(codelistName);
    }
}
