package nl.kadaster.klic.win.feature.codelist.domain;

import nl.kadaster.klic.win.feature.domain.DomainObject;

public class Codelist extends DomainObject {

    private final String name;

    public Codelist(final String name) {
        super();
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
