package nl.kadaster.klic.win.feature.codelist.storage;

import static nl.kadaster.klic.win.util.NiStoreUtil.getCdbTableName;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import nl.kadaster.klic.win.feature.codelist.domain.Codelist;

public class CodelistDaoImpl implements CodelistDao {

    private static final String TABLENAME_CODELIST = "codelist";

    private static final String SQL_QUERY_CODELIST = "select id, name from " + getCdbTableName(TABLENAME_CODELIST) +
            " where name = ?";

    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    @Override
    public Codelist getCodelist(final String codelistName) {
        Codelist codelist = null;
        List<Codelist> codelists = jdbcTemplate.query(SQL_QUERY_CODELIST, new Object[] {codelistName}, new CodelistRowMapper());
        if (!codelists.isEmpty()) {
            codelist = codelists.get(0);
        }
        return codelist;
    }

}
