package nl.kadaster.klic.win.feature.codelist.storage;

import static java.sql.Types.INTEGER;
import static java.sql.Types.VARCHAR;
import static nl.kadaster.klic.win.util.NiStoreUtil.getCdbTableName;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import nl.kadaster.klic.win.feature.codelist.domain.CodelistValue;

public class CodelistValueDaoImpl implements CodelistValueDao {

    private static final String TABLENAME_CODELIST_VALUE = "codelistvalue";
   
    private static final String SQL_QUERY_CODELISTVALUE_BY_CODELIST_ID = "select id, codelist_id, label, description, code from " + getCdbTableName(TABLENAME_CODELIST_VALUE) +
            " where codelist_id = ? and code = ?";
    
    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    // NOTE: the 'value' column is associated with the 'code' column. Reason is that 'value'
    //       is a reserved word in SQL99 and SQL92 standards.

    @Override
    public CodelistValue getCodelistValue(final long codelistId, final String value) {
        CodelistValue codelistValue = null;
        List<CodelistValue> codelistValues = jdbcTemplate.query(
        		  SQL_QUERY_CODELISTVALUE_BY_CODELIST_ID
        		, new Object[]{codelistId, value}
        		, new int[] { INTEGER, VARCHAR }
        		, new CodelistValueRowMapper());
        if (!codelistValues.isEmpty()) {
            codelistValue = codelistValues.get(0);
        }
        return codelistValue;
    }

}
