package nl.kadaster.klic.win.feature.codelist.service;

public interface CodelistVerifyService {

    boolean isValid(final String codelistName, final String value);

}
