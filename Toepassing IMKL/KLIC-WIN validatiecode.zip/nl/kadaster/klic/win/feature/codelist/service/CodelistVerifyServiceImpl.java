package nl.kadaster.klic.win.feature.codelist.service;

import nl.kadaster.klic.win.feature.codelist.domain.Codelist;
import org.springframework.beans.factory.annotation.Autowired;

public class CodelistVerifyServiceImpl implements CodelistVerifyService {

    @Autowired
    private CachingService cachingService;

    @Override
    public boolean isValid(final String codelistName, final String value) {
        final Codelist codelist = cachingService.getCodelistCached(codelistName);
        return codelist != null && cachingService.getCodelistValueCached(value, codelist) != null;
    }
}
