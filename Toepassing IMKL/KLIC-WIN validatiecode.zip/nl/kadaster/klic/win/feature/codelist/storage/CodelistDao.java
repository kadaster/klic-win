package nl.kadaster.klic.win.feature.codelist.storage;

import nl.kadaster.klic.win.feature.codelist.domain.Codelist;

public interface CodelistDao {

    Codelist getCodelist(final String codelistName);

}
