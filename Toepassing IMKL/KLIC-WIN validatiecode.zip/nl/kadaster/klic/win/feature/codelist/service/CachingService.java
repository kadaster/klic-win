package nl.kadaster.klic.win.feature.codelist.service;

import nl.kadaster.klic.win.feature.codelist.domain.Codelist;
import nl.kadaster.klic.win.feature.codelist.domain.CodelistValue;

public interface CachingService {

    CodelistValue getCodelistValueCached(final String value, final Codelist codelist);
    Codelist getCodelistCached(final String codelistName);
}