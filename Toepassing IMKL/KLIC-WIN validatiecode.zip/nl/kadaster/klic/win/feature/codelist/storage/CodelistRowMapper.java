package nl.kadaster.klic.win.feature.codelist.storage;

import nl.kadaster.klic.win.storage.BaseRowMapper;
import nl.kadaster.klic.win.feature.codelist.domain.Codelist;

import java.sql.SQLException;

public class CodelistRowMapper extends BaseRowMapper<Codelist> {

    private static final String FIELD_ID = "id";
    private static final String FIELD_NAME = "name";

    @Override
    protected Codelist mapRow() throws SQLException {
        final String name = getString(FIELD_NAME);
        final Codelist codelist = new Codelist(name);
        codelist.setId(getLong(FIELD_ID));
        return codelist;
    }

}
