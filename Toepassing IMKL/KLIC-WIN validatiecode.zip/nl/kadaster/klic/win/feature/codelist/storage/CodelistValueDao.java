package nl.kadaster.klic.win.feature.codelist.storage;

import nl.kadaster.klic.win.feature.codelist.domain.CodelistValue;

public interface CodelistValueDao {

    CodelistValue getCodelistValue(final long codelistId, final String value);

}
