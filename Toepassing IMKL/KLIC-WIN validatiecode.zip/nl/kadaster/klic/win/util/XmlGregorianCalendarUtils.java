package nl.kadaster.klic.win.util;

import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.XMLGregorianCalendar;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalDateTime;
import org.joda.time.LocalTime;

public final class XmlGregorianCalendarUtils {

    /**
     * Private constructor to prevent instantiation.
     */
    private XmlGregorianCalendarUtils() {
    }

    /**
     * Converts from an XMLGregorianCalendar to a LocalDateTime i.e. represents a date and time without timezone
     * information
     *
     * @param calendar XMLGregorianCalendar object.
     * @return The calendar converted to a LocalDateTime.
     */
    public static LocalDateTime convertToLocalDateTime(final XMLGregorianCalendar calendar) {
        if (calendar == null) {
            return null;
        }
        int year = calendar.getYear() > 0 ? calendar.getYear() : 0;
        // month and day cannot be zero
        int hour = calendar.getHour() > 0 ? calendar.getHour() : 0;
        int minute = calendar.getMinute() > 0 ? calendar.getMinute() : 0;
        int second = calendar.getSecond() > 0 ? calendar.getSecond() : 0;
        int millisecond = calendar.getMillisecond() > 0 ? calendar.getMillisecond() : 0;

        return new LocalDateTime(year, calendar.getMonth(), calendar.getDay(), hour, minute, second, millisecond);
    }

    public static DateTime convertToDateTime(final XMLGregorianCalendar calendar) {
        if (calendar == null) {
            return null;
        }
        
        int year = calendar.getYear();
        int month = calendar.getMonth();
        int day = calendar.getDay();
        
        if (year == DatatypeConstants.FIELD_UNDEFINED || month == DatatypeConstants.FIELD_UNDEFINED || day == DatatypeConstants.FIELD_UNDEFINED) {
            return null;
        }
        
        int hour = nvl( calendar.getHour() );
        int minute = nvl( calendar.getMinute() );
        int second = nvl( calendar.getSecond() );
        int millisecond = nvl( calendar.getMillisecond() );
        
        int xmlTimezoneInMinutes = calendar.getTimezone();
        DateTimeZone tz;
        if (xmlTimezoneInMinutes == DatatypeConstants.FIELD_UNDEFINED) {
            tz = DateTimeZone.getDefault();
        } else {
            tz = DateTimeZone.forOffsetHoursMinutes(tzHoursOffset(xmlTimezoneInMinutes), tzMinutesOffset(xmlTimezoneInMinutes));
        }

        return new DateTime(year, month, day, hour, minute, second, millisecond, tz);
    }

    private static int nvl(final int v) {
        return v != DatatypeConstants.FIELD_UNDEFINED ? v : 0;
    }
    
    static int tzHoursOffset(final int totalMinutesOffset) {
        return totalMinutesOffset/60;
    }
    
    static int tzMinutesOffset(final int totalMinutesOffset) {
        return totalMinutesOffset%60;
    }

    /**
     * Converts from an XMLGregorianCalendar to a LocalTime i.e. represents a time without timezone or date information.
     *
     * @param calendar XMLGregorianCalendar object.
     * @return The calendar converted to a LocalTime.
     */
    public static LocalTime convertToLocalTime(final XMLGregorianCalendar calendar) {
        if (calendar == null) {
            return null;
        }
        int hour = calendar.getHour() > 0 ? calendar.getHour() : 0;
        int minute = calendar.getMinute() > 0 ? calendar.getMinute() : 0;
        int second = calendar.getSecond() > 0 ? calendar.getSecond() : 0;
        int millisecond = calendar.getMillisecond() > 0 ? calendar.getMillisecond() : 0;

        return new LocalTime(hour, minute, second, millisecond);
    }

}
