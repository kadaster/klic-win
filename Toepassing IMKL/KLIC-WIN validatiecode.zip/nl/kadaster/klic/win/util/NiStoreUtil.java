package nl.kadaster.klic.win.util;

import nl.kadaster.klic.win.feature.domain.imkl2015.DatabaseConstants;
import nl.kadaster.klic.win.feature.domain.production.LeveringType;

public final class NiStoreUtil {

    public static final String SA_PLACEHOLDER  = "%1$s";
    public static final String SA_PLACEHOLDER1 = "%1$s";
    public static final String SA_PLACEHOLDER2 = "%2$s";

    private static final String BRONHOUDERCODE_ENEXIS = "KL1031";
    private static final String BRONHOUDERCODE_LIANDER = "KL1040";

    private NiStoreUtil() {
    }
    
    public static boolean isPartitioned(final String bronhoudercode) {
        return BRONHOUDERCODE_ENEXIS.equals(bronhoudercode) ||
               BRONHOUDERCODE_LIANDER.equals(bronhoudercode);
    }

    public static String adaptQueryForStagingArea(final String bronhoudercode, final String qry, final String... tables) {
        String[] conceptTables = new String[tables.length];
        for (int i=0; i<tables.length; i++) {
            conceptTables[i] = getConceptTableName(tables[i], bronhoudercode);
        }
        return String.format(qry, (Object[]) conceptTables);
    }
    
    public static String getCdbTableName(final String tableName) {
        return DatabaseConstants.NI_STORE + "." + tableName;
    }

    private static String getConceptTableName(final String tableName, final String bronhoudercode) {
        return DatabaseConstants.NI_STORE + "." + tableName + "_" + getStagingAreaSuffix(bronhoudercode);
    }

    private static String getStagingAreaSuffix(final String bronhoudercode) {
        String name;
        if (isPartitioned(bronhoudercode)) {
            name = bronhoudercode.toLowerCase() + "_sa";
        } else {
            name = "rest_sa";
        }
        return name;
    }
    
    public static String getBronhoudercodeFromGmlId(final String gmlId) {
        return gmlId.substring(8, 14);
    }

}
