package nl.kadaster.klic.win.util;

import org.joda.time.DateTime;

public interface TimestampProvider {
    DateTime getTimeStamp();
}
