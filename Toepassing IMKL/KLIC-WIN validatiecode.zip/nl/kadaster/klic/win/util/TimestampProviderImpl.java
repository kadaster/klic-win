package nl.kadaster.klic.win.util;

import org.joda.time.DateTime;

public class TimestampProviderImpl implements TimestampProvider {
    @Override
    public DateTime getTimeStamp() {
        return new DateTime();
    }
}
