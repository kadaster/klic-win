package nl.kadaster.klic.win.delivery.processor;


import nl.kadaster.klic.win.model.message.DeliverReadyMessage;
import nl.kadaster.klic.win.model.message.MarshalException;
import nl.kadaster.klic.win.model.message.Marshaller;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

class DeliveryReadyMessageSenderProcessor implements Processor {

    private static final Logger LOG = LoggerFactory.getLogger(DeliveryReadyMessageSenderProcessor.class);

    private final DeliverReadyMessage message;

    public DeliveryReadyMessageSenderProcessor(final DeliverReadyMessage message) {
        this.message = message;
    }

    @Override
    public void process(final Exchange exchange) throws Exception {
        try {
            exchange.getIn().setBody(Marshaller.marshal(message));
        } catch (MarshalException ex) {
            LOG.error("Unable to write DeliveryReadyMessage to put on the queue", ex);
            throw ex;
        }
    }

}
