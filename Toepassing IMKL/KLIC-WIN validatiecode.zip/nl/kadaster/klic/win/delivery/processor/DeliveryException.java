package nl.kadaster.klic.win.delivery.processor;

public class DeliveryException extends Exception {
    
    private static final long serialVersionUID = -6911332479313506437L;

    public DeliveryException(final String message, final Throwable cause) {
        super(message, cause);
    }

}
