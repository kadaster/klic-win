package nl.kadaster.klic.win.delivery.processor;

import nl.kadaster.klic.win.delivery.storage.OrderDao;
import nl.kadaster.klic.win.model.message.DeliverReadyMessage;
import nl.kadaster.klic.win.model.message.DeliverRequestMessage;
import nl.kadaster.klic.win.model.message.Unmarshaller;
import org.apache.camel.EndpointInject;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.ProducerTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.sql.SQLException;

public class DeliveryProcessor implements Processor {

    private static final Logger LOG = LoggerFactory.getLogger(DeliveryProcessor.class);
    private static final String WMS_URL_FMT = "%s/%s/inspire/wms?service=wms&version=1.3.0&request=GetCapabilities";
    private static final String WFS_URL_FMT = "%s/%s?service=wfs&version=2.0.0&request=GetCapabilities";

    private String wmsUrl;
    private String wfsUrl;

    @EndpointInject(uri = "direct:sendDeliveryReady")
    private ProducerTemplate deliveryReadySenderProcessor;

    @Autowired
    private OrderDao orderDao;

    @Override
    public void process(final Exchange exchange) throws Exception {
        LOG.info("De-queueing DeliverRequestMessage. [JmsMessageID: {}]", exchange.getIn().getMessageId());
        final String xml = exchange.getIn().getBody(String.class);
        DeliverRequestMessage deliverRequestMessage = Unmarshaller.unmarshal(xml, DeliverRequestMessage.class);
        if (deliverRequestMessage.getOrderId() != null) {
            sendLeveringUrls(deliverRequestMessage);
        } else {
            // Drop invalid messages
            LOG.error("Ignoring invalid order message {}", deliverRequestMessage );
            sendErrorMessage(deliverRequestMessage);
        }
    }

    private void sendErrorMessage(DeliverRequestMessage inMessage) throws DeliveryException {
        DeliverReadyMessage outMessage = new DeliverReadyMessage();
        outMessage.setDeliverRequestMessage(inMessage);
        outMessage.setOrderOk(false);

        LOG.info("Enqueuing of DeliverReadyMessage ERROR to delivery_rdy [ProductieOrder ID: {}]", inMessage.getOrderId());
        final Exchange send = deliveryReadySenderProcessor.send(new DeliveryReadyMessageSenderProcessor(outMessage));
        final Exception sendException = send.getException();
        if (null != sendException) {
            final String message = "Unable to put OrderMessage on the delivery-ready queue";
            LOG.error(message, sendException);
            throw new DeliveryException(message, sendException);
        }
    }

    private void sendLeveringUrls(DeliverRequestMessage inMessage) throws DeliveryException {
        DeliverReadyMessage outMessage = new DeliverReadyMessage();
        outMessage.setDeliverRequestMessage(inMessage);
        try {
            String uuid = orderDao.getUuidByMtoId(inMessage.getOrderId());
            outMessage.setUrlWms( String.format(WMS_URL_FMT, wmsUrl, uuid) );
            outMessage.setUrlWfs( String.format(WFS_URL_FMT, wfsUrl, uuid) );
            outMessage.setOrderOk(true);

            LOG.info("Enqueuing of DeliverReadyMessage SUCCESS to delivery_rdy [ProductieOrder ID: {}]", inMessage.getOrderId());
            final Exchange send = deliveryReadySenderProcessor.send(new DeliveryReadyMessageSenderProcessor(outMessage));
            final Exception sendException = send.getException();
            if (null != sendException) {
                final String message = "Unable to put DeliverReadyMessage on the delivery-ready queue";
                LOG.error(message, sendException);
                throw new DeliveryException(message, sendException);
            }
        } catch (SQLException e) {
            throw new DeliveryException(e.getMessage(), e);
        }
    }

    public void setWmsUrl(String wmsUrl) {
        this.wmsUrl = wmsUrl;
    }

    public void setWfsUrl(String wfsUrl) {
        this.wfsUrl = wfsUrl;
    }

}
