package nl.kadaster.klic.win.delivery.storage;

import java.sql.SQLException;

public interface OrderDao {
    String getUuidByMtoId(final String crmId) throws SQLException;
}
