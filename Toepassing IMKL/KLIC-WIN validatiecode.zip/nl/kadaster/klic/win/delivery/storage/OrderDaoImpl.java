package nl.kadaster.klic.win.delivery.storage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;

public class OrderDaoImpl implements OrderDao {

    private static final String SQL_GET_UUID_BY_CRMID = "select uuid from levering.order where mto_id=?";

    @Autowired
    private DataSource datasource;

    /**
     * Get UUID by MTO (Make To Order) Id.
     */
    @Override
    public String getUuidByMtoId(final String mtoId) throws SQLException {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(datasource);
        List<String> uuids = jdbcTemplate.query(new PreparedStatementCreator() {
            @Override
            public PreparedStatement createPreparedStatement(final Connection connection) throws SQLException {
                final PreparedStatement ps = connection.prepareStatement(SQL_GET_UUID_BY_CRMID);
                ps.setString(1, mtoId);
                return ps;
            }
        }, new RowMapper<String>() {
            @Override
            public String mapRow(ResultSet resultSet, int i) throws SQLException {
                return resultSet.getString(1);
            }
        });
        String uuid;
        if (uuids != null && uuids.size()==1) {
            uuid = uuids.get(0);
        } else {
            throw new SQLException(String.format("Expected exactly one order for mto_id %s, but found none or more than one.", mtoId));
        }
        return uuid;
    }
}
